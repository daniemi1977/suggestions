<?php
/**
 * Elementor Video Grid Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Elementor_Video_Grid extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'ipv_video_grid';
    }
    
    public function get_title() {
        return '🎞️ IPV Video Grid';
    }
    
    public function get_icon() {
        return 'eicon-gallery-grid';
    }
    
    public function get_categories() {
        return array('ipv-video-manager');
    }
    
    protected function register_controls() {
        
        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Content',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'posts_per_page',
            array(
                'label' => 'Videos to Show',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 6,
                'min' => 1,
                'max' => 100,
            )
        );
        
        $this->add_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    '2' => '2 Columns',
                    '3' => '3 Columns',
                    '4' => '4 Columns',
                ),
                'default' => '3',
            )
        );
        
        $this->add_control(
            'orderby',
            array(
                'label' => 'Order By',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'date' => 'Date',
                    'title' => 'Title',
                    'rand' => 'Random',
                    'meta_value_num' => 'Views',
                ),
                'default' => 'date',
            )
        );
        
        $this->add_control(
            'order',
            array(
                'label' => 'Order',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'ASC' => 'Ascending',
                    'DESC' => 'Descending',
                ),
                'default' => 'DESC',
            )
        );
        
        $this->add_control(
            'show_title',
            array(
                'label' => 'Show Title',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_excerpt',
            array(
                'label' => 'Show Excerpt',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_views',
            array(
                'label' => 'Show View Count',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            array(
                'label' => 'Style',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'default' => array(
                    'size' => 20,
                ),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $args = array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'posts_per_page' => $settings['posts_per_page'],
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
        );
        
        if ($settings['orderby'] === 'meta_value_num') {
            $args['meta_key'] = '_ipv_view_count';
        }
        
        $videos = new WP_Query($args);
        
        $columns = $settings['columns'];
        $gap = $settings['gap']['size'];
        
        ?>
        <div class="ipv-video-grid" style="display: grid; grid-template-columns: repeat(<?php echo esc_attr($columns); ?>, 1fr); gap: <?php echo esc_attr($gap); ?>px;">
            <?php while ($videos->have_posts()): $videos->the_post(); ?>
                <div class="ipv-video-card" style="background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <div class="ipv-video-thumbnail" style="position: relative; padding-bottom: 56.25%; background: #000;">
                        <?php 
                        $thumbnail = get_post_meta(get_the_ID(), '_ipv_thumbnail_url', true);
                        if ($thumbnail): 
                        ?>
                            <img src="<?php echo esc_url($thumbnail); ?>" 
                                 alt="<?php the_title(); ?>"
                                 style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
                        <?php endif; ?>
                        <a href="<?php the_permalink(); ?>" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.3); opacity: 0; transition: opacity 0.3s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0'">
                            <svg width="60" height="60" viewBox="0 0 24 24" fill="white">
                                <path d="M8 5v14l11-7z"/>
                            </svg>
                        </a>
                    </div>
                    
                    <div style="padding: 15px;">
                        <?php if ($settings['show_title'] === 'yes'): ?>
                            <h3 style="margin: 0 0 10px 0; font-size: 16px; line-height: 1.4;">
                                <a href="<?php the_permalink(); ?>" style="color: #333; text-decoration: none;">
                                    <?php the_title(); ?>
                                </a>
                            </h3>
                        <?php endif; ?>
                        
                        <?php if ($settings['show_excerpt'] === 'yes'): ?>
                            <p style="margin: 0 0 10px 0; font-size: 14px; color: #666; line-height: 1.6;">
                                <?php echo wp_trim_words(get_the_excerpt(), 15); ?>
                            </p>
                        <?php endif; ?>
                        
                        <?php if ($settings['show_views'] === 'yes'): ?>
                            <div style="font-size: 12px; color: #999;">
                                👁️ <?php echo number_format(get_post_meta(get_the_ID(), '_ipv_view_count', true)); ?> views
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
        
        <style>
        @media (max-width: 768px) {
            .ipv-video-grid {
                grid-template-columns: repeat(2, 1fr) !important;
            }
        }
        @media (max-width: 480px) {
            .ipv-video-grid {
                grid-template-columns: 1fr !important;
            }
        }
        </style>
        <?php
    }
}
