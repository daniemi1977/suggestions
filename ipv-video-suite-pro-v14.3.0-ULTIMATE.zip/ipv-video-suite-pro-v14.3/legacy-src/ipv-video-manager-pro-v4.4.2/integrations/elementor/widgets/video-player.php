<?php
/**
 * Elementor Video Player Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Elementor_Video_Player extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'ipv_video_player';
    }
    
    public function get_title() {
        return '🎬 IPV Video Player';
    }
    
    public function get_icon() {
        return 'eicon-youtube';
    }
    
    public function get_categories() {
        return array('ipv-video-manager');
    }
    
    protected function register_controls() {
        
        // Content Section
        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Content',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'video_id',
            array(
                'label' => 'Select Video',
                'type' => \Elementor\Controls_Manager::SELECT2,
                'options' => $this->get_video_options(),
                'default' => '',
            )
        );
        
        $this->add_control(
            'autoplay',
            array(
                'label' => 'Autoplay',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
            )
        );
        
        $this->add_control(
            'show_title',
            array(
                'label' => 'Show Title',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_description',
            array(
                'label' => 'Show Description',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            array(
                'label' => 'Style',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'title_color',
            array(
                'label' => 'Title Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#333333',
                'selectors' => array(
                    '{{WRAPPER}} .ipv-video-title' => 'color: {{VALUE}}',
                ),
            )
        );
        
        $this->add_control(
            'border_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'default' => array(
                    'size' => 8,
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ipv-video-player iframe' => 'border-radius: {{SIZE}}{{UNIT}}',
                ),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        $video_id = $settings['video_id'];
        
        if (empty($video_id)) {
            echo '<p>Please select a video</p>';
            return;
        }
        
        $video = get_post($video_id);
        $youtube_id = get_post_meta($video_id, '_ipv_youtube_id', true);
        $autoplay = $settings['autoplay'] === 'yes' ? '1' : '0';
        
        ?>
        <div class="ipv-video-player-elementor">
            <?php if ($settings['show_title'] === 'yes'): ?>
                <h2 class="ipv-video-title"><?php echo esc_html($video->post_title); ?></h2>
            <?php endif; ?>
            
            <div class="ipv-video-player" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
                <iframe 
                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
                    src="https://www.youtube.com/embed/<?php echo esc_attr($youtube_id); ?>?autoplay=<?php echo $autoplay; ?>" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
            
            <?php if ($settings['show_description'] === 'yes'): ?>
                <div class="ipv-video-description" style="margin-top: 20px;">
                    <?php echo wpautop($video->post_content); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    private function get_video_options() {
        $options = array();
        
        $videos = get_posts(array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        foreach ($videos as $video) {
            $options[$video->ID] = $video->post_title;
        }
        
        return $options;
    }
}
