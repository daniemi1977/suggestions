<?php
/**
 * Elementor Video List Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Elementor_Video_List extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'ipv_video_list';
    }
    
    public function get_title() {
        return '📋 IPV Video List';
    }
    
    public function get_icon() {
        return 'eicon-post-list';
    }
    
    public function get_categories() {
        return array('ipv-video-manager');
    }
    
    protected function register_controls() {
        
        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Content',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'posts_per_page',
            array(
                'label' => 'Videos to Show',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
                'min' => 1,
                'max' => 50,
            )
        );
        
        $this->add_control(
            'show_thumbnail',
            array(
                'label' => 'Show Thumbnail',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_date',
            array(
                'label' => 'Show Date',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_views',
            array(
                'label' => 'Show Views',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $videos = get_posts(array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'posts_per_page' => $settings['posts_per_page'],
            'orderby' => 'date',
            'order' => 'DESC',
        ));
        
        ?>
        <div class="ipv-video-list">
            <?php foreach ($videos as $video): ?>
                <div class="ipv-video-list-item" style="display: flex; gap: 15px; padding: 15px; margin-bottom: 15px; background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <?php if ($settings['show_thumbnail'] === 'yes'): ?>
                        <div style="flex-shrink: 0; width: 120px;">
                            <?php $thumbnail = get_post_meta($video->ID, '_ipv_thumbnail_url', true); ?>
                            <a href="<?php echo get_permalink($video->ID); ?>">
                                <img src="<?php echo esc_url($thumbnail); ?>" 
                                     alt="<?php echo esc_attr($video->post_title); ?>"
                                     style="width: 100%; border-radius: 4px;">
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 8px 0; font-size: 16px;">
                            <a href="<?php echo get_permalink($video->ID); ?>" style="color: #333; text-decoration: none;">
                                <?php echo esc_html($video->post_title); ?>
                            </a>
                        </h4>
                        
                        <div style="font-size: 12px; color: #999; display: flex; gap: 15px;">
                            <?php if ($settings['show_date'] === 'yes'): ?>
                                <span>📅 <?php echo date('M d, Y', strtotime($video->post_date)); ?></span>
                            <?php endif; ?>
                            
                            <?php if ($settings['show_views'] === 'yes'): ?>
                                <span>👁️ <?php echo number_format(get_post_meta($video->ID, '_ipv_view_count', true)); ?> views</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
}
