/**
 * Gutenberg Blocks per IPV Video Manager
 */

(function(blocks, element, components, editor) {
    const { registerBlockType } = blocks;
    const { createElement: el } = element;
    const { SelectControl, ToggleControl, RangeControl } = components;
    const { InspectorControls } = editor;
    
    // Video Player Block
    registerBlockType('ipv/video-player', {
        title: '🎬 IPV Video Player',
        icon: 'video-alt3',
        category: 'embed',
        attributes: {
            videoId: { type: 'number', default: 0 },
            autoplay: { type: 'boolean', default: false },
            showTitle: { type: 'boolean', default: true },
            showDescription: { type: 'boolean', default: true }
        },
        
        edit: function(props) {
            const { attributes, setAttributes } = props;
            const { videoId, autoplay, showTitle, showDescription } = attributes;
            
            return el('div', { className: props.className },
                el(InspectorControls, {},
                    el(SelectControl, {
                        label: 'Select Video',
                        value: videoId,
                        options: [
                            { value: 0, label: 'Select a video...' },
                            ...ipvVideos.videos
                        ],
                        onChange: function(value) {
                            setAttributes({ videoId: parseInt(value) });
                        }
                    }),
                    el(ToggleControl, {
                        label: 'Autoplay',
                        checked: autoplay,
                        onChange: function(value) {
                            setAttributes({ autoplay: value });
                        }
                    }),
                    el(ToggleControl, {
                        label: 'Show Title',
                        checked: showTitle,
                        onChange: function(value) {
                            setAttributes({ showTitle: value });
                        }
                    }),
                    el(ToggleControl, {
                        label: 'Show Description',
                        checked: showDescription,
                        onChange: function(value) {
                            setAttributes({ showDescription: value });
                        }
                    })
                ),
                el('div', {
                    style: {
                        background: '#f0f0f0',
                        padding: '20px',
                        borderRadius: '4px',
                        textAlign: 'center'
                    }
                }, videoId ? '🎬 Video Player: Video ID ' + videoId : 'Please select a video')
            );
        },
        
        save: function() {
            return null; // Dynamic block
        }
    });
    
    // Video Grid Block
    registerBlockType('ipv/video-grid', {
        title: '🎞️ IPV Video Grid',
        icon: 'grid-view',
        category: 'widgets',
        attributes: {
            postsPerPage: { type: 'number', default: 6 },
            columns: { type: 'number', default: 3 },
            orderBy: { type: 'string', default: 'date' },
            order: { type: 'string', default: 'DESC' }
        },
        
        edit: function(props) {
            const { attributes, setAttributes } = props;
            const { postsPerPage, columns, orderBy, order } = attributes;
            
            return el('div', { className: props.className },
                el(InspectorControls, {},
                    el(RangeControl, {
                        label: 'Videos to Show',
                        value: postsPerPage,
                        onChange: function(value) {
                            setAttributes({ postsPerPage: value });
                        },
                        min: 1,
                        max: 20
                    }),
                    el(RangeControl, {
                        label: 'Columns',
                        value: columns,
                        onChange: function(value) {
                            setAttributes({ columns: value });
                        },
                        min: 1,
                        max: 4
                    }),
                    el(SelectControl, {
                        label: 'Order By',
                        value: orderBy,
                        options: [
                            { value: 'date', label: 'Date' },
                            { value: 'title', label: 'Title' },
                            { value: 'rand', label: 'Random' }
                        ],
                        onChange: function(value) {
                            setAttributes({ orderBy: value });
                        }
                    }),
                    el(SelectControl, {
                        label: 'Order',
                        value: order,
                        options: [
                            { value: 'DESC', label: 'Descending' },
                            { value: 'ASC', label: 'Ascending' }
                        ],
                        onChange: function(value) {
                            setAttributes({ order: value });
                        }
                    })
                ),
                el('div', {
                    style: {
                        background: '#f0f0f0',
                        padding: '20px',
                        borderRadius: '4px',
                        textAlign: 'center'
                    }
                }, '🎞️ Video Grid: ' + postsPerPage + ' videos in ' + columns + ' columns')
            );
        },
        
        save: function() {
            return null; // Dynamic block
        }
    });
    
})(window.wp.blocks, window.wp.element, window.wp.components, window.wp.blockEditor);
