<?php
/**
 * IPV Performance Monitor
 * Monitora performance e salute del plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Performance {
    
    private $metrics_option = 'ipv_performance_metrics';
    
    /**
     * Start performance timer
     * 
     * @param string $operation Operation name
     * @return string Timer ID
     */
    public function start_timer($operation) {
        $timer_id = uniqid('timer_', true);
        
        $timers = get_transient('ipv_active_timers') ?: array();
        $timers[$timer_id] = array(
            'operation' => $operation,
            'start' => microtime(true),
        );
        
        set_transient('ipv_active_timers', $timers, 3600);
        
        return $timer_id;
    }
    
    /**
     * Stop performance timer
     * 
     * @param string $timer_id Timer ID
     * @return float|false Execution time in seconds
     */
    public function stop_timer($timer_id) {
        $timers = get_transient('ipv_active_timers') ?: array();
        
        if (!isset($timers[$timer_id])) {
            return false;
        }
        
        $timer = $timers[$timer_id];
        $end_time = microtime(true);
        $execution_time = $end_time - $timer['start'];
        
        // Log metric
        $this->log_metric($timer['operation'], $execution_time);
        
        // Remove timer
        unset($timers[$timer_id]);
        set_transient('ipv_active_timers', $timers, 3600);
        
        return $execution_time;
    }
    
    /**
     * Log performance metric
     * 
     * @param string $operation Operation name
     * @param float $execution_time Execution time in seconds
     */
    public function log_metric($operation, $execution_time) {
        $metrics = get_option($this->metrics_option, array());
        
        if (!isset($metrics[$operation])) {
            $metrics[$operation] = array(
                'count' => 0,
                'total_time' => 0,
                'min_time' => PHP_FLOAT_MAX,
                'max_time' => 0,
                'last_execution' => null,
            );
        }
        
        $metrics[$operation]['count']++;
        $metrics[$operation]['total_time'] += $execution_time;
        $metrics[$operation]['min_time'] = min($metrics[$operation]['min_time'], $execution_time);
        $metrics[$operation]['max_time'] = max($metrics[$operation]['max_time'], $execution_time);
        $metrics[$operation]['last_execution'] = current_time('mysql');
        $metrics[$operation]['avg_time'] = $metrics[$operation]['total_time'] / $metrics[$operation]['count'];
        
        update_option($this->metrics_option, $metrics);
    }
    
    /**
     * Get performance metrics
     * 
     * @param string|null $operation Specific operation or null for all
     * @return array
     */
    public function get_metrics($operation = null) {
        $metrics = get_option($this->metrics_option, array());
        
        if ($operation !== null) {
            return isset($metrics[$operation]) ? $metrics[$operation] : null;
        }
        
        return $metrics;
    }
    
    /**
     * Get system health
     * 
     * @return array
     */
    public function get_system_health() {
        global $wpdb;
        
        $health = array(
            'database' => $this->check_database_health(),
            'api' => $this->check_api_health(),
            'cache' => $this->check_cache_health(),
            'queue' => $this->check_queue_health(),
            'disk_space' => $this->check_disk_space(),
            'memory_usage' => $this->check_memory_usage(),
        );
        
        // Calculate overall score
        $scores = array_map(function($check) {
            return $check['score'];
        }, $health);
        
        $health['overall_score'] = array_sum($scores) / count($scores);
        $health['status'] = $this->get_status_from_score($health['overall_score']);
        
        return $health;
    }
    
    /**
     * Check database health
     * 
     * @return array
     */
    private function check_database_health() {
        global $wpdb;
        
        $video_count = wp_count_posts('ipv_video')->publish;
        $orphaned_meta = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->postmeta} pm
            LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
            WHERE p.ID IS NULL AND pm.meta_key LIKE '_ipv_%'
        ");
        
        $score = 100;
        $issues = array();
        
        if ($orphaned_meta > 0) {
            $score -= 20;
            $issues[] = sprintf('Found %d orphaned meta entries', $orphaned_meta);
        }
        
        return array(
            'score' => $score,
            'status' => $this->get_status_from_score($score),
            'video_count' => $video_count,
            'orphaned_meta' => $orphaned_meta,
            'issues' => $issues,
        );
    }
    
    /**
     * Check API health
     * 
     * @return array
     */
    private function check_api_health() {
        $supadata_key = get_option('ipv_supadata_api_key', '');
        $openai_key = get_option('ipv_openai_api_key', '');
        
        $score = 100;
        $issues = array();
        
        if (empty($supadata_key)) {
            $score -= 50;
            $issues[] = 'Supadata API key not configured';
        }
        
        if (empty($openai_key)) {
            $score -= 50;
            $issues[] = 'OpenAI API key not configured';
        }
        
        return array(
            'score' => $score,
            'status' => $this->get_status_from_score($score),
            'supadata_configured' => !empty($supadata_key),
            'openai_configured' => !empty($openai_key),
            'issues' => $issues,
        );
    }
    
    /**
     * Check cache health
     * 
     * @return array
     */
    private function check_cache_health() {
        $cache = new IPV_Cache();
        $stats = $cache->get_stats();
        
        $score = min(100, $stats['hit_rate']);
        
        return array(
            'score' => $score,
            'status' => $this->get_status_from_score($score),
            'hit_rate' => $stats['hit_rate'],
            'cache_hits' => $stats['cache_hits'],
            'cache_misses' => $stats['cache_misses'],
        );
    }
    
    /**
     * Check queue health
     * 
     * @return array
     */
    private function check_queue_health() {
        $queue = new IPV_Queue();
        $stats = $queue->get_stats();
        
        $score = 100;
        $issues = array();
        
        if ($stats['failed'] > 10) {
            $score -= 30;
            $issues[] = sprintf('High number of failed jobs: %d', $stats['failed']);
        }
        
        if ($stats['pending'] > 50) {
            $score -= 20;
            $issues[] = sprintf('Large queue backlog: %d pending jobs', $stats['pending']);
        }
        
        return array(
            'score' => $score,
            'status' => $this->get_status_from_score($score),
            'total' => $stats['total'],
            'pending' => $stats['pending'],
            'completed' => $stats['completed'],
            'failed' => $stats['failed'],
            'issues' => $issues,
        );
    }
    
    /**
     * Check disk space
     * 
     * @return array
     */
    private function check_disk_space() {
        $upload_dir = wp_upload_dir();
        $free_space = @disk_free_space($upload_dir['basedir']);
        $total_space = @disk_total_space($upload_dir['basedir']);
        
        if ($free_space === false || $total_space === false) {
            return array(
                'score' => 100,
                'status' => 'unknown',
                'message' => 'Unable to check disk space',
            );
        }
        
        $used_percent = (($total_space - $free_space) / $total_space) * 100;
        
        $score = 100;
        if ($used_percent > 90) {
            $score = 30;
        } elseif ($used_percent > 80) {
            $score = 60;
        }
        
        return array(
            'score' => $score,
            'status' => $this->get_status_from_score($score),
            'free_space' => size_format($free_space),
            'total_space' => size_format($total_space),
            'used_percent' => round($used_percent, 2),
        );
    }
    
    /**
     * Check memory usage
     * 
     * @return array
     */
    private function check_memory_usage() {
        $memory_limit = ini_get('memory_limit');
        $memory_usage = memory_get_usage(true);
        
        $limit_bytes = $this->convert_to_bytes($memory_limit);
        $usage_percent = ($memory_usage / $limit_bytes) * 100;
        
        $score = 100;
        if ($usage_percent > 90) {
            $score = 30;
        } elseif ($usage_percent > 75) {
            $score = 60;
        }
        
        return array(
            'score' => $score,
            'status' => $this->get_status_from_score($score),
            'memory_limit' => $memory_limit,
            'memory_usage' => size_format($memory_usage),
            'usage_percent' => round($usage_percent, 2),
        );
    }
    
    /**
     * Convert memory limit to bytes
     * 
     * @param string $size Size string
     * @return int
     */
    private function convert_to_bytes($size) {
        $size = trim($size);
        $last = strtolower($size[strlen($size) - 1]);
        $size = (int) $size;
        
        switch ($last) {
            case 'g':
                $size *= 1024;
            case 'm':
                $size *= 1024;
            case 'k':
                $size *= 1024;
        }
        
        return $size;
    }
    
    /**
     * Get status from score
     * 
     * @param float $score Score 0-100
     * @return string
     */
    private function get_status_from_score($score) {
        if ($score >= 80) {
            return 'good';
        } elseif ($score >= 60) {
            return 'warning';
        } else {
            return 'critical';
        }
    }
    
    /**
     * Get slow operations
     * 
     * @param int $limit Max results
     * @return array
     */
    public function get_slow_operations($limit = 10) {
        $metrics = $this->get_metrics();
        
        usort($metrics, function($a, $b) {
            return $b['avg_time'] <=> $a['avg_time'];
        });
        
        return array_slice($metrics, 0, $limit);
    }
    
    /**
     * Reset metrics
     */
    public function reset_metrics() {
        delete_option($this->metrics_option);
    }
}
