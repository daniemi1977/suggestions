<?php
/**
 * IPV WooCommerce Integration
 * Associa video a prodotti WooCommerce
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_WooCommerce {
    
    /**
     * Initialize WooCommerce integration
     */
    public function __construct() {
        // Add video tab to product page
        add_filter('woocommerce_product_tabs', array($this, 'add_video_tab'));
        
        // Add video metabox to product edit page
        add_action('add_meta_boxes', array($this, 'add_product_video_metabox'));
        add_action('save_post_product', array($this, 'save_product_video_metabox'));
        
        // Add video column to products list
        add_filter('manage_product_posts_columns', array($this, 'add_video_column'));
        add_action('manage_product_posts_custom_column', array($this, 'render_video_column'), 10, 2);
    }
    
    /**
     * Add video tab to product page
     */
    public function add_video_tab($tabs) {
        global $post;
        
        $video_id = get_post_meta($post->ID, '_ipv_product_video', true);
        
        if ($video_id) {
            $tabs['ipv_video'] = array(
                'title' => '🎬 Video',
                'priority' => 50,
                'callback' => array($this, 'render_video_tab_content'),
            );
        }
        
        return $tabs;
    }
    
    /**
     * Render video tab content
     */
    public function render_video_tab_content() {
        global $post;
        
        $video_id = get_post_meta($post->ID, '_ipv_product_video', true);
        
        if (!$video_id) {
            return;
        }
        
        $video = get_post($video_id);
        $youtube_id = get_post_meta($video_id, '_ipv_youtube_id', true);
        
        ?>
        <div class="ipv-woo-video-tab">
            <h2><?php echo esc_html($video->post_title); ?></h2>
            
            <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; margin: 20px 0;">
                <iframe 
                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
                    src="https://www.youtube.com/embed/<?php echo esc_attr($youtube_id); ?>" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
            
            <div class="ipv-video-description">
                <?php echo wpautop($video->post_content); ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Add video metabox to product
     */
    public function add_product_video_metabox() {
        add_meta_box(
            'ipv_product_video',
            '🎬 IPV Product Video',
            array($this, 'render_product_video_metabox'),
            'product',
            'side',
            'default'
        );
    }
    
    /**
     * Render product video metabox
     */
    public function render_product_video_metabox($post) {
        wp_nonce_field('ipv_product_video_nonce', 'ipv_product_video_nonce');
        
        $selected_video = get_post_meta($post->ID, '_ipv_product_video', true);
        
        $videos = get_posts(array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        ?>
        <p>
            <label for="ipv_product_video">Select video for this product:</label>
            <select name="ipv_product_video" id="ipv_product_video" style="width: 100%;">
                <option value="">No video</option>
                <?php foreach ($videos as $video): ?>
                    <option value="<?php echo $video->ID; ?>" <?php selected($selected_video, $video->ID); ?>>
                        <?php echo esc_html($video->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        
        <?php if ($selected_video): ?>
            <p>
                <a href="<?php echo get_permalink($selected_video); ?>" target="_blank" class="button">
                    View Video
                </a>
            </p>
        <?php endif; ?>
        <?php
    }
    
    /**
     * Save product video metabox
     */
    public function save_product_video_metabox($post_id) {
        if (!isset($_POST['ipv_product_video_nonce']) || 
            !wp_verify_nonce($_POST['ipv_product_video_nonce'], 'ipv_product_video_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        $video_id = isset($_POST['ipv_product_video']) ? intval($_POST['ipv_product_video']) : 0;
        
        if ($video_id) {
            update_post_meta($post_id, '_ipv_product_video', $video_id);
        } else {
            delete_post_meta($post_id, '_ipv_product_video');
        }
    }
    
    /**
     * Add video column to products list
     */
    public function add_video_column($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $title) {
            $new_columns[$key] = $title;
            
            if ($key === 'product_cat') {
                $new_columns['ipv_video'] = '🎬 Video';
            }
        }
        
        return $new_columns;
    }
    
    /**
     * Render video column
     */
    public function render_video_column($column, $post_id) {
        if ($column === 'ipv_video') {
            $video_id = get_post_meta($post_id, '_ipv_product_video', true);
            
            if ($video_id) {
                $video = get_post($video_id);
                echo '<a href="' . get_permalink($video_id) . '" target="_blank">✅ ' . esc_html($video->post_title) . '</a>';
            } else {
                echo '—';
            }
        }
    }
    
    /**
     * Check if WooCommerce is active
     */
    public static function is_woocommerce_active() {
        return class_exists('WooCommerce');
    }
}

// Initialize if WooCommerce is active
if (class_exists('WooCommerce')) {
    new IPV_WooCommerce();
}
