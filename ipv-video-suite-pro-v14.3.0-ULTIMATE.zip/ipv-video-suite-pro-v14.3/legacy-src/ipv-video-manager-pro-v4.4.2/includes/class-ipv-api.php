<?php
/**
 * IPV API Class
 * Gestisce le chiamate alle API Supadata per import video e trascrizioni
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_API {
    
    private $supadata_key;
    private $api_base_url = 'https://api.supadata.ai/v1';
    private $cache; // STEP 3A: Cache instance
    
    public function __construct() {
        $this->supadata_key = get_option('ipv_supadata_api_key', '');
        $this->cache = new IPV_Cache(); // STEP 3A: Initialize cache
    }
    
    /**
     * Import singolo video
     * 
     * @param string $url URL del video YouTube
     * @param int $post_id ID del post (0 per nuovo post)
     * @return array|WP_Error
     */
    public function import_video($url, $post_id = 0) {
        if (empty($this->supadata_key)) {
            return new WP_Error('no_api_key', 'Supadata API key non configurata');
        }
        
        // Estrai video ID dall'URL
        $video_id = $this->extract_video_id($url);
        if (!$video_id) {
            return new WP_Error('invalid_url', 'URL YouTube non valido');
        }
        
        // 1. Ottieni metadata video
        $metadata = $this->get_video_metadata($video_id);
        if (is_wp_error($metadata)) {
            return $metadata;
        }
        
        // 2. Controlla se è uno Short (durata < 60s)
        $is_short = $metadata['duration'] < 60;
        
        // 3. Ottieni trascrizione
        $transcript = $this->get_transcript($url);
        if (is_wp_error($transcript)) {
            return $transcript;
        }
        
        // 4. Crea o aggiorna post
        $post_data = array(
            'post_title' => $metadata['title'],
            'post_type' => 'ipv_video',
            'post_status' => $is_short ? 'draft' : 'publish', // Short in bozza
        );
        
        if ($post_id > 0) {
            $post_data['ID'] = $post_id;
            $post_id = wp_update_post($post_data);
        } else {
            $post_id = wp_insert_post($post_data);
        }
        
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        
        // 5. Salva metadata
        update_post_meta($post_id, '_ipv_youtube_id', $video_id);
        update_post_meta($post_id, '_ipv_youtube_url', $url);
        update_post_meta($post_id, '_ipv_thumbnail_url', $metadata['thumbnail']);
        update_post_meta($post_id, '_ipv_duration', $metadata['duration']);
        update_post_meta($post_id, '_ipv_view_count', $metadata['viewCount']);
        update_post_meta($post_id, '_ipv_upload_date', $metadata['uploadDate']);
        update_post_meta($post_id, '_ipv_source', 'YouTube');
        
        // FIX: Gestisci transcript sia come array che come stringa
        $transcript_content = '';
        if (is_array($transcript)) {
            if (isset($transcript['content'])) {
                $transcript_content = $transcript['content'];
            } elseif (isset($transcript['text'])) {
                $transcript_content = $transcript['text'];
            } elseif (isset($transcript['transcript'])) {
                $transcript_content = $transcript['transcript'];
            } else {
                // Se è un array senza chiavi note, serializza per debug
                $transcript_content = wp_json_encode($transcript);
            }
        } else {
            $transcript_content = (string) $transcript;
        }
        
        update_post_meta($post_id, '_ipv_transcript', $transcript_content);
        
        // 6. Scarica e imposta featured image
        $this->set_featured_image($post_id, $metadata['thumbnail']);
        
        // 7. Se NON è uno Short, genera contenuti automaticamente
        if (!$is_short) {
            $openai = new IPV_OpenAI();
            $openai->generate_content($transcript['content'], $post_id);
        }
        
        return array(
            'post_id' => $post_id,
            'title' => $metadata['title'],
            'duration' => $metadata['duration'],
            'is_short' => $is_short,
            'status' => $is_short ? 'draft' : 'publish',
            'message' => $is_short ? 'Video importato in bozza (Short)' : 'Video importato e pubblicato',
        );
    }
    
    /**
     * Import batch di 10 video dal canale
     * 
     * @param int $limit Numero di video da importare
     * @return array|WP_Error
     */
    public function batch_import($limit = 10) {
        if (empty($this->supadata_key)) {
            return new WP_Error('no_api_key', 'Supadata API key non configurata');
        }
        
        $channel_url = get_option('ipv_channel_url', 'https://www.youtube.com/@ilpuntodivista/streams');
        
        // Ottieni lista video dal canale
        $video_ids = $this->get_channel_videos($channel_url, $limit);
        
        if (is_wp_error($video_ids)) {
            return $video_ids;
        }
        
        $results = array(
            'success' => 0,
            'errors' => 0,
            'skipped' => 0,
            'details' => array(),
        );
        
        foreach ($video_ids as $video_id) {
            // Controlla se video già importato
            $existing = $this->get_post_by_video_id($video_id);
            if ($existing) {
                $results['skipped']++;
                $results['details'][] = array(
                    'video_id' => $video_id,
                    'status' => 'skipped',
                    'message' => 'Video già importato',
                );
                continue;
            }
            
            // Import video
            $url = 'https://www.youtube.com/watch?v=' . $video_id;
            $result = $this->import_video($url);
            
            if (is_wp_error($result)) {
                $results['errors']++;
                $results['details'][] = array(
                    'video_id' => $video_id,
                    'status' => 'error',
                    'message' => $result->get_error_message(),
                );
            } else {
                $results['success']++;
                $results['details'][] = array(
                    'video_id' => $video_id,
                    'status' => 'success',
                    'post_id' => $result['post_id'],
                    'title' => $result['title'],
                );
            }
            
            // Pausa tra le richieste per evitare rate limiting
            sleep(2);
        }
        
        return $results;
    }
    
    /**
     * Ottieni metadata video da Supadata
     * 
     * @param string $video_id ID del video YouTube
     * @return array|WP_Error
     */
    private function get_video_metadata($video_id) {
        // STEP 3A: Check cache first
        $cached = $this->cache->get_video_metadata($video_id);
        if ($cached !== false) {
            $this->cache->increment_hit();
            return $cached;
        }
        
        $this->cache->increment_miss();
        
        $url = $this->api_base_url . '/youtube/video?id=' . urlencode($video_id);
        
        $response = wp_remote_get($url, array(
            'headers' => array(
                'x-api-key' => $this->supadata_key,
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['error'])) {
            return new WP_Error('api_error', $data['error']);
        }
        
        // STEP 3A: Cache the result
        $this->cache->cache_video_metadata($video_id, $data);
        
        return $data;
    }
    
    /**
     * Ottieni trascrizione da Supadata
     * 
     * @param string $url URL del video
     * @return array|WP_Error
     */
    private function get_transcript($url) {
        $api_url = $this->api_base_url . '/transcript?url=' . urlencode($url) . '&text=true&mode=auto';
        
        $response = wp_remote_get($api_url, array(
            'headers' => array(
                'x-api-key' => $this->supadata_key,
            ),
            'timeout' => 60,
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // Se ritorna 202, è un job asincrono
        if ($status_code === 202 && isset($data['jobId'])) {
            return $this->poll_transcript_job($data['jobId']);
        }
        
        if (isset($data['error'])) {
            return new WP_Error('api_error', $data['error']);
        }
        
        return $data;
    }
    
    /**
     * Poll job asincrono per trascrizione
     * 
     * @param string $job_id ID del job
     * @return array|WP_Error
     */
    private function poll_transcript_job($job_id) {
        $max_attempts = 30; // Max 5 minuti (30 * 10 secondi)
        $attempt = 0;
        
        while ($attempt < $max_attempts) {
            sleep(10); // Attendi 10 secondi
            
            $url = $this->api_base_url . '/transcript/' . $job_id;
            
            $response = wp_remote_get($url, array(
                'headers' => array(
                    'x-api-key' => $this->supadata_key,
                ),
                'timeout' => 30,
            ));
            
            if (is_wp_error($response)) {
                return $response;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (isset($data['status'])) {
                if ($data['status'] === 'completed') {
                    return $data;
                } elseif ($data['status'] === 'failed') {
                    return new WP_Error('job_failed', 'Generazione trascrizione fallita');
                }
            }
            
            $attempt++;
        }
        
        return new WP_Error('timeout', 'Timeout durante l\'attesa della trascrizione');
    }
    
    /**
     * Ottieni lista video dal canale
     * 
     * @param string $channel_url URL del canale
     * @param int $limit Numero massimo di video
     * @return array|WP_Error
     */
    private function get_channel_videos($channel_url, $limit = 10) {
        $url = $this->api_base_url . '/youtube/channel/videos?id=' . urlencode($channel_url) . '&type=all&limit=' . $limit;
        
        $response = wp_remote_get($url, array(
            'headers' => array(
                'x-api-key' => $this->supadata_key,
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['error'])) {
            return new WP_Error('api_error', $data['error']);
        }
        
        // Restituisci solo video normali (non shorts né live)
        return isset($data['videoIds']) ? $data['videoIds'] : array();
    }
    
    /**
     * Estrai video ID da URL YouTube
     * 
     * @param string $url URL del video
     * @return string|false
     */
    private function extract_video_id($url) {
        $pattern = '/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/ ]{11})/i';
        
        if (preg_match($pattern, $url, $matches)) {
            return $matches[1];
        }
        
        return false;
    }
    
    /**
     * Cerca post esistente tramite video ID
     * 
     * @param string $video_id Video ID
     * @return int|false ID del post o false
     */
    private function get_post_by_video_id($video_id) {
        $args = array(
            'post_type' => 'ipv_video',
            'meta_key' => '_ipv_youtube_id',
            'meta_value' => $video_id,
            'posts_per_page' => 1,
            'fields' => 'ids',
        );
        
        $posts = get_posts($args);
        
        return !empty($posts) ? $posts[0] : false;
    }
    
    /**
     * Imposta featured image da URL
     * 
     * @param int $post_id ID del post
     * @param string $image_url URL dell'immagine
     * @return bool
     */
    private function set_featured_image($post_id, $image_url) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $tmp = download_url($image_url);
        
        if (is_wp_error($tmp)) {
            return false;
        }
        
        $file_array = array(
            'name' => basename($image_url),
            'tmp_name' => $tmp,
        );
        
        $id = media_handle_sideload($file_array, $post_id);
        
        if (is_wp_error($id)) {
            @unlink($file_array['tmp_name']);
            return false;
        }
        
        set_post_thumbnail($post_id, $id);
        
        return true;
    }
}
