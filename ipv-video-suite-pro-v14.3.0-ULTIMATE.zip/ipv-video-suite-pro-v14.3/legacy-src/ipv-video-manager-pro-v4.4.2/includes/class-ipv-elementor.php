<?php
/**
 * IPV Elementor Integration
 * Widget Elementor per visualizzare video
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Elementor {
    
    /**
     * Initialize Elementor integration
     */
    public function __construct() {
        add_action('elementor/widgets/register', array($this, 'register_widgets'));
        add_action('elementor/elements/categories_registered', array($this, 'add_category'));
    }
    
    /**
     * Add IPV category to Elementor
     */
    public function add_category($elements_manager) {
        $elements_manager->add_category(
            'ipv-video-manager',
            array(
                'title' => 'IPV Video Manager',
                'icon' => 'fa fa-video',
            )
        );
    }
    
    /**
     * Register widgets
     */
    public function register_widgets($widgets_manager) {
        require_once IPV_VM_PLUGIN_DIR . 'integrations/elementor/widgets/video-player.php';
        require_once IPV_VM_PLUGIN_DIR . 'integrations/elementor/widgets/video-grid.php';
        require_once IPV_VM_PLUGIN_DIR . 'integrations/elementor/widgets/video-list.php';
        
        $widgets_manager->register(new \IPV_Elementor_Video_Player());
        $widgets_manager->register(new \IPV_Elementor_Video_Grid());
        $widgets_manager->register(new \IPV_Elementor_Video_List());
    }
    
    /**
     * Check if Elementor is active
     */
    public static function is_elementor_active() {
        return did_action('elementor/loaded');
    }
}

// Initialize if Elementor is active
if (did_action('elementor/loaded')) {
    new IPV_Elementor();
}
