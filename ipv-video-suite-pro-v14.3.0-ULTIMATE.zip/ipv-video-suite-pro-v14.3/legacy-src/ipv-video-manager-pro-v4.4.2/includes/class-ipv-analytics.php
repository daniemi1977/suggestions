<?php
/**
 * IPV Analytics
 * Sistema di analytics e statistiche per video
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Analytics {
    
    /**
     * Get dashboard stats
     * 
     * @return array
     */
    public function get_dashboard_stats() {
        $stats = array(
            'total_videos' => $this->get_total_videos(),
            'total_views' => $this->get_total_views(),
            'published_this_month' => $this->get_videos_this_month(),
            'avg_views_per_video' => $this->get_avg_views(),
            'top_performing' => $this->get_top_videos(5),
            'recent_activity' => $this->get_recent_activity(10),
            'views_trend' => $this->get_views_trend(30),
            'publishing_frequency' => $this->get_publishing_frequency(),
        );
        
        return $stats;
    }
    
    /**
     * Get total videos count
     * 
     * @return int
     */
    public function get_total_videos() {
        $count = wp_count_posts('ipv_video');
        return $count->publish + $count->draft;
    }
    
    /**
     * Get total views across all videos
     * 
     * @return int
     */
    public function get_total_views() {
        global $wpdb;
        
        $total = $wpdb->get_var("
            SELECT SUM(CAST(meta_value AS UNSIGNED)) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_ipv_view_count'
        ");
        
        return intval($total);
    }
    
    /**
     * Get videos published this month
     * 
     * @return int
     */
    public function get_videos_this_month() {
        $args = array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'date_query' => array(
                array(
                    'after' => '1 month ago',
                ),
            ),
            'posts_per_page' => -1,
        );
        
        $query = new WP_Query($args);
        return $query->found_posts;
    }
    
    /**
     * Get average views per video
     * 
     * @return float
     */
    public function get_avg_views() {
        $total_videos = $this->get_total_videos();
        
        if ($total_videos === 0) {
            return 0;
        }
        
        $total_views = $this->get_total_views();
        return round($total_views / $total_videos, 2);
    }
    
    /**
     * Get top performing videos
     * 
     * @param int $limit Number of videos
     * @return array
     */
    public function get_top_videos($limit = 10) {
        $args = array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'meta_key' => '_ipv_view_count',
            'orderby' => 'meta_value_num',
            'order' => 'DESC',
        );
        
        $videos = get_posts($args);
        $results = array();
        
        foreach ($videos as $video) {
            $results[] = array(
                'id' => $video->ID,
                'title' => $video->post_title,
                'views' => get_post_meta($video->ID, '_ipv_view_count', true),
                'url' => get_permalink($video->ID),
                'youtube_url' => get_post_meta($video->ID, '_ipv_youtube_url', true),
                'published' => $video->post_date,
            );
        }
        
        return $results;
    }
    
    /**
     * Get recent activity
     * 
     * @param int $limit Number of items
     * @return array
     */
    public function get_recent_activity($limit = 10) {
        $args = array(
            'post_type' => 'ipv_video',
            'post_status' => array('publish', 'draft'),
            'posts_per_page' => $limit,
            'orderby' => 'modified',
            'order' => 'DESC',
        );
        
        $videos = get_posts($args);
        $activity = array();
        
        foreach ($videos as $video) {
            $activity[] = array(
                'id' => $video->ID,
                'title' => $video->post_title,
                'status' => $video->post_status,
                'modified' => $video->post_modified,
                'action' => $this->get_last_action($video->ID),
            );
        }
        
        return $activity;
    }
    
    /**
     * Get last action on video
     * 
     * @param int $post_id Post ID
     * @return string
     */
    private function get_last_action($post_id) {
        $post = get_post($post_id);
        
        if ($post->post_status === 'draft') {
            return 'Saved as draft';
        }
        
        if ($post->post_date === $post->post_modified) {
            return 'Published';
        }
        
        return 'Updated';
    }
    
    /**
     * Get views trend for last N days
     * 
     * @param int $days Number of days
     * @return array
     */
    public function get_views_trend($days = 30) {
        global $wpdb;
        
        $trend = array();
        
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-{$i} days"));
            
            // Get videos published on this day
            $videos = get_posts(array(
                'post_type' => 'ipv_video',
                'post_status' => 'publish',
                'date_query' => array(
                    array(
                        'year' => date('Y', strtotime($date)),
                        'month' => date('m', strtotime($date)),
                        'day' => date('d', strtotime($date)),
                    ),
                ),
                'posts_per_page' => -1,
            ));
            
            $total_views = 0;
            foreach ($videos as $video) {
                $views = get_post_meta($video->ID, '_ipv_view_count', true);
                $total_views += intval($views);
            }
            
            $trend[] = array(
                'date' => $date,
                'views' => $total_views,
                'videos_published' => count($videos),
            );
        }
        
        return $trend;
    }
    
    /**
     * Get publishing frequency stats
     * 
     * @return array
     */
    public function get_publishing_frequency() {
        global $wpdb;
        
        $frequency = array(
            'daily' => array(),
            'weekly' => 0,
            'monthly' => 0,
        );
        
        // Last 7 days
        for ($i = 6; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-{$i} days"));
            $day_name = date('D', strtotime($date));
            
            $count = get_posts(array(
                'post_type' => 'ipv_video',
                'post_status' => 'publish',
                'date_query' => array(
                    array(
                        'year' => date('Y', strtotime($date)),
                        'month' => date('m', strtotime($date)),
                        'day' => date('d', strtotime($date)),
                    ),
                ),
                'posts_per_page' => -1,
                'fields' => 'ids',
            ));
            
            $frequency['daily'][] = array(
                'day' => $day_name,
                'count' => count($count),
            );
        }
        
        // Last week
        $frequency['weekly'] = get_posts(array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'date_query' => array(
                array(
                    'after' => '1 week ago',
                ),
            ),
            'posts_per_page' => -1,
            'fields' => 'ids',
        ));
        $frequency['weekly'] = count($frequency['weekly']);
        
        // Last month
        $frequency['monthly'] = $this->get_videos_this_month();
        
        return $frequency;
    }
    
    /**
     * Get SEO score for video
     * 
     * @param int $post_id Post ID
     * @return array
     */
    public function get_seo_score($post_id) {
        $score = 0;
        $max_score = 100;
        $checks = array();
        
        $title = get_the_title($post_id);
        $content = get_post_field('post_content', $post_id);
        $excerpt = get_post_field('post_excerpt', $post_id);
        
        // Title length (10 points)
        if (strlen($title) >= 30 && strlen($title) <= 60) {
            $score += 10;
            $checks['title_length'] = array('status' => 'good', 'message' => 'Title length optimal');
        } else {
            $checks['title_length'] = array('status' => 'warning', 'message' => 'Title should be 30-60 characters');
        }
        
        // Has excerpt (10 points)
        if (!empty($excerpt)) {
            $score += 10;
            $checks['excerpt'] = array('status' => 'good', 'message' => 'Excerpt present');
        } else {
            $checks['excerpt'] = array('status' => 'warning', 'message' => 'Add an excerpt');
        }
        
        // Content length (15 points)
        if (strlen($content) >= 300) {
            $score += 15;
            $checks['content_length'] = array('status' => 'good', 'message' => 'Content length good');
        } else {
            $checks['content_length'] = array('status' => 'warning', 'message' => 'Content should be at least 300 characters');
        }
        
        // Has thumbnail (15 points)
        $thumbnail = get_post_meta($post_id, '_ipv_thumbnail_url', true);
        if (!empty($thumbnail)) {
            $score += 15;
            $checks['thumbnail'] = array('status' => 'good', 'message' => 'Thumbnail present');
        } else {
            $checks['thumbnail'] = array('status' => 'warning', 'message' => 'Add a thumbnail');
        }
        
        // Has video embedded (20 points)
        $youtube_id = get_post_meta($post_id, '_ipv_youtube_id', true);
        if (!empty($youtube_id)) {
            $score += 20;
            $checks['video'] = array('status' => 'good', 'message' => 'Video embedded');
        } else {
            $checks['video'] = array('status' => 'error', 'message' => 'No video embedded');
        }
        
        // Has categories (10 points)
        $categories = wp_get_post_categories($post_id);
        if (count($categories) > 0) {
            $score += 10;
            $checks['categories'] = array('status' => 'good', 'message' => 'Categories assigned');
        } else {
            $checks['categories'] = array('status' => 'warning', 'message' => 'Add categories');
        }
        
        // Has tags (10 points)
        $tags = wp_get_post_tags($post_id);
        if (count($tags) > 0) {
            $score += 10;
            $checks['tags'] = array('status' => 'good', 'message' => 'Tags assigned');
        } else {
            $checks['tags'] = array('status' => 'warning', 'message' => 'Add tags');
        }
        
        // Published status (10 points)
        $status = get_post_status($post_id);
        if ($status === 'publish') {
            $score += 10;
            $checks['status'] = array('status' => 'good', 'message' => 'Published');
        } else {
            $checks['status'] = array('status' => 'warning', 'message' => 'Not published');
        }
        
        return array(
            'score' => $score,
            'max_score' => $max_score,
            'percentage' => round(($score / $max_score) * 100),
            'grade' => $this->get_grade($score, $max_score),
            'checks' => $checks,
        );
    }
    
    /**
     * Get grade from score
     * 
     * @param int $score Score
     * @param int $max_score Max score
     * @return string
     */
    private function get_grade($score, $max_score) {
        $percentage = ($score / $max_score) * 100;
        
        if ($percentage >= 90) return 'A+';
        if ($percentage >= 80) return 'A';
        if ($percentage >= 70) return 'B';
        if ($percentage >= 60) return 'C';
        if ($percentage >= 50) return 'D';
        return 'F';
    }
    
    /**
     * Get API costs estimate
     * 
     * @return array
     */
    public function get_api_costs() {
        $total_videos = $this->get_total_videos();
        
        // Supadata costs (estimate)
        $supadata_cost_per_video = 0.05; // $0.05 per video
        $supadata_total = $total_videos * $supadata_cost_per_video;
        
        // OpenAI costs (estimate based on tokens)
        $openai_cost_per_video = 0.10; // $0.10 per video (GPT-4)
        $openai_total = $total_videos * $openai_cost_per_video;
        
        return array(
            'supadata' => array(
                'cost_per_video' => $supadata_cost_per_video,
                'total' => $supadata_total,
                'videos' => $total_videos,
            ),
            'openai' => array(
                'cost_per_video' => $openai_cost_per_video,
                'total' => $openai_total,
                'videos' => $total_videos,
            ),
            'total' => $supadata_total + $openai_total,
            'monthly_estimate' => ($supadata_cost_per_video + $openai_cost_per_video) * $this->get_videos_this_month(),
        );
    }
    
    /**
     * Get calendar data for publishing schedule
     * 
     * @param string $month Month in Y-m format
     * @return array
     */
    public function get_calendar_data($month = null) {
        if (!$month) {
            $month = date('Y-m');
        }
        
        $year = date('Y', strtotime($month . '-01'));
        $month_num = date('m', strtotime($month . '-01'));
        
        $args = array(
            'post_type' => 'ipv_video',
            'post_status' => array('publish', 'draft', 'future'),
            'date_query' => array(
                array(
                    'year' => $year,
                    'month' => $month_num,
                ),
            ),
            'posts_per_page' => -1,
        );
        
        $videos = get_posts($args);
        $calendar = array();
        
        foreach ($videos as $video) {
            $day = date('d', strtotime($video->post_date));
            
            if (!isset($calendar[$day])) {
                $calendar[$day] = array();
            }
            
            $calendar[$day][] = array(
                'id' => $video->ID,
                'title' => $video->post_title,
                'status' => $video->post_status,
                'time' => date('H:i', strtotime($video->post_date)),
            );
        }
        
        return $calendar;
    }
}
