<?php
/**
 * IPV Queue Manager
 * Sistema di code per operazioni batch in background
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Queue {
    
    private $queue_option = 'ipv_processing_queue';
    private $max_batch_size = 5;
    
    /**
     * Add item to queue
     * 
     * @param string $type Operation type
     * @param array $data Operation data
     * @return bool
     */
    public function add($type, $data) {
        $queue = $this->get_queue();
        
        $item = array(
            'id' => uniqid('ipv_', true),
            'type' => $type,
            'data' => $data,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
            'attempts' => 0,
            'error' => null,
        );
        
        $queue[] = $item;
        
        return update_option($this->queue_option, $queue);
    }
    
    /**
     * Add multiple items to queue
     * 
     * @param string $type Operation type
     * @param array $items Array of data items
     * @return int Number of items added
     */
    public function add_bulk($type, $items) {
        $added = 0;
        
        foreach ($items as $data) {
            if ($this->add($type, $data)) {
                $added++;
            }
        }
        
        return $added;
    }
    
    /**
     * Get queue
     * 
     * @return array
     */
    public function get_queue() {
        $queue = get_option($this->queue_option, array());
        
        if (!is_array($queue)) {
            $queue = array();
        }
        
        return $queue;
    }
    
    /**
     * Get next pending items
     * 
     * @param int $limit Max items to return
     * @return array
     */
    public function get_pending($limit = null) {
        if ($limit === null) {
            $limit = $this->max_batch_size;
        }
        
        $queue = $this->get_queue();
        $pending = array();
        
        foreach ($queue as $item) {
            if ($item['status'] === 'pending' && count($pending) < $limit) {
                $pending[] = $item;
            }
        }
        
        return $pending;
    }
    
    /**
     * Process queue
     * 
     * @return array Results
     */
    public function process() {
        $items = $this->get_pending();
        $results = array(
            'processed' => 0,
            'failed' => 0,
            'errors' => array(),
        );
        
        foreach ($items as $item) {
            $result = $this->process_item($item);
            
            if ($result['success']) {
                $results['processed']++;
                $this->mark_completed($item['id'], $result['data']);
            } else {
                $results['failed']++;
                $results['errors'][] = array(
                    'item_id' => $item['id'],
                    'error' => $result['error'],
                );
                $this->mark_failed($item['id'], $result['error']);
            }
        }
        
        return $results;
    }
    
    /**
     * Process single queue item
     * 
     * @param array $item Queue item
     * @return array
     */
    private function process_item($item) {
        try {
            switch ($item['type']) {
                case 'import_video':
                    return $this->process_import_video($item['data']);
                    
                case 'generate_content':
                    return $this->process_generate_content($item['data']);
                    
                case 'regenerate_thumbnails':
                    return $this->process_regenerate_thumbnails($item['data']);
                    
                case 'regenerate_descriptions':
                    return $this->process_regenerate_descriptions($item['data']);
                    
                default:
                    return array(
                        'success' => false,
                        'error' => 'Unknown operation type: ' . $item['type'],
                    );
            }
        } catch (Exception $e) {
            return array(
                'success' => false,
                'error' => $e->getMessage(),
            );
        }
    }
    
    /**
     * Process import video
     * 
     * @param array $data Data
     * @return array
     */
    private function process_import_video($data) {
        $api = new IPV_API();
        $result = $api->import_video($data['url']);
        
        if (is_wp_error($result)) {
            return array(
                'success' => false,
                'error' => $result->get_error_message(),
            );
        }
        
        return array(
            'success' => true,
            'data' => $result,
        );
    }
    
    /**
     * Process generate content
     * 
     * @param array $data Data
     * @return array
     */
    private function process_generate_content($data) {
        $post_id = $data['post_id'];
        $transcript = get_post_meta($post_id, '_ipv_transcript', true);
        $transcript = ipv_normalize_transcript($transcript);
        
        if (empty($transcript)) {
            return array(
                'success' => false,
                'error' => 'No transcript available',
            );
        }
        
        $openai = new IPV_OpenAI();
        $result = $openai->generate_content($transcript, $post_id);
        
        if (is_wp_error($result)) {
            return array(
                'success' => false,
                'error' => $result->get_error_message(),
            );
        }
        
        return array(
            'success' => true,
            'data' => $result,
        );
    }
    
    /**
     * Process regenerate thumbnails
     * 
     * @param array $data Data
     * @return array
     */
    private function process_regenerate_thumbnails($data) {
        // TODO: Implement thumbnail regeneration
        return array(
            'success' => true,
            'data' => array('message' => 'Thumbnail regenerated'),
        );
    }
    
    /**
     * Process regenerate descriptions
     * 
     * @param array $data Data
     * @return array
     */
    private function process_regenerate_descriptions($data) {
        return $this->process_generate_content($data);
    }
    
    /**
     * Mark item as completed
     * 
     * @param string $item_id Item ID
     * @param mixed $result Result data
     */
    public function mark_completed($item_id, $result = null) {
        $queue = $this->get_queue();
        
        foreach ($queue as $key => $item) {
            if ($item['id'] === $item_id) {
                $queue[$key]['status'] = 'completed';
                $queue[$key]['completed_at'] = current_time('mysql');
                $queue[$key]['result'] = $result;
                break;
            }
        }
        
        update_option($this->queue_option, $queue);
    }
    
    /**
     * Mark item as failed
     * 
     * @param string $item_id Item ID
     * @param string $error Error message
     */
    public function mark_failed($item_id, $error) {
        $queue = $this->get_queue();
        
        foreach ($queue as $key => $item) {
            if ($item['id'] === $item_id) {
                $queue[$key]['attempts']++;
                
                // Se ha superato i tentativi, marca come failed definitivo
                if ($queue[$key]['attempts'] >= 3) {
                    $queue[$key]['status'] = 'failed';
                    $queue[$key]['failed_at'] = current_time('mysql');
                } else {
                    $queue[$key]['status'] = 'pending'; // Riprova
                }
                
                $queue[$key]['error'] = $error;
                break;
            }
        }
        
        update_option($this->queue_option, $queue);
    }
    
    /**
     * Clear completed items
     * 
     * @return int Number of items cleared
     */
    public function clear_completed() {
        $queue = $this->get_queue();
        $cleared = 0;
        
        $queue = array_filter($queue, function($item) use (&$cleared) {
            if ($item['status'] === 'completed') {
                $cleared++;
                return false;
            }
            return true;
        });
        
        update_option($this->queue_option, array_values($queue));
        
        return $cleared;
    }
    
    /**
     * Get queue stats
     * 
     * @return array
     */
    public function get_stats() {
        $queue = $this->get_queue();
        
        $stats = array(
            'total' => count($queue),
            'pending' => 0,
            'processing' => 0,
            'completed' => 0,
            'failed' => 0,
        );
        
        foreach ($queue as $item) {
            if (isset($item['status'])) {
                $stats[$item['status']]++;
            }
        }
        
        return $stats;
    }
    
    /**
     * Clear entire queue
     */
    public function clear_all() {
        delete_option($this->queue_option);
    }
}
