<?php
/**
 * IPV Cache Manager
 * Sistema di cache avanzato per API calls e contenuti
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Cache {
    
    private $cache_group = 'ipv_video_manager';
    private $cache_duration = 3600; // 1 ora default
    
    /**
     * Get cache
     * 
     * @param string $key Cache key
     * @return mixed|false
     */
    public function get($key) {
        $cache_key = $this->build_key($key);
        return wp_cache_get($cache_key, $this->cache_group);
    }
    
    /**
     * Set cache
     * 
     * @param string $key Cache key
     * @param mixed $data Data to cache
     * @param int $expiration Expiration time in seconds (default 1 hour)
     * @return bool
     */
    public function set($key, $data, $expiration = null) {
        if ($expiration === null) {
            $expiration = $this->cache_duration;
        }
        
        $cache_key = $this->build_key($key);
        return wp_cache_set($cache_key, $data, $this->cache_group, $expiration);
    }
    
    /**
     * Delete cache
     * 
     * @param string $key Cache key
     * @return bool
     */
    public function delete($key) {
        $cache_key = $this->build_key($key);
        return wp_cache_delete($cache_key, $this->cache_group);
    }
    
    /**
     * Flush all cache
     * 
     * @return bool
     */
    public function flush() {
        return wp_cache_flush();
    }
    
    /**
     * Get cached API response
     * 
     * @param string $url API URL
     * @param array $params Query parameters
     * @return mixed|false
     */
    public function get_api_response($url, $params = array()) {
        $key = 'api_' . md5($url . serialize($params));
        return $this->get($key);
    }
    
    /**
     * Cache API response
     * 
     * @param string $url API URL
     * @param array $params Query parameters
     * @param mixed $response Response data
     * @param int $expiration Cache duration
     * @return bool
     */
    public function cache_api_response($url, $params, $response, $expiration = 3600) {
        $key = 'api_' . md5($url . serialize($params));
        return $this->set($key, $response, $expiration);
    }
    
    /**
     * Get cached transcript
     * 
     * @param string $video_id Video ID
     * @return string|false
     */
    public function get_transcript($video_id) {
        $key = 'transcript_' . $video_id;
        return $this->get($key);
    }
    
    /**
     * Cache transcript
     * 
     * @param string $video_id Video ID
     * @param string $transcript Transcript content
     * @return bool
     */
    public function cache_transcript($video_id, $transcript) {
        $key = 'transcript_' . $video_id;
        // Transcript cache 24 ore
        return $this->set($key, $transcript, 86400);
    }
    
    /**
     * Get cached video metadata
     * 
     * @param string $video_id Video ID
     * @return array|false
     */
    public function get_video_metadata($video_id) {
        $key = 'metadata_' . $video_id;
        return $this->get($key);
    }
    
    /**
     * Cache video metadata
     * 
     * @param string $video_id Video ID
     * @param array $metadata Metadata
     * @return bool
     */
    public function cache_video_metadata($video_id, $metadata) {
        $key = 'metadata_' . $video_id;
        // Metadata cache 12 ore
        return $this->set($key, $metadata, 43200);
    }
    
    /**
     * Build cache key
     * 
     * @param string $key Original key
     * @return string
     */
    private function build_key($key) {
        return sanitize_key($key);
    }
    
    /**
     * Get cache statistics
     * 
     * @return array
     */
    public function get_stats() {
        global $wpdb;
        
        $stats = array(
            'total_cached_items' => 0,
            'cache_hits' => get_option('ipv_cache_hits', 0),
            'cache_misses' => get_option('ipv_cache_misses', 0),
            'cache_size_bytes' => 0,
        );
        
        // Calcola hit rate
        $total = $stats['cache_hits'] + $stats['cache_misses'];
        $stats['hit_rate'] = $total > 0 ? ($stats['cache_hits'] / $total) * 100 : 0;
        
        return $stats;
    }
    
    /**
     * Increment cache hit
     */
    public function increment_hit() {
        $hits = get_option('ipv_cache_hits', 0);
        update_option('ipv_cache_hits', $hits + 1);
    }
    
    /**
     * Increment cache miss
     */
    public function increment_miss() {
        $misses = get_option('ipv_cache_misses', 0);
        update_option('ipv_cache_misses', $misses + 1);
    }
    
    /**
     * Clear video cache
     * 
     * @param int $post_id Post ID
     */
    public function clear_video_cache($post_id) {
        $video_id = get_post_meta($post_id, '_ipv_youtube_id', true);
        
        if ($video_id) {
            $this->delete('transcript_' . $video_id);
            $this->delete('metadata_' . $video_id);
        }
    }
    
    /**
     * Warm cache per i video popolari
     * 
     * @param int $limit Numero di video
     */
    public function warm_cache($limit = 20) {
        $args = array(
            'post_type' => 'ipv_video',
            'posts_per_page' => $limit,
            'orderby' => 'meta_value_num',
            'meta_key' => '_ipv_view_count',
            'order' => 'DESC',
        );
        
        $videos = get_posts($args);
        $warmed = 0;
        
        foreach ($videos as $video) {
            $video_id = get_post_meta($video->ID, '_ipv_youtube_id', true);
            $transcript = get_post_meta($video->ID, '_ipv_transcript', true);
            $transcript = ipv_normalize_transcript($transcript);
            
            if ($video_id && $transcript) {
                $this->cache_transcript($video_id, $transcript);
                $warmed++;
            }
        }
        
        return $warmed;
    }
}
