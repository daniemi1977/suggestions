<?php
/**
 * IPV Gutenberg Integration
 * Custom blocks per Gutenberg editor
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Gutenberg {
    
    /**
     * Initialize Gutenberg integration
     */
    public function __construct() {
        add_action('init', array($this, 'register_blocks'));
        add_action('enqueue_block_editor_assets', array($this, 'enqueue_block_editor_assets'));
    }
    
    /**
     * Register blocks
     */
    public function register_blocks() {
        // Video Player Block
        register_block_type('ipv/video-player', array(
            'render_callback' => array($this, 'render_video_player_block'),
            'attributes' => array(
                'videoId' => array(
                    'type' => 'number',
                    'default' => 0,
                ),
                'autoplay' => array(
                    'type' => 'boolean',
                    'default' => false,
                ),
                'showTitle' => array(
                    'type' => 'boolean',
                    'default' => true,
                ),
                'showDescription' => array(
                    'type' => 'boolean',
                    'default' => true,
                ),
            ),
        ));
        
        // Video Grid Block
        register_block_type('ipv/video-grid', array(
            'render_callback' => array($this, 'render_video_grid_block'),
            'attributes' => array(
                'postsPerPage' => array(
                    'type' => 'number',
                    'default' => 6,
                ),
                'columns' => array(
                    'type' => 'number',
                    'default' => 3,
                ),
                'orderBy' => array(
                    'type' => 'string',
                    'default' => 'date',
                ),
                'order' => array(
                    'type' => 'string',
                    'default' => 'DESC',
                ),
            ),
        ));
    }
    
    /**
     * Enqueue block editor assets
     */
    public function enqueue_block_editor_assets() {
        wp_enqueue_script(
            'ipv-gutenberg-blocks',
            IPV_VM_PLUGIN_URL . 'integrations/gutenberg/blocks.js',
            array('wp-blocks', 'wp-element', 'wp-components', 'wp-editor'),
            IPV_VM_VERSION,
            true
        );
        
        // Pass video options to JS
        wp_localize_script('ipv-gutenberg-blocks', 'ipvVideos', array(
            'videos' => $this->get_video_options(),
        ));
    }
    
    /**
     * Render video player block
     */
    public function render_video_player_block($attributes) {
        $video_id = $attributes['videoId'];
        
        if (empty($video_id)) {
            return '<p>Please select a video</p>';
        }
        
        $video = get_post($video_id);
        $youtube_id = get_post_meta($video_id, '_ipv_youtube_id', true);
        $autoplay = $attributes['autoplay'] ? '1' : '0';
        
        ob_start();
        ?>
        <div class="ipv-video-player-block">
            <?php if ($attributes['showTitle']): ?>
                <h2><?php echo esc_html($video->post_title); ?></h2>
            <?php endif; ?>
            
            <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
                <iframe 
                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
                    src="https://www.youtube.com/embed/<?php echo esc_attr($youtube_id); ?>?autoplay=<?php echo $autoplay; ?>" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
            
            <?php if ($attributes['showDescription']): ?>
                <div style="margin-top: 20px;">
                    <?php echo wpautop($video->post_content); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render video grid block
     */
    public function render_video_grid_block($attributes) {
        $args = array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'posts_per_page' => $attributes['postsPerPage'],
            'orderby' => $attributes['orderBy'],
            'order' => $attributes['order'],
        );
        
        $videos = new WP_Query($args);
        $columns = $attributes['columns'];
        
        ob_start();
        ?>
        <div class="ipv-video-grid-block" style="display: grid; grid-template-columns: repeat(<?php echo $columns; ?>, 1fr); gap: 20px;">
            <?php while ($videos->have_posts()): $videos->the_post(); ?>
                <div style="background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <div style="position: relative; padding-bottom: 56.25%; background: #000;">
                        <?php $thumbnail = get_post_meta(get_the_ID(), '_ipv_thumbnail_url', true); ?>
                        <img src="<?php echo esc_url($thumbnail); ?>" 
                             alt="<?php the_title(); ?>"
                             style="position: absolute; width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div style="padding: 15px;">
                        <h3 style="margin: 0 0 10px 0; font-size: 16px;">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        <div style="font-size: 12px; color: #999;">
                            👁️ <?php echo number_format(get_post_meta(get_the_ID(), '_ipv_view_count', true)); ?> views
                        </div>
                    </div>
                </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get video options
     */
    private function get_video_options() {
        $options = array();
        
        $videos = get_posts(array(
            'post_type' => 'ipv_video',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        foreach ($videos as $video) {
            $options[] = array(
                'value' => $video->ID,
                'label' => $video->post_title,
            );
        }
        
        return $options;
    }
}

new IPV_Gutenberg();
