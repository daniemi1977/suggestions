<?php
/**
 * IPV Notifications
 * Gestisce notifiche via Telegram, Discord, Mailchimp
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Notifications {
    
    /**
     * Initialize notifications
     */
    public function __construct() {
        add_action('transition_post_status', array($this, 'on_video_published'), 10, 3);
    }
    
    /**
     * When video is published
     */
    public function on_video_published($new_status, $old_status, $post) {
        if ($post->post_type !== 'ipv_video') {
            return;
        }
        
        if ($new_status !== 'publish' || $old_status === 'publish') {
            return;
        }
        
        // Send notifications
        $this->send_telegram_notification($post);
        $this->send_discord_notification($post);
        $this->send_mailchimp_campaign($post);
    }
    
    /**
     * Send Telegram notification
     */
    public function send_telegram_notification($post) {
        $telegram_enabled = get_option('ipv_telegram_enabled', '0');
        $telegram_bot_token = get_option('ipv_telegram_bot_token', '');
        $telegram_chat_id = get_option('ipv_telegram_chat_id', '');
        
        if ($telegram_enabled !== '1' || empty($telegram_bot_token) || empty($telegram_chat_id)) {
            return;
        }
        
        $url = get_permalink($post->ID);
        $youtube_url = get_post_meta($post->ID, '_ipv_youtube_url', true);
        
        $message = "🎬 *Nuovo Video Pubblicato!*\n\n";
        $message .= "*" . $post->post_title . "*\n\n";
        $message .= "[Guarda su WordPress](" . $url . ")\n";
        $message .= "[Guarda su YouTube](" . $youtube_url . ")";
        
        $api_url = "https://api.telegram.org/bot{$telegram_bot_token}/sendMessage";
        
        wp_remote_post($api_url, array(
            'body' => array(
                'chat_id' => $telegram_chat_id,
                'text' => $message,
                'parse_mode' => 'Markdown',
                'disable_web_page_preview' => false,
            ),
        ));
    }
    
    /**
     * Send Discord notification
     */
    public function send_discord_notification($post) {
        $discord_enabled = get_option('ipv_discord_enabled', '0');
        $discord_webhook_url = get_option('ipv_discord_webhook_url', '');
        
        if ($discord_enabled !== '1' || empty($discord_webhook_url)) {
            return;
        }
        
        $url = get_permalink($post->ID);
        $youtube_url = get_post_meta($post->ID, '_ipv_youtube_url', true);
        $thumbnail = get_post_meta($post->ID, '_ipv_thumbnail_url', true);
        $views = get_post_meta($post->ID, '_ipv_view_count', true);
        
        $embed = array(
            'title' => $post->post_title,
            'description' => wp_trim_words($post->post_content, 50),
            'url' => $url,
            'color' => 16711680, // Red color
            'thumbnail' => array(
                'url' => $thumbnail,
            ),
            'fields' => array(
                array(
                    'name' => '👁️ Views',
                    'value' => number_format($views),
                    'inline' => true,
                ),
                array(
                    'name' => '📅 Published',
                    'value' => date('M d, Y', strtotime($post->post_date)),
                    'inline' => true,
                ),
            ),
            'footer' => array(
                'text' => 'IPV Video Manager',
            ),
        );
        
        if ($youtube_url) {
            $embed['fields'][] = array(
                'name' => '🔗 YouTube',
                'value' => '[Watch on YouTube](' . $youtube_url . ')',
                'inline' => false,
            );
        }
        
        wp_remote_post($discord_webhook_url, array(
            'body' => wp_json_encode(array(
                'content' => '🎬 **Nuovo Video Pubblicato!**',
                'embeds' => array($embed),
            )),
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
        ));
    }
    
    /**
     * Send Mailchimp campaign
     */
    public function send_mailchimp_campaign($post) {
        $mailchimp_enabled = get_option('ipv_mailchimp_enabled', '0');
        $mailchimp_api_key = get_option('ipv_mailchimp_api_key', '');
        $mailchimp_list_id = get_option('ipv_mailchimp_list_id', '');
        
        if ($mailchimp_enabled !== '1' || empty($mailchimp_api_key) || empty($mailchimp_list_id)) {
            return;
        }
        
        // Extract datacenter from API key
        $datacenter = substr($mailchimp_api_key, strpos($mailchimp_api_key, '-') + 1);
        $api_url = "https://{$datacenter}.api.mailchimp.com/3.0/campaigns";
        
        $url = get_permalink($post->ID);
        $youtube_url = get_post_meta($post->ID, '_ipv_youtube_url', true);
        $thumbnail = get_post_meta($post->ID, '_ipv_thumbnail_url', true);
        
        $content = '<html><body>';
        $content .= '<h1>' . $post->post_title . '</h1>';
        
        if ($thumbnail) {
            $content .= '<img src="' . $thumbnail . '" alt="' . $post->post_title . '" style="max-width: 100%;">';
        }
        
        $content .= '<p>' . wpautop($post->post_content) . '</p>';
        $content .= '<p><a href="' . $url . '" style="background: #ff0000; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Guarda su WordPress</a></p>';
        
        if ($youtube_url) {
            $content .= '<p><a href="' . $youtube_url . '" style="background: #ff0000; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Guarda su YouTube</a></p>';
        }
        
        $content .= '</body></html>';
        
        // Create campaign
        $campaign_data = array(
            'type' => 'regular',
            'recipients' => array(
                'list_id' => $mailchimp_list_id,
            ),
            'settings' => array(
                'subject_line' => '🎬 Nuovo Video: ' . $post->post_title,
                'from_name' => get_bloginfo('name'),
                'reply_to' => get_bloginfo('admin_email'),
                'title' => 'IPV Video: ' . $post->post_title,
            ),
        );
        
        $response = wp_remote_post($api_url, array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key),
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode($campaign_data),
        ));
        
        if (!is_wp_error($response)) {
            $campaign = json_decode(wp_remote_retrieve_body($response), true);
            
            if (isset($campaign['id'])) {
                // Set campaign content
                $content_url = "https://{$datacenter}.api.mailchimp.com/3.0/campaigns/{$campaign['id']}/content";
                
                wp_remote_put($content_url, array(
                    'headers' => array(
                        'Authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key),
                        'Content-Type' => 'application/json',
                    ),
                    'body' => wp_json_encode(array(
                        'html' => $content,
                    )),
                ));
                
                // Send campaign
                $send_url = "https://{$datacenter}.api.mailchimp.com/3.0/campaigns/{$campaign['id']}/actions/send";
                
                wp_remote_post($send_url, array(
                    'headers' => array(
                        'Authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key),
                    ),
                ));
            }
        }
    }
    
    /**
     * Get notification settings for admin page
     */
    public function get_settings() {
        return array(
            'telegram' => array(
                'enabled' => get_option('ipv_telegram_enabled', '0'),
                'bot_token' => get_option('ipv_telegram_bot_token', ''),
                'chat_id' => get_option('ipv_telegram_chat_id', ''),
            ),
            'discord' => array(
                'enabled' => get_option('ipv_discord_enabled', '0'),
                'webhook_url' => get_option('ipv_discord_webhook_url', ''),
            ),
            'mailchimp' => array(
                'enabled' => get_option('ipv_mailchimp_enabled', '0'),
                'api_key' => get_option('ipv_mailchimp_api_key', ''),
                'list_id' => get_option('ipv_mailchimp_list_id', ''),
            ),
        );
    }
}

new IPV_Notifications();
