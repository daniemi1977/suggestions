<?php
/**
 * IPV OpenAI Class
 * Gestisce la generazione di contenuti tramite OpenAI API
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_OpenAI {
    
    private $api_key;
    private $api_url = 'https://api.openai.com/v1/chat/completions';
    
    public function __construct() {
        $this->api_key = get_option('ipv_openai_api_key', '');
    }
    
    /**
     * Genera contenuti da trascrizione
     * 
     * @param string|array $transcript Trascrizione del video
     * @param int $post_id ID del post
     * @return array|WP_Error
     */
    public function generate_content($transcript, $post_id) {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', 'OpenAI API key non configurata');
        }
        
        // Normalizza transcript usando la funzione helper globale
        $transcript = ipv_normalize_transcript($transcript);
        
        if (empty($transcript)) {
            return new WP_Error('no_transcript', 'Trascrizione non disponibile');
        }
        
        // Costruisci il prompt con la trascrizione
        $prompt = $this->build_prompt($transcript);
        
        // Chiama OpenAI API
        $response = wp_remote_post($this->api_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4o',
                'messages' => array(
                    array(
                        'role' => 'system',
                        'content' => 'Sei un assistente esperto nella creazione di contenuti per YouTube per il canale "Il Punto di Vista". Segui ESATTAMENTE le istruzioni fornite e genera contenuti in formato strutturato.',
                    ),
                    array(
                        'role' => 'user',
                        'content' => $prompt,
                    ),
                ),
                'temperature' => 0.7,
                'max_tokens' => 4000,
            )),
            'timeout' => 120,
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['error'])) {
            return new WP_Error('api_error', $data['error']['message']);
        }
        
        if (!isset($data['choices'][0]['message']['content'])) {
            return new WP_Error('invalid_response', 'Risposta OpenAI non valida');
        }
        
        $content = $data['choices'][0]['message']['content'];
        
        // Parsa il contenuto e salva i campi
        $parsed = $this->parse_generated_content($content);
        
        // Salva i campi nel post
        $this->save_generated_fields($post_id, $parsed);
        
        // Aggiorna anche il titolo del post se generato
        if (!empty($parsed['titolo_episodio'])) {
            wp_update_post(array(
                'ID' => $post_id,
                'post_title' => $parsed['titolo_episodio'],
            ));
        }
        
        return array(
            'status' => 'success',
            'message' => 'Contenuti generati con successo',
            'fields' => $parsed,
        );
    }
    
    /**
     * Costruisci prompt per OpenAI
     * 
     * @param string $transcript Trascrizione
     * @return string
     */
    private function build_prompt($transcript) {
        // Determina testo sponsor
        $sponsor_setting = get_option('ipv_sponsor_type', 'biovital');
        if ($sponsor_setting === 'streamyard') {
            $sponsor_text = "StreamYard – Dai un'occhiata a StreamYard e ottieni \$10 di sconto! 👉 https://streamyard.com/pal/d/50874561";
        } else {
            $sponsor_text = "Biovital – Progetto Italia\nSostieni il progetto: 👉 https://biovital-italia.com/?bio=17";
        }
        
        $prompt = <<<PROMPT
Hai ricevuto la trascrizione completa di un episodio del canale YouTube "Il Punto di Vista".

TRASCRIZIONE:
{$transcript}

---

**FORMATO RICHIESTO:**

📺 TITOLO EPISODIO
[Crea un titolo accattivante e ottimizzato per YouTube, massimo 100 caratteri]

---

📌 DESCRIZIONE
[Scrivi una descrizione SEO-ottimizzata del video, massimo 1200 caratteri, che riassuma i contenuti principali]

---

🎁 SPONSOR
{$sponsor_text}

---

⏱️ MINUTAGGIO
00:00 – Intro
[Aggiungi le tappe principali del video nel formato HH:MM – Titolo tappa. Analizza la trascrizione per identificare i momenti chiave.]

---

📖 ARGOMENTI TRATTATI
[Lista gli argomenti principali trattati nel video, uno per riga con prefisso "– ". Basati SOLO sulla trascrizione.]

---

👤 OSPITI
[Lista gli ospiti presenti (se ci sono), uno per riga con prefisso "– ". Se non ci sono ospiti nella trascrizione, scrivi "Nessun ospite"]

---

📌 PERSONE MENZIONATE
[Lista le persone menzionate nel video (se ci sono), uno per riga con prefisso "– ". Se non ci sono, scrivi "Nessuna persona menzionata"]

---

🎥 REGIA
Il Punto di Vista

---

🔔 EVENTI
[Se nel video vengono menzionati eventi, indicali con data e modalità nel formato:
📅 [EVENTO + DATA + MODALITÀ]
🌐 [LINK O INFO UTILI]

Se non ci sono eventi nella trascrizione, scrivi "Nessun evento in programma"]

---

🔗 LINK UTILI
[INSERIRE SOLO SE PRESENTI NELLA TRASCRIZIONE – altrimenti rimuovere completamente questa sezione]

---

❤️ DONAZIONI
Per sostenere il canale e i progetti de Il Punto di Vista basta fare una donazione a questo link:
👉 https://paypal.me/adrianfiorelli
Grazie in anticipo a tutti i pirati 🖤🏴‍☠️

---

🙏 ABBONATI AL CANALE
/ @ilpuntodivista

---

🌐 SOCIAL
Telegram 👉 https://t.me/il_punto_divista
Facebook 👉 https://facebook.com/groups/4102938329737588
Instagram 👉 https://instagram.com/_ilpuntodivista._

---

📧 CONTATTI
✉️ ilpuntodivistaredazione@gmail.com

---

🎯 TEMI DEL CANALE
Esoterismo – Spiritualità – Misteri – Geopolitica – Divulgazione alternativa

---

#️⃣ HASHTAG
[Genera fino a 30 hashtag pertinenti separati da spazio, tutti in minuscolo con #. Basati SOLO sul contenuto reale della trascrizione.]

---

**REGOLE IMPORTANTI:**
1. Mantieni ESATTAMENTE questa struttura con i separatori "---"
2. Usa le emoji indicate per ogni sezione
3. Rispetta i limiti di caratteri indicati
4. Basati SOLO sul contenuto della trascrizione fornita
5. Se qualche informazione non è presente nella trascrizione, usa placeholder neutri
6. NON inventare informazioni che non sono nella trascrizione
7. Per i link utili, se non sono menzionati nella trascrizione, RIMUOVI COMPLETAMENTE quella sezione
PROMPT;

        return $prompt;
    }
    
    /**
     * Parsa contenuto generato
     * 
     * @param string $content Contenuto generato da OpenAI
     * @return array
     */
    private function parse_generated_content($content) {
        $parsed = array();
        
        // Split per sezioni
        $sections = explode('---', $content);
        
        foreach ($sections as $section) {
            $section = trim($section);
            
            if (empty($section)) {
                continue;
            }
            
            // Titolo Episodio
            if (stripos($section, 'TITOLO EPISODIO') !== false || stripos($section, '📺') !== false) {
                $lines = explode("\n", $section);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'TITOLO') === false && stripos($line, '📺') === false) {
                        $parsed['titolo_episodio'] = $line;
                        break;
                    }
                }
            }
            
            // Descrizione
            elseif (stripos($section, 'DESCRIZIONE') !== false || stripos($section, '📌') !== false) {
                $lines = explode("\n", $section);
                $desc_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'DESCRIZIONE') === false && stripos($line, '📌') === false) {
                        $desc_lines[] = $line;
                    }
                }
                $parsed['descrizione'] = implode("\n", $desc_lines);
            }
            
            // Sponsor
            elseif (stripos($section, 'SPONSOR') !== false || stripos($section, '🎁') !== false) {
                $lines = explode("\n", $section);
                $sponsor_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'SPONSOR') === false && stripos($line, '🎁') === false) {
                        $sponsor_lines[] = $line;
                    }
                }
                $parsed['sponsor'] = implode("\n", $sponsor_lines);
            }
            
            // Minutaggio
            elseif (stripos($section, 'MINUTAGGIO') !== false || stripos($section, '⏱️') !== false) {
                $lines = explode("\n", $section);
                $time_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'MINUTAGGIO') === false && stripos($line, '⏱️') === false) {
                        $time_lines[] = $line;
                    }
                }
                $parsed['timecodes'] = implode("\n", $time_lines);
            }
            
            // Argomenti Trattati
            elseif (stripos($section, 'ARGOMENTI') !== false || stripos($section, '📖') !== false) {
                $lines = explode("\n", $section);
                $arg_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'ARGOMENTI') === false && stripos($line, '📖') === false) {
                        $arg_lines[] = $line;
                    }
                }
                $parsed['argomenti_trattati'] = implode("\n", $arg_lines);
            }
            
            // Ospiti
            elseif (stripos($section, 'OSPITI') !== false || stripos($section, '👤') !== false) {
                $lines = explode("\n", $section);
                $guest_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'OSPITI') === false && stripos($line, '👤') === false) {
                        $guest_lines[] = $line;
                    }
                }
                $parsed['ospiti'] = implode("\n", $guest_lines);
            }
            
            // Persone Menzionate
            elseif (stripos($section, 'PERSONE') !== false || stripos($section, '📌') !== false) {
                $lines = explode("\n", $section);
                $people_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'PERSONE') === false && stripos($line, '📌') === false && stripos($line, 'DESCRIZIONE') === false) {
                        $people_lines[] = $line;
                    }
                }
                if (!empty($people_lines)) {
                    $parsed['persone_menzionate'] = implode("\n", $people_lines);
                }
            }
            
            // Regia
            elseif (stripos($section, 'REGIA') !== false || stripos($section, '🎥') !== false) {
                $lines = explode("\n", $section);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'REGIA') === false && stripos($line, '🎥') === false) {
                        $parsed['regia'] = $line;
                        break;
                    }
                }
            }
            
            // Eventi
            elseif (stripos($section, 'EVENTI') !== false || stripos($section, '🔔') !== false) {
                $lines = explode("\n", $section);
                $event_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'EVENTI') === false && stripos($line, '🔔') === false) {
                        $event_lines[] = $line;
                    }
                }
                $parsed['eventi'] = implode("\n", $event_lines);
            }
            
            // Link Utili
            elseif (stripos($section, 'LINK UTILI') !== false || stripos($section, '🔗') !== false) {
                $lines = explode("\n", $section);
                $link_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'LINK UTILI') === false && stripos($line, '🔗') === false && !preg_match('/\[INSERIRE SOLO SE/i', $line)) {
                        $link_lines[] = $line;
                    }
                }
                if (!empty($link_lines)) {
                    $parsed['link_utili'] = implode("\n", $link_lines);
                }
            }
            
            // Hashtag
            elseif (stripos($section, 'HASHTAG') !== false || stripos($section, '#️⃣') !== false) {
                $lines = explode("\n", $section);
                $hashtag_lines = array();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, 'HASHTAG') === false && stripos($line, '#️⃣') === false) {
                        $hashtag_lines[] = $line;
                    }
                }
                $parsed['hashtag'] = implode("\n", $hashtag_lines);
            }
        }
        
        return $parsed;
    }
    
    /**
     * Salva campi generati nel post
     * 
     * @param int $post_id ID del post
     * @param array $fields Campi parsati
     */
    private function save_generated_fields($post_id, $fields) {
        $field_map = array(
            'titolo_episodio' => '_ipv_argomenta',
            'descrizione' => '_ipv_descrizione',
            'sponsor' => '_ipv_sponsor',
            'timecodes' => '_ipv_timecodes',
            'argomenti_trattati' => '_ipv_argomenti_trattati',
            'ospiti' => '_ipv_ospiti',
            'persone_menzionate' => '_ipv_persone_menzionate',
            'regia' => '_ipv_regia',
            'eventi' => '_ipv_eventi',
            'link_utili' => '_ipv_link_utili',
            'hashtag' => '_ipv_hashtag',
        );
        
        foreach ($field_map as $key => $meta_key) {
            if (isset($fields[$key])) {
                update_post_meta($post_id, $meta_key, wp_kses_post($fields[$key]));
            }
        }
        
        // Salva anche un riassunto (stesso della descrizione)
        if (isset($fields['descrizione'])) {
            update_post_meta($post_id, '_ipv_riassunto', wp_kses_post($fields['descrizione']));
        }
    }
    
    /**
     * Rigenera solo descrizione
     * 
     * @param int $post_id ID del post
     * @return array|WP_Error
     */
    public function regenerate_description($post_id) {
        $transcript = get_post_meta($post_id, '_ipv_transcript', true);
        
        if (empty($transcript)) {
            return new WP_Error('no_transcript', 'Trascrizione non disponibile');
        }
        
        // Usa un prompt più breve solo per la descrizione
        $prompt = "Crea una descrizione SEO-ottimizzata (max 1200 caratteri) per questo video YouTube basandoti sulla seguente trascrizione:\n\n{$transcript}";
        
        $response = wp_remote_post($this->api_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4o',
                'messages' => array(
                    array('role' => 'user', 'content' => $prompt),
                ),
                'temperature' => 0.7,
                'max_tokens' => 500,
            )),
            'timeout' => 60,
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['choices'][0]['message']['content'])) {
            $description = trim($data['choices'][0]['message']['content']);
            update_post_meta($post_id, '_ipv_descrizione', wp_kses_post($description));
            update_post_meta($post_id, '_ipv_riassunto', wp_kses_post($description));
            
            return array('status' => 'success', 'description' => $description);
        }
        
        return new WP_Error('invalid_response', 'Risposta OpenAI non valida');
    }
}
