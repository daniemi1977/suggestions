/**
 * IPV Video Manager - Admin JS
 */

(function($) {
    'use strict';
    
    // Variabili globali
    const strings = ipvVm.strings;
    const ajaxUrl = ipvVm.ajax_url;
    const nonce = ipvVm.nonce;
    
    /**
     * Tabs navigation
     */
    function initTabs() {
        $('.ipv-tab-nav a').on('click', function(e) {
            e.preventDefault();
            
            const tab = $(this).attr('href');
            
            // Update active tab
            $(this).closest('.ipv-tab-nav').find('li').removeClass('active');
            $(this).parent('li').addClass('active');
            
            // Show/hide content
            $(this).closest('.ipv-tabs').find('.ipv-tab-pane').removeClass('active');
            $(tab).addClass('active');
        });
    }
    
    /**
     * Import video
     */
    function initImport() {
        $('#ipv-import-video').on('click', function() {
            const $button = $(this);
            const $status = $('#ipv-import-status');
            const url = $('#ipv-import-url').val().trim();
            const postId = $('#post_ID').val() || 0;
            
            if (!url) {
                showStatus($status, 'error', 'Inserisci un URL valido');
                return;
            }
            
            // Disable button
            $button.prop('disabled', true).text('⏳ Importazione...');
            showStatus($status, 'loading', strings.importing);
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_import_video',
                    nonce: nonce,
                    url: url,
                    post_id: postId
                },
                success: function(response) {
                    if (response.success) {
                        showStatus($status, 'success', response.data.message);
                        
                        // Reload page dopo 2 secondi
                        setTimeout(function() {
                            if (postId > 0) {
                                location.reload();
                            } else {
                                window.location.href = 'post.php?post=' + response.data.post_id + '&action=edit';
                            }
                        }, 2000);
                    } else {
                        showStatus($status, 'error', response.data || strings.error);
                        $button.prop('disabled', false).text('📥 Importa Video');
                    }
                },
                error: function(xhr, status, error) {
                    showStatus($status, 'error', 'Errore: ' + error);
                    $button.prop('disabled', false).text('📥 Importa Video');
                }
            });
        });
    }
    
    /**
     * Generate content with OpenAI
     */
    function initGenerate() {
        $('#ipv-generate-content').on('click', function() {
            const $button = $(this);
            const $status = $('#ipv-generate-status');
            const postId = $('#post_ID').val();
            
            if (!postId) {
                alert('Salva prima il post');
                return;
            }
            
            // Disable button
            $button.prop('disabled', true).html('⏳ Generazione... <span class="ipv-spinner"></span>');
            showStatus($status, 'loading', strings.generating);
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_generate_content',
                    nonce: nonce,
                    post_id: postId
                },
                success: function(response) {
                    if (response.success) {
                        showStatus($status, 'success', strings.success);
                        
                        // Reload page dopo 1 secondo
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showStatus($status, 'error', response.data || strings.error);
                        $button.prop('disabled', false).html('🤖 Genera Contenuti con OpenAI');
                    }
                },
                error: function(xhr, status, error) {
                    showStatus($status, 'error', 'Errore: ' + error);
                    $button.prop('disabled', false).html('🤖 Genera Contenuti con OpenAI');
                }
            });
        });
    }
    
    /**
     * Batch import 10 videos
     */
    function initBatchImport() {
        $('#ipv-batch-import-10').on('click', function() {
            const $button = $(this);
            const $status = $('#ipv-tools-status');
            
            if (!confirm('Importare gli ultimi 10 video dal canale? Questa operazione può richiedere diversi minuti.')) {
                return;
            }
            
            // Disable button
            $button.prop('disabled', true).html('⏳ Importazione batch... <span class="ipv-spinner"></span>');
            showStatus($status, 'loading', 'Import in corso... attendere...');
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_batch_import',
                    nonce: nonce
                },
                timeout: 300000, // 5 minuti
                success: function(response) {
                    if (response.success) {
                        const data = response.data;
                        const msg = `Import completato!\nSuccesso: ${data.success}\nErrori: ${data.errors}\nSaltati: ${data.skipped}`;
                        showStatus($status, 'success', msg);
                        
                        // Reload dopo 3 secondi
                        setTimeout(function() {
                            location.reload();
                        }, 3000);
                    } else {
                        showStatus($status, 'error', response.data || strings.error);
                        $button.prop('disabled', false).html('📥 Importa Ultimi 10 Video');
                    }
                },
                error: function(xhr, status, error) {
                    showStatus($status, 'error', 'Errore: ' + error);
                    $button.prop('disabled', false).html('📥 Importa Ultimi 10 Video');
                }
            });
        });
    }
    
    /**
     * Regenerate single video
     */
    function initRegenerate() {
        $('#ipv-regenerate-single').on('click', function() {
            const $button = $(this);
            const $status = $('#ipv-tools-status');
            const postId = $('#post_ID').val();
            
            if (!postId) {
                alert('Salva prima il post');
                return;
            }
            
            if (!confirm('Rigenerare tutti i contenuti per questo video?')) {
                return;
            }
            
            // Disable button
            $button.prop('disabled', true).html('⏳ Rigenerazione... <span class="ipv-spinner"></span>');
            showStatus($status, 'loading', 'Rigenerazione in corso...');
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_generate_content',
                    nonce: nonce,
                    post_id: postId
                },
                success: function(response) {
                    if (response.success) {
                        showStatus($status, 'success', 'Contenuti rigenerati!');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showStatus($status, 'error', response.data || strings.error);
                        $button.prop('disabled', false).html('🔄 Rigenera Tutto (questo video)');
                    }
                },
                error: function(xhr, status, error) {
                    showStatus($status, 'error', 'Errore: ' + error);
                    $button.prop('disabled', false).html('🔄 Rigenera Tutto (questo video)');
                }
            });
        });
        
        // Regenerate thumbnail
        $('#ipv-regenerate-thumb').on('click', function() {
            const $button = $(this);
            const $status = $('#ipv-tools-status');
            const postId = $('#post_ID').val();
            
            if (!postId) {
                alert('Salva prima il post');
                return;
            }
            
            $button.prop('disabled', true).html('⏳ Rigenerazione...');
            showStatus($status, 'loading', 'Rigenerazione thumbnail...');
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_regenerate_thumbnails',
                    nonce: nonce,
                    post_id: postId
                },
                success: function(response) {
                    if (response.success) {
                        showStatus($status, 'success', 'Thumbnail rigenerata!');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showStatus($status, 'error', response.data || strings.error);
                        $button.prop('disabled', false).html('🖼️ Rigenera Thumbnail');
                    }
                },
                error: function() {
                    showStatus($status, 'error', strings.error);
                    $button.prop('disabled', false).html('🖼️ Rigenera Thumbnail');
                }
            });
        });
        
        // Regenerate description
        $('#ipv-regenerate-desc').on('click', function() {
            const $button = $(this);
            const $status = $('#ipv-tools-status');
            const postId = $('#post_ID').val();
            
            if (!postId) {
                alert('Salva prima il post');
                return;
            }
            
            $button.prop('disabled', true).html('⏳ Rigenerazione...');
            showStatus($status, 'loading', 'Rigenerazione descrizione...');
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_regenerate_descriptions',
                    nonce: nonce,
                    post_id: postId
                },
                success: function(response) {
                    if (response.success) {
                        showStatus($status, 'success', 'Descrizione rigenerata!');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showStatus($status, 'error', response.data || strings.error);
                        $button.prop('disabled', false).html('📝 Rigenera Descrizione');
                    }
                },
                error: function() {
                    showStatus($status, 'error', strings.error);
                    $button.prop('disabled', false).html('📝 Rigenera Descrizione');
                }
            });
        });
    }
    
    /**
     * Test API connections
     */
    function initApiTests() {
        $('#ipv-test-supadata').on('click', function() {
            const $button = $(this);
            const $results = $('#ipv-test-results');
            
            $button.prop('disabled', true).text('Testing...');
            $results.html('<p>Testing Supadata API...</p>');
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_test_supadata',
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        $results.html('<p style="color: green;">✓ Supadata API: OK</p>');
                    } else {
                        $results.html('<p style="color: red;">✗ Supadata API: ' + response.data + '</p>');
                    }
                    $button.prop('disabled', false).text('Test Supadata API');
                },
                error: function() {
                    $results.html('<p style="color: red;">✗ Errore di connessione</p>');
                    $button.prop('disabled', false).text('Test Supadata API');
                }
            });
        });
        
        $('#ipv-test-openai').on('click', function() {
            const $button = $(this);
            const $results = $('#ipv-test-results');
            
            $button.prop('disabled', true).text('Testing...');
            $results.html('<p>Testing OpenAI API...</p>');
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ipv_test_openai',
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        $results.html('<p style="color: green;">✓ OpenAI API: OK</p>');
                    } else {
                        $results.html('<p style="color: red;">✗ OpenAI API: ' + response.data + '</p>');
                    }
                    $button.prop('disabled', false).text('Test OpenAI API');
                },
                error: function() {
                    $results.html('<p style="color: red;">✗ Errore di connessione</p>');
                    $button.prop('disabled', false).text('Test OpenAI API');
                }
            });
        });
    }
    
    /**
     * Show status message
     */
    function showStatus($element, type, message) {
        $element.removeClass('ipv-status-loading ipv-status-success ipv-status-error');
        $element.addClass('ipv-status-' + type);
        $element.html(message).show();
    }
    
    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        initTabs();
        initImport();
        initGenerate();
        initBatchImport();
        initRegenerate();
        initApiTests();
    });
    
})(jQuery);
