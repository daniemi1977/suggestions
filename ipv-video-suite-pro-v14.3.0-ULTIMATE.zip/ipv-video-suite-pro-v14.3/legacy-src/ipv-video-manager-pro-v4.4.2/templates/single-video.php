<?php
/**
 * Template per visualizzazione singolo video
 * 
 * Questo template può essere sovrascritto copiandolo nel tema:
 * /wp-content/themes/your-theme/ipv-video-manager/single-video.php
 */

get_header(); ?>

<div class="ipv-single-video-page">
    <?php
    while (have_posts()) : the_post();
        
        $youtube_id = get_post_meta(get_the_ID(), '_ipv_youtube_id', true);
        ?>
        
        <article id="post-<?php the_ID(); ?>" <?php post_class('ipv-video-post'); ?>>
            
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
                
                <div class="entry-meta">
                    <span class="posted-on">
                        <time datetime="<?php echo get_the_date('c'); ?>">
                            <?php echo get_the_date(); ?>
                        </time>
                    </span>
                    
                    <?php
                    $view_count = get_post_meta(get_the_ID(), '_ipv_view_count', true);
                    if ($view_count):
                    ?>
                    <span class="view-count">
                        👁️ <?php echo number_format($view_count); ?> visualizzazioni
                    </span>
                    <?php endif; ?>
                </div>
            </header>
            
            <?php if ($youtube_id): ?>
            <div class="ipv-video-container">
                <div class="ipv-video-wrapper">
                    <iframe 
                        src="https://www.youtube.com/embed/<?php echo esc_attr($youtube_id); ?>" 
                        frameborder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowfullscreen>
                    </iframe>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="entry-content">
                <?php
                // Contenuti generati (formato Notion)
                $descrizione = get_post_meta(get_the_ID(), '_ipv_descrizione', true);
                $sponsor = get_post_meta(get_the_ID(), '_ipv_sponsor', true);
                $timecodes = get_post_meta(get_the_ID(), '_ipv_timecodes', true);
                $argomenti = get_post_meta(get_the_ID(), '_ipv_argomenti_trattati', true);
                $ospiti = get_post_meta(get_the_ID(), '_ipv_ospiti', true);
                $persone = get_post_meta(get_the_ID(), '_ipv_persone_menzionate', true);
                $eventi = get_post_meta(get_the_ID(), '_ipv_eventi', true);
                $hashtag = get_post_meta(get_the_ID(), '_ipv_hashtag', true);
                ?>
                
                <div class="ipv-video-content">
                    
                    <?php if ($descrizione): ?>
                    <div class="ipv-section">
                        <h3 class="ipv-section-title">📌 Descrizione</h3>
                        <div class="ipv-section-content">
                            <?php echo nl2br(esc_html($descrizione)); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($sponsor): ?>
                    <div class="ipv-section ipv-sponsor">
                        <h3 class="ipv-section-title">🎁 Sponsor</h3>
                        <div class="ipv-section-content">
                            <?php echo wpautop($sponsor); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($timecodes): ?>
                    <div class="ipv-section">
                        <h3 class="ipv-section-title">⏱️ Minutaggio</h3>
                        <div class="ipv-section-content ipv-timecodes">
                            <?php echo nl2br(esc_html($timecodes)); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($argomenti): ?>
                    <div class="ipv-section">
                        <h3 class="ipv-section-title">📖 Argomenti Trattati</h3>
                        <div class="ipv-section-content">
                            <?php echo nl2br(esc_html($argomenti)); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($ospiti && stripos($ospiti, 'nessun') === false): ?>
                    <div class="ipv-section">
                        <h3 class="ipv-section-title">👤 Ospiti</h3>
                        <div class="ipv-section-content">
                            <?php echo nl2br(esc_html($ospiti)); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($persone && stripos($persone, 'nessun') === false): ?>
                    <div class="ipv-section">
                        <h3 class="ipv-section-title">📌 Persone Menzionate</h3>
                        <div class="ipv-section-content">
                            <?php echo nl2br(esc_html($persone)); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($eventi && stripos($eventi, 'nessun') === false): ?>
                    <div class="ipv-section">
                        <h3 class="ipv-section-title">🔔 Eventi</h3>
                        <div class="ipv-section-content">
                            <?php echo nl2br(esc_html($eventi)); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($hashtag): ?>
                    <div class="ipv-section ipv-hashtags">
                        <h3 class="ipv-section-title">#️⃣ Hashtag</h3>
                        <div class="ipv-section-content">
                            <?php echo esc_html($hashtag); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="ipv-section ipv-support">
                        <h3 class="ipv-section-title">❤️ Sostieni il Canale</h3>
                        <div class="ipv-section-content">
                            <p>Per sostenere il canale e i progetti de Il Punto di Vista:</p>
                            <p><a href="https://paypal.me/adrianfiorelli" target="_blank" class="ipv-button">💝 Dona su PayPal</a></p>
                            <p>Grazie in anticipo a tutti i pirati 🖤🏴‍☠️</p>
                        </div>
                    </div>
                    
                    <div class="ipv-section ipv-social">
                        <h3 class="ipv-section-title">🌐 Seguici sui Social</h3>
                        <div class="ipv-section-content ipv-social-links">
                            <a href="https://t.me/il_punto_divista" target="_blank" class="ipv-social-link">📱 Telegram</a>
                            <a href="https://facebook.com/groups/4102938329737588" target="_blank" class="ipv-social-link">📘 Facebook</a>
                            <a href="https://instagram.com/_ilpuntodivista._" target="_blank" class="ipv-social-link">📸 Instagram</a>
                            <a href="https://www.youtube.com/@ilpuntodivista" target="_blank" class="ipv-social-link">📺 YouTube</a>
                        </div>
                    </div>
                    
                </div>
                
                <?php the_content(); ?>
            </div>
            
        </article>
        
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>
