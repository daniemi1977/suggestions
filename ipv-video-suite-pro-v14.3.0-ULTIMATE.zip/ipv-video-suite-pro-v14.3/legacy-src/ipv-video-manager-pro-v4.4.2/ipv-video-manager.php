<?php
/**
 * Plugin Name: IPV Video Manager Pro
 * Plugin URI: https://ilpuntodivista.com
 * Description: Gestione professionale video YouTube con import automatico, trascrizioni, generazione contenuti AI, analytics dashboard, integrazioni Elementor/Gutenberg/WooCommerce, notifiche Telegram/Discord/Mailchimp, cache system, queue manager e performance monitoring
 * Version: 4.4.2
 * Author: Il Punto di Vista
 * Author URI: https://ilpuntodivista.com
 * License: GPL v2 or later
 * Text Domain: ipv-video-manager
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

// Definizioni costanti
define('IPV_VM_VERSION', '4.4.2');
define('IPV_VM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('IPV_VM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('IPV_VM_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Classe principale del plugin
 */
class IPV_Video_Manager {
    
    private static $instance = null;
    
    /**
     * Singleton instance
     */
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Costruttore
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Normalizza trascrizione (usa funzione helper globale)
     * 
     * @param mixed $transcript Trascrizione in qualsiasi formato
     * @return string Trascrizione come stringa pulita
     */
    private function normalize_transcript($transcript) {
        return ipv_normalize_transcript($transcript);
    }
    
    /**
     * Inizializza hooks
     */
    private function init_hooks() {
        add_action('init', array($this, 'register_post_type'));
        add_action('init', array($this, 'load_textdomain'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post_ipv_video', array($this, 'save_meta_boxes'), 10, 2);
        
        // AJAX handlers
        add_action('wp_ajax_ipv_import_video', array($this, 'ajax_import_video'));
        add_action('wp_ajax_ipv_generate_content', array($this, 'ajax_generate_content'));
        add_action('wp_ajax_ipv_batch_import', array($this, 'ajax_batch_import'));
        add_action('wp_ajax_ipv_regenerate_thumbnails', array($this, 'ajax_regenerate_thumbnails'));
        add_action('wp_ajax_ipv_regenerate_descriptions', array($this, 'ajax_regenerate_descriptions'));
        add_action('wp_ajax_ipv_batch_regenerate_all', array($this, 'ajax_batch_regenerate_all'));
        add_action('wp_ajax_ipv_test_supadata', array($this, 'ajax_test_supadata'));
        add_action('wp_ajax_ipv_test_openai', array($this, 'ajax_test_openai'));
        
        // STEP 3A: New AJAX handlers for cache, queue, performance
        add_action('wp_ajax_ipv_clear_cache', array($this, 'ajax_clear_cache'));
        add_action('wp_ajax_ipv_warm_cache', array($this, 'ajax_warm_cache'));
        add_action('wp_ajax_ipv_get_queue_stats', array($this, 'ajax_get_queue_stats'));
        add_action('wp_ajax_ipv_process_queue', array($this, 'ajax_process_queue'));
        add_action('wp_ajax_ipv_clear_queue', array($this, 'ajax_clear_queue'));
        add_action('wp_ajax_ipv_get_system_health', array($this, 'ajax_get_system_health'));
        add_action('wp_ajax_ipv_get_performance_metrics', array($this, 'ajax_get_performance_metrics'));
        
        // STEP 3B: New AJAX handlers for dashboard & analytics
        add_action('wp_ajax_ipv_get_dashboard_stats', array($this, 'ajax_get_dashboard_stats'));
        add_action('wp_ajax_ipv_get_seo_score', array($this, 'ajax_get_seo_score'));
        add_action('wp_ajax_ipv_get_calendar_data', array($this, 'ajax_get_calendar_data'));
        
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Frontend
        add_filter('single_template', array($this, 'load_video_template'));
        add_filter('the_content', array($this, 'inject_video_content'));
        add_shortcode('ipv_video', array($this, 'video_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        
        // CRON
        add_action('ipv_auto_import_videos', array($this, 'cron_auto_import'));
        add_action('ipv_process_queue', array($this, 'cron_process_queue')); // STEP 3A: Queue processing
        
        // Activation/Deactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Carica dipendenze
     */
    private function load_dependencies() {
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-api.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-openai.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-cache.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-queue.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-performance.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-analytics.php'; // STEP 3B
        
        // STEP 3D: Integrations
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-elementor.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-gutenberg.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-woocommerce.php';
        require_once IPV_VM_PLUGIN_DIR . 'includes/class-ipv-notifications.php';
    }
    
    /**
     * Carica text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain('ipv-video-manager', false, dirname(IPV_VM_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * Registra Custom Post Type
     */
    public function register_post_type() {
        $labels = array(
            'name' => 'Video',
            'singular_name' => 'Video',
            'add_new' => 'Aggiungi Nuovo',
            'add_new_item' => 'Aggiungi Nuovo Video',
            'edit_item' => 'Modifica Video',
            'new_item' => 'Nuovo Video',
            'view_item' => 'Visualizza Video',
            'search_items' => 'Cerca Video',
            'not_found' => 'Nessun video trovato',
            'not_found_in_trash' => 'Nessun video nel cestino',
            'all_items' => 'Tutti i Video',
            'menu_name' => 'Video Manager',
        );
        
        $args = array(
            'labels' => $labels,
            'public' => true,
            'has_archive' => true,
            'menu_icon' => 'dashicons-video-alt3',
            'supports' => array('title', 'editor', 'thumbnail'),
            'show_in_rest' => true,
            'rewrite' => array('slug' => 'video'),
        );
        
        register_post_type('ipv_video', $args);
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        global $post_type;
        
        if ('ipv_video' !== $post_type && 'ipv_video_page_ipv-settings' !== $hook) {
            return;
        }
        
        wp_enqueue_style('ipv-admin', IPV_VM_PLUGIN_URL . 'assets/css/admin.css', array(), IPV_VM_VERSION);
        wp_enqueue_script('ipv-admin', IPV_VM_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), IPV_VM_VERSION, true);
        
        wp_localize_script('ipv-admin', 'ipvVm', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ipv_video_nonce'),
            'strings' => array(
                'importing' => 'Importazione in corso...',
                'generating' => 'Generazione contenuti...',
                'success' => 'Operazione completata!',
                'error' => 'Errore durante l\'operazione.',
            ),
        ));
    }
    
    /**
     * Aggiungi meta boxes
     */
    public function add_meta_boxes() {
        // Video Info
        add_meta_box(
            'ipv_video_info',
            'Informazioni Video',
            array($this, 'render_video_info_metabox'),
            'ipv_video',
            'normal',
            'high'
        );
        
        // Import
        add_meta_box(
            'ipv_video_import',
            'Import Video',
            array($this, 'render_import_metabox'),
            'ipv_video',
            'side',
            'high'
        );
        
        // Trascrizione
        add_meta_box(
            'ipv_video_transcript',
            'Trascrizione',
            array($this, 'render_transcript_metabox'),
            'ipv_video',
            'normal',
            'high'
        );
        
        // Contenuti Generati
        add_meta_box(
            'ipv_video_generated',
            'Contenuti Generati (OpenAI)',
            array($this, 'render_generated_metabox'),
            'ipv_video',
            'normal',
            'default'
        );
        
        // Tools
        add_meta_box(
            'ipv_video_tools',
            'Strumenti',
            array($this, 'render_tools_metabox'),
            'ipv_video',
            'side',
            'default'
        );
    }
    
    /**
     * Render Video Info Metabox
     */
    public function render_video_info_metabox($post) {
        wp_nonce_field('ipv_video_meta', 'ipv_video_meta_nonce');
        
        $youtube_id = get_post_meta($post->ID, '_ipv_youtube_id', true);
        $youtube_url = get_post_meta($post->ID, '_ipv_youtube_url', true);
        $thumbnail_url = get_post_meta($post->ID, '_ipv_thumbnail_url', true);
        $duration = get_post_meta($post->ID, '_ipv_duration', true);
        $is_episode = get_post_meta($post->ID, '_ipv_is_episode', true);
        $source = get_post_meta($post->ID, '_ipv_source', true);
        $view_count = get_post_meta($post->ID, '_ipv_view_count', true);
        $upload_date = get_post_meta($post->ID, '_ipv_upload_date', true);
        ?>
        
        <div class="ipv-tabs">
            <ul class="ipv-tab-nav">
                <li class="active"><a href="#ipv-tab-video">Video</a></li>
                <li><a href="#ipv-tab-details">Dettagli</a></li>
            </ul>
            
            <div class="ipv-tab-content">
                <!-- Tab Video -->
                <div id="ipv-tab-video" class="ipv-tab-pane active">
                    <?php if ($youtube_id): ?>
                        <div class="ipv-video-preview">
                            <iframe width="100%" height="315" 
                                src="https://www.youtube.com/embed/<?php echo esc_attr($youtube_id); ?>" 
                                frameborder="0" allowfullscreen></iframe>
                        </div>
                    <?php endif; ?>
                    
                    <p>
                        <label><strong>YouTube Video ID</strong></label>
                        <input type="text" name="ipv_youtube_id" value="<?php echo esc_attr($youtube_id); ?>" 
                            class="widefat" readonly>
                    </p>
                    
                    <p>
                        <label><strong>YouTube URL</strong></label>
                        <input type="text" name="ipv_youtube_url" value="<?php echo esc_attr($youtube_url); ?>" 
                            class="widefat" readonly>
                    </p>
                    
                    <p>
                        <label><strong>Thumbnail URL</strong></label>
                        <input type="text" name="ipv_thumbnail_url" value="<?php echo esc_attr($thumbnail_url); ?>" 
                            class="widefat" readonly>
                        <?php if ($thumbnail_url): ?>
                            <img src="<?php echo esc_url($thumbnail_url); ?>" style="max-width: 200px; margin-top: 10px;">
                        <?php endif; ?>
                    </p>
                </div>
                
                <!-- Tab Dettagli -->
                <div id="ipv-tab-details" class="ipv-tab-pane">
                    <p>
                        <label><strong>Durata (secondi)</strong></label>
                        <input type="number" name="ipv_duration" value="<?php echo esc_attr($duration); ?>" class="widefat">
                        <?php if ($duration): ?>
                            <span class="description">
                                <?php echo gmdate('H:i:s', $duration); ?>
                                <?php if ($duration < 60): ?>
                                    <strong style="color: red;"> - SHORT (salvato in bozza)</strong>
                                <?php endif; ?>
                            </span>
                        <?php endif; ?>
                    </p>
                    
                    <p>
                        <label>
                            <input type="checkbox" name="ipv_is_episode" value="1" <?php checked($is_episode, '1'); ?>>
                            <strong>È Puntata?</strong>
                        </label>
                    </p>
                    
                    <p>
                        <label><strong>Sorgente</strong></label>
                        <input type="text" name="ipv_source" value="<?php echo esc_attr($source); ?>" class="widefat">
                    </p>
                    
                    <p>
                        <label><strong>Visualizzazioni</strong></label>
                        <input type="text" name="ipv_view_count" value="<?php echo esc_attr($view_count); ?>" class="widefat" readonly>
                    </p>
                    
                    <p>
                        <label><strong>Data Caricamento</strong></label>
                        <input type="text" name="ipv_upload_date" value="<?php echo esc_attr($upload_date); ?>" class="widefat" readonly>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render Import Metabox
     */
    public function render_import_metabox($post) {
        ?>
        <div class="ipv-import-box">
            <p>
                <label><strong>URL Video YouTube</strong></label>
                <input type="text" id="ipv-import-url" class="widefat" 
                    placeholder="https://www.youtube.com/watch?v=...">
            </p>
            
            <p>
                <button type="button" class="button button-primary button-large" id="ipv-import-video">
                    📥 Importa Video
                </button>
            </p>
            
            <div id="ipv-import-status" style="margin-top: 10px;"></div>
        </div>
        <?php
    }
    
    /**
     * Render Transcript Metabox
     */
    public function render_transcript_metabox($post) {
        $transcript = get_post_meta($post->ID, '_ipv_transcript', true);
        $transcript = $this->normalize_transcript($transcript);
        
        ?>
        <p>
            <textarea name="ipv_transcript" rows="15" class="widefat" style="font-family: monospace;"><?php echo esc_textarea($transcript); ?></textarea>
        </p>
        
        <p>
            <button type="button" class="button button-primary" id="ipv-generate-content">
                🤖 Genera Contenuti con OpenAI
            </button>
            <span id="ipv-generate-status" style="margin-left: 10px;"></span>
        </p>
        <?php
    }
    
    /**
     * Render Generated Content Metabox
     */
    public function render_generated_metabox($post) {
        $fields = array(
            'argomenta' => 'Argomenta',
            'riassunto' => 'Riassunto',
            'sponsor' => 'Sponsor',
            'tesi_oratoria' => 'Tesi Oratoria/Temi',
            'descrizione' => 'Descrizione/Riassunto',
            'argomenti_trattati' => 'Argomenti Trattati',
            'timecodes' => 'Timecodes/Minutaggio',
            'ospiti' => 'Ospiti',
            'persone_menzionate' => 'Persone Menzionate',
            'eventi' => 'Eventi',
            'hashtag' => 'Hashtag',
        );
        
        echo '<div class="ipv-generated-fields">';
        
        foreach ($fields as $key => $label) {
            $value = get_post_meta($post->ID, '_ipv_' . $key, true);
            ?>
            <p>
                <label><strong><?php echo esc_html($label); ?></strong></label>
                <textarea name="ipv_<?php echo esc_attr($key); ?>" rows="5" class="widefat"><?php echo esc_textarea($value); ?></textarea>
            </p>
            <?php
        }
        
        echo '</div>';
    }
    
    /**
     * Render Tools Metabox
     */
    public function render_tools_metabox($post) {
        ?>
        <div class="ipv-tools">
            <h4>🔄 Rigenera</h4>
            
            <p>
                <button type="button" class="button button-small widefat" id="ipv-regenerate-single">
                    🔄 Rigenera Tutto (questo video)
                </button>
            </p>
            
            <p>
                <button type="button" class="button button-small widefat" id="ipv-regenerate-thumb">
                    🖼️ Rigenera Thumbnail
                </button>
            </p>
            
            <p>
                <button type="button" class="button button-small widefat" id="ipv-regenerate-desc">
                    📝 Rigenera Descrizione
                </button>
            </p>
            
            <hr>
            
            <h4>📥 Import Batch</h4>
            <p>
                <button type="button" class="button button-small widefat" id="ipv-batch-import-10">
                    📥 Importa Ultimi 10 Video
                </button>
            </p>
            
            <div id="ipv-tools-status" style="margin-top: 10px; font-size: 12px;"></div>
        </div>
        <?php
    }
    
    /**
     * Salva meta boxes
     */
    public function save_meta_boxes($post_id, $post) {
        // Verifica nonce
        if (!isset($_POST['ipv_video_meta_nonce']) || !wp_verify_nonce($_POST['ipv_video_meta_nonce'], 'ipv_video_meta')) {
            return;
        }
        
        // Verifica autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Verifica permessi
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Salva campi base
        $fields = array(
            'ipv_youtube_id',
            'ipv_youtube_url',
            'ipv_thumbnail_url',
            'ipv_duration',
            'ipv_source',
            'ipv_view_count',
            'ipv_upload_date',
            'ipv_transcript',
        );
        
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        // Checkbox
        update_post_meta($post_id, '_ipv_is_episode', isset($_POST['ipv_is_episode']) ? '1' : '0');
        
        // Campi generati
        $generated_fields = array(
            'ipv_argomenta',
            'ipv_riassunto',
            'ipv_sponsor',
            'ipv_tesi_oratoria',
            'ipv_descrizione',
            'ipv_argomenti_trattati',
            'ipv_timecodes',
            'ipv_ospiti',
            'ipv_persone_menzionate',
            'ipv_eventi',
            'ipv_hashtag',
        );
        
        foreach ($generated_fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, '_' . $field, wp_kses_post($_POST[$field]));
            }
        }
    }
    
    /**
     * AJAX: Import Video
     */
    public function ajax_import_video() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        if (empty($url)) {
            wp_send_json_error('URL non valido');
        }
        
        try {
            $api = new IPV_API();
            $result = $api->import_video($url, $post_id);
            
            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message());
            }
            
            wp_send_json_success($result);
            
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
    
    /**
     * AJAX: Generate Content
     */
    public function ajax_generate_content() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $transcript = get_post_meta($post_id, '_ipv_transcript', true);
        $transcript = $this->normalize_transcript($transcript);
        
        if (empty($transcript)) {
            wp_send_json_error('Nessuna trascrizione disponibile');
        }
        
        try {
            $openai = new IPV_OpenAI();
            $result = $openai->generate_content($transcript, $post_id);
            
            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message());
            }
            
            wp_send_json_success($result);
            
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
    
    /**
     * AJAX: Batch Import
     */
    public function ajax_batch_import() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        try {
            $api = new IPV_API();
            $result = $api->batch_import(10);
            
            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message());
            }
            
            wp_send_json_success($result);
            
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
    
    /**
     * AJAX: Regenerate Thumbnails
     */
    public function ajax_regenerate_thumbnails() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        // TODO: Implementare rigenerazione thumbnails
        
        wp_send_json_success('Thumbnail rigenerata');
    }
    
    /**
     * AJAX: Regenerate Descriptions
     */
    public function ajax_regenerate_descriptions() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        if ($post_id > 0) {
            // Rigenera singola descrizione
            $openai = new IPV_OpenAI();
            $result = $openai->regenerate_description($post_id);
            
            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message());
            }
            
            wp_send_json_success($result);
        } else {
            wp_send_json_error('Post ID non valido');
        }
    }
    
    /**
     * AJAX: Batch Regenerate All
     */
    public function ajax_batch_regenerate_all() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        // Ottieni tutti i video con trascrizione
        $args = array(
            'post_type' => 'ipv_video',
            'posts_per_page' => 10,
            'meta_query' => array(
                array(
                    'key' => '_ipv_transcript',
                    'value' => '',
                    'compare' => '!=',
                ),
            ),
        );
        
        $videos = get_posts($args);
        
        if (empty($videos)) {
            wp_send_json_error('Nessun video con trascrizione trovato');
        }
        
        $results = array(
            'success' => 0,
            'errors' => 0,
            'details' => array(),
        );
        
        $openai = new IPV_OpenAI();
        
        foreach ($videos as $video) {
            $transcript = get_post_meta($video->ID, '_ipv_transcript', true);
            $transcript = $this->normalize_transcript($transcript);
            $result = $openai->generate_content($transcript, $video->ID);
            
            if (is_wp_error($result)) {
                $results['errors']++;
                $results['details'][] = array(
                    'post_id' => $video->ID,
                    'title' => $video->post_title,
                    'status' => 'error',
                    'message' => $result->get_error_message(),
                );
            } else {
                $results['success']++;
                $results['details'][] = array(
                    'post_id' => $video->ID,
                    'title' => $video->post_title,
                    'status' => 'success',
                );
            }
            
            // Pausa per evitare rate limiting
            sleep(2);
        }
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX: Test Supadata API
     */
    public function ajax_test_supadata() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $api_key = get_option('ipv_supadata_api_key', '');
        
        if (empty($api_key)) {
            wp_send_json_error('API key non configurata');
        }
        
        // Test con un video YouTube noto
        $test_url = 'https://api.supadata.ai/v1/youtube/video?id=dQw4w9WgXcQ';
        
        $response = wp_remote_get($test_url, array(
            'headers' => array(
                'x-api-key' => $api_key,
            ),
            'timeout' => 10,
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200) {
            wp_send_json_success('Connessione riuscita!');
        } else {
            $body = wp_remote_retrieve_body($response);
            wp_send_json_error('Errore ' . $code . ': ' . $body);
        }
    }
    
    /**
     * AJAX: Test OpenAI API
     */
    public function ajax_test_openai() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $api_key = get_option('ipv_openai_api_key', '');
        
        if (empty($api_key)) {
            wp_send_json_error('API key non configurata');
        }
        
        // Test con una richiesta semplice
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4o',
                'messages' => array(
                    array('role' => 'user', 'content' => 'Test'),
                ),
                'max_tokens' => 5,
            )),
            'timeout' => 10,
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200) {
            wp_send_json_success('Connessione riuscita!');
        } else {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            $error = isset($data['error']['message']) ? $data['error']['message'] : 'Errore sconosciuto';
            wp_send_json_error('Errore ' . $code . ': ' . $error);
        }
    }
    
    
    /**
     * Aggiungi menu admin
     */
    public function add_admin_menu() {
        // STEP 3B: Dashboard page (first in menu)
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            'Dashboard',
            '📊 Dashboard',
            'edit_posts',
            'ipv-dashboard',
            array($this, 'render_dashboard_page')
        );
        
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            'Impostazioni',
            'Impostazioni',
            'manage_options',
            'ipv-settings',
            array($this, 'render_settings_page')
        );
        
        // STEP 3D: Integrations page
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            'Integrations',
            '🧩 Integrations',
            'manage_options',
            'ipv-integrations',
            array($this, 'render_integrations_page')
        );
        
        // STEP 3A: Performance monitoring page
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            'Performance',
            '⚡ Performance',
            'manage_options',
            'ipv-performance',
            array($this, 'render_performance_page')
        );
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (isset($_POST['ipv_save_settings']) && check_admin_referer('ipv_settings', 'ipv_settings_nonce')) {
            update_option('ipv_supadata_api_key', sanitize_text_field($_POST['ipv_supadata_api_key']));
            update_option('ipv_openai_api_key', sanitize_text_field($_POST['ipv_openai_api_key']));
            update_option('ipv_channel_url', esc_url_raw($_POST['ipv_channel_url']));
            update_option('ipv_auto_import_enabled', isset($_POST['ipv_auto_import_enabled']) ? '1' : '0');
            update_option('ipv_auto_import_interval', intval($_POST['ipv_auto_import_interval']));
            
            // Aggiorna CRON schedule
            $this->update_cron_schedule();
            
            echo '<div class="notice notice-success"><p>Impostazioni salvate! CRON job aggiornato.</p></div>';
        }
        
        $supadata_key = get_option('ipv_supadata_api_key', '');
        $openai_key = get_option('ipv_openai_api_key', '');
        $channel_url = get_option('ipv_channel_url', 'https://www.youtube.com/@ilpuntodivista/streams');
        $auto_import = get_option('ipv_auto_import_enabled', '0');
        $interval = get_option('ipv_auto_import_interval', 12);
        ?>
        
        <div class="wrap">
            <h1>🎬 IPV Video Manager - Impostazioni</h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('ipv_settings', 'ipv_settings_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>Supadata API Key</label></th>
                        <td>
                            <input type="text" name="ipv_supadata_api_key" value="<?php echo esc_attr($supadata_key); ?>" 
                                class="regular-text" required>
                            <p class="description">Chiave API per Supadata (trascrizioni e metadata)</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label>OpenAI API Key</label></th>
                        <td>
                            <input type="text" name="ipv_openai_api_key" value="<?php echo esc_attr($openai_key); ?>" 
                                class="regular-text" required>
                            <p class="description">Chiave API per OpenAI (generazione contenuti)</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label>URL Canale YouTube</label></th>
                        <td>
                            <input type="url" name="ipv_channel_url" value="<?php echo esc_attr($channel_url); ?>" 
                                class="regular-text">
                            <p class="description">URL del canale per l'import automatico</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label>Import Automatico</label></th>
                        <td>
                            <label>
                                <input type="checkbox" name="ipv_auto_import_enabled" value="1" 
                                    <?php checked($auto_import, '1'); ?>>
                                Abilita import automatico via CRON
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label>Intervallo Import (ore)</label></th>
                        <td>
                            <input type="number" name="ipv_auto_import_interval" value="<?php echo esc_attr($interval); ?>" 
                                min="1" max="24" class="small-text">
                            <p class="description">Controlla nuovi video ogni X ore</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="ipv_save_settings" class="button button-primary">
                        💾 Salva Impostazioni
                    </button>
                </p>
            </form>
            
            <hr>
            
            <h2>🧪 Test API</h2>
            <p>
                <button type="button" class="button" id="ipv-test-supadata">Test Supadata API</button>
                <button type="button" class="button" id="ipv-test-openai">Test OpenAI API</button>
            </p>
            <div id="ipv-test-results" style="margin-top: 20px;"></div>
            
            <hr>
            
            <h2>🔄 Operazioni Batch</h2>
            <p class="description">Operazioni massive su tutti i video. Usare con cautela.</p>
            
            <table class="form-table">
                <tr>
                    <th scope="row">Import Batch</th>
                    <td>
                        <button type="button" class="button button-primary" id="ipv-batch-import-settings">
                            📥 Importa Ultimi 10 Video
                        </button>
                        <p class="description">Importa gli ultimi 10 video dal canale configurato.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Rigenera Tutto</th>
                    <td>
                        <button type="button" class="button button-secondary" id="ipv-batch-regenerate-all">
                            🔄 Rigenera Contenuti (primi 10 video)
                        </button>
                        <p class="description">Rigenera descrizioni e contenuti AI per i primi 10 video con trascrizione. <strong>Operazione lenta (2-5 minuti).</strong></p>
                    </td>
                </tr>
            </table>
            
            <div id="ipv-batch-results" style="margin-top: 20px; padding: 15px; background: #f5f5f5; border-radius: 4px; display: none;"></div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Batch import from settings
            $('#ipv-batch-import-settings').on('click', function() {
                if (!confirm('Importare gli ultimi 10 video? Questa operazione può richiedere diversi minuti.')) {
                    return;
                }
                
                var $button = $(this);
                var $results = $('#ipv-batch-results');
                
                $button.prop('disabled', true).html('⏳ Importazione in corso...');
                $results.html('Import avviato... attendere...').show();
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ipv_batch_import',
                        nonce: '<?php echo wp_create_nonce('ipv_video_nonce'); ?>'
                    },
                    timeout: 300000,
                    success: function(response) {
                        if (response.success) {
                            var data = response.data;
                            var html = '<h3 style="color: green;">✓ Import Completato!</h3>';
                            html += '<p><strong>Successo:</strong> ' + data.success + '</p>';
                            html += '<p><strong>Errori:</strong> ' + data.errors + '</p>';
                            html += '<p><strong>Saltati:</strong> ' + data.skipped + '</p>';
                            
                            if (data.details && data.details.length > 0) {
                                html += '<h4>Dettagli:</h4><ul>';
                                data.details.forEach(function(item) {
                                    html += '<li>' + item.video_id + ' - ' + item.status;
                                    if (item.title) html += ' - ' + item.title;
                                    html += '</li>';
                                });
                                html += '</ul>';
                            }
                            
                            $results.html(html);
                        } else {
                            $results.html('<p style="color: red;">✗ Errore: ' + response.data + '</p>');
                        }
                        $button.prop('disabled', false).html('📥 Importa Ultimi 10 Video');
                    },
                    error: function() {
                        $results.html('<p style="color: red;">✗ Errore di connessione</p>');
                        $button.prop('disabled', false).html('📥 Importa Ultimi 10 Video');
                    }
                });
            });
            
            // Batch regenerate
            $('#ipv-batch-regenerate-all').on('click', function() {
                if (!confirm('Rigenerare i contenuti per i primi 10 video? Questa operazione può richiedere 2-5 minuti e consumare crediti OpenAI.')) {
                    return;
                }
                
                var $button = $(this);
                var $results = $('#ipv-batch-results');
                
                $button.prop('disabled', true).html('⏳ Rigenerazione in corso...');
                $results.html('Rigenerazione avviata... attendere...').show();
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ipv_batch_regenerate_all',
                        nonce: '<?php echo wp_create_nonce('ipv_video_nonce'); ?>'
                    },
                    timeout: 300000,
                    success: function(response) {
                        if (response.success) {
                            var data = response.data;
                            var html = '<h3 style="color: green;">✓ Rigenerazione Completata!</h3>';
                            html += '<p><strong>Successo:</strong> ' + data.success + '</p>';
                            html += '<p><strong>Errori:</strong> ' + data.errors + '</p>';
                            
                            if (data.details && data.details.length > 0) {
                                html += '<h4>Dettagli:</h4><ul>';
                                data.details.forEach(function(item) {
                                    var color = item.status === 'success' ? 'green' : 'red';
                                    html += '<li style="color: ' + color + ';">' + item.title + ' - ' + item.status;
                                    if (item.message) html += ' (' + item.message + ')';
                                    html += '</li>';
                                });
                                html += '</ul>';
                            }
                            
                            $results.html(html);
                        } else {
                            $results.html('<p style="color: red;">✗ Errore: ' + response.data + '</p>');
                        }
                        $button.prop('disabled', false).html('🔄 Rigenera Contenuti (primi 10 video)');
                    },
                    error: function() {
                        $results.html('<p style="color: red;">✗ Errore di connessione</p>');
                        $button.prop('disabled', false).html('🔄 Rigenera Contenuti (primi 10 video)');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * CRON: Auto Import
     */
    public function cron_auto_import() {
        if (get_option('ipv_auto_import_enabled') !== '1') {
            return;
        }
        
        try {
            $api = new IPV_API();
            $result = $api->batch_import(10);
            
            // Log risultati
            if (!is_wp_error($result)) {
                error_log('IPV Auto Import: Success=' . $result['success'] . ', Errors=' . $result['errors'] . ', Skipped=' . $result['skipped']);
            }
        } catch (Exception $e) {
            error_log('IPV Auto Import Error: ' . $e->getMessage());
        }
    }
    
    /**
     * Load custom template for video single post
     */
    public function load_video_template($template) {
        global $post;
        
        if ($post->post_type == 'ipv_video' && is_single()) {
            $plugin_template = IPV_VM_PLUGIN_DIR . 'templates/single-video.php';
            
            if (file_exists($plugin_template)) {
                return $plugin_template;
            }
        }
        
        return $template;
    }
    
    /**
     * Inject video content
     */
    public function inject_video_content($content) {
        global $post;
        
        if (!is_singular('ipv_video')) {
            return $content;
        }
        
        $youtube_id = get_post_meta($post->ID, '_ipv_youtube_id', true);
        
        if (empty($youtube_id)) {
            return $content;
        }
        
        // Video embed
        $video_html = $this->render_video_embed($youtube_id);
        
        // Contenuti generati
        $generated_content = $this->render_generated_content($post->ID);
        
        return $video_html . $generated_content . $content;
    }
    
    /**
     * Render video embed
     */
    private function render_video_embed($youtube_id) {
        ob_start();
        ?>
        <div class="ipv-video-container">
            <div class="ipv-video-wrapper">
                <iframe 
                    src="https://www.youtube.com/embed/<?php echo esc_attr($youtube_id); ?>" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render generated content (formato Notion)
     */
    private function render_generated_content($post_id) {
        $descrizione = get_post_meta($post_id, '_ipv_descrizione', true);
        $sponsor = get_post_meta($post_id, '_ipv_sponsor', true);
        $timecodes = get_post_meta($post_id, '_ipv_timecodes', true);
        $argomenti = get_post_meta($post_id, '_ipv_argomenti_trattati', true);
        $ospiti = get_post_meta($post_id, '_ipv_ospiti', true);
        $persone = get_post_meta($post_id, '_ipv_persone_menzionate', true);
        $eventi = get_post_meta($post_id, '_ipv_eventi', true);
        $hashtag = get_post_meta($post_id, '_ipv_hashtag', true);
        
        ob_start();
        ?>
        <div class="ipv-video-content">
            
            <?php if ($descrizione): ?>
            <div class="ipv-section">
                <h3 class="ipv-section-title">📌 Descrizione</h3>
                <div class="ipv-section-content">
                    <?php echo nl2br(esc_html($descrizione)); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($sponsor): ?>
            <div class="ipv-section ipv-sponsor">
                <h3 class="ipv-section-title">🎁 Sponsor</h3>
                <div class="ipv-section-content">
                    <?php echo wpautop($sponsor); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($timecodes): ?>
            <div class="ipv-section">
                <h3 class="ipv-section-title">⏱️ Minutaggio</h3>
                <div class="ipv-section-content ipv-timecodes">
                    <?php echo nl2br(esc_html($timecodes)); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($argomenti): ?>
            <div class="ipv-section">
                <h3 class="ipv-section-title">📖 Argomenti Trattati</h3>
                <div class="ipv-section-content">
                    <?php echo nl2br(esc_html($argomenti)); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($ospiti && stripos($ospiti, 'nessun') === false): ?>
            <div class="ipv-section">
                <h3 class="ipv-section-title">👤 Ospiti</h3>
                <div class="ipv-section-content">
                    <?php echo nl2br(esc_html($ospiti)); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($persone && stripos($persone, 'nessun') === false): ?>
            <div class="ipv-section">
                <h3 class="ipv-section-title">📌 Persone Menzionate</h3>
                <div class="ipv-section-content">
                    <?php echo nl2br(esc_html($persone)); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($eventi && stripos($eventi, 'nessun') === false): ?>
            <div class="ipv-section">
                <h3 class="ipv-section-title">🔔 Eventi</h3>
                <div class="ipv-section-content">
                    <?php echo nl2br(esc_html($eventi)); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($hashtag): ?>
            <div class="ipv-section ipv-hashtags">
                <h3 class="ipv-section-title">#️⃣ Hashtag</h3>
                <div class="ipv-section-content">
                    <?php echo esc_html($hashtag); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="ipv-section ipv-support">
                <h3 class="ipv-section-title">❤️ Sostieni il Canale</h3>
                <div class="ipv-section-content">
                    <p>Per sostenere il canale e i progetti de Il Punto di Vista:</p>
                    <p><a href="https://paypal.me/adrianfiorelli" target="_blank" class="ipv-button">💝 Dona su PayPal</a></p>
                    <p>Grazie in anticipo a tutti i pirati 🖤🏴‍☠️</p>
                </div>
            </div>
            
            <div class="ipv-section ipv-social">
                <h3 class="ipv-section-title">🌐 Seguici sui Social</h3>
                <div class="ipv-section-content ipv-social-links">
                    <a href="https://t.me/il_punto_divista" target="_blank" class="ipv-social-link">📱 Telegram</a>
                    <a href="https://facebook.com/groups/4102938329737588" target="_blank" class="ipv-social-link">📘 Facebook</a>
                    <a href="https://instagram.com/_ilpuntodivista._" target="_blank" class="ipv-social-link">📸 Instagram</a>
                    <a href="https://www.youtube.com/@ilpuntodivista" target="_blank" class="ipv-social-link">📺 YouTube</a>
                </div>
            </div>
            
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Shortcode [ipv_video id="123"]
     */
    public function video_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => 0,
        ), $atts);
        
        $post_id = intval($atts['id']);
        
        if ($post_id <= 0) {
            return '';
        }
        
        $youtube_id = get_post_meta($post_id, '_ipv_youtube_id', true);
        
        if (empty($youtube_id)) {
            return '';
        }
        
        return $this->render_video_embed($youtube_id);
    }
    
    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets() {
        if (is_singular('ipv_video')) {
            wp_enqueue_style('ipv-frontend', IPV_VM_PLUGIN_URL . 'assets/css/frontend.css', array(), IPV_VM_VERSION);
        }
    }
    
    
    /**
     * Activation
     */
    public function activate() {
        $this->register_post_type();
        flush_rewrite_rules();
        
        // Schedule CRON se abilitato
        $this->update_cron_schedule();
        
        // STEP 3A: Schedule queue processing every 5 minutes
        if (!wp_next_scheduled('ipv_process_queue')) {
            wp_schedule_event(time(), 'hourly', 'ipv_process_queue');
        }
        
        // Set default options
        if (get_option('ipv_auto_import_interval') === false) {
            update_option('ipv_auto_import_interval', 12);
        }
        
        if (get_option('ipv_channel_url') === false) {
            update_option('ipv_channel_url', 'https://www.youtube.com/@ilpuntodivista/streams');
        }
    }
    
    /**
     * Update CRON schedule
     */
    public function update_cron_schedule() {
        // Clear existing schedule
        $timestamp = wp_next_scheduled('ipv_auto_import_videos');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'ipv_auto_import_videos');
        }
        
        // Schedule new if enabled
        if (get_option('ipv_auto_import_enabled') === '1') {
            $interval = intval(get_option('ipv_auto_import_interval', 12));
            
            // Usa schedule WordPress predefiniti
            if ($interval <= 1) {
                $recurrence = 'hourly';
            } elseif ($interval <= 12) {
                $recurrence = 'twicedaily';
            } else {
                $recurrence = 'daily';
            }
            
            wp_schedule_event(time(), $recurrence, 'ipv_auto_import_videos');
        }
    }
    
    /**
     * Deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
        
        // Clear CRON - auto import
        $timestamp = wp_next_scheduled('ipv_auto_import_videos');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'ipv_auto_import_videos');
        }
        
        // Clear CRON - queue processing (STEP 3A)
        $timestamp_queue = wp_next_scheduled('ipv_process_queue');
        if ($timestamp_queue) {
            wp_unschedule_event($timestamp_queue, 'ipv_process_queue');
        }
    }
    
    /**
     * ===================================================================
     * STEP 3A: PERFORMANCE & CORE - NEW FUNCTIONS
     * ===================================================================
     */
    
    /**
     * AJAX: Clear cache
     */
    public function ajax_clear_cache() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $cache = new IPV_Cache();
        $cache->flush();
        
        wp_send_json_success(array(
            'message' => 'Cache cleared successfully',
        ));
    }
    
    /**
     * AJAX: Warm cache
     */
    public function ajax_warm_cache() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $cache = new IPV_Cache();
        $warmed = $cache->warm_cache(20);
        
        wp_send_json_success(array(
            'message' => sprintf('Cache warmed for %d videos', $warmed),
            'warmed_count' => $warmed,
        ));
    }
    
    /**
     * AJAX: Get queue stats
     */
    public function ajax_get_queue_stats() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $queue = new IPV_Queue();
        $stats = $queue->get_stats();
        
        wp_send_json_success($stats);
    }
    
    /**
     * AJAX: Process queue manually
     */
    public function ajax_process_queue() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $queue = new IPV_Queue();
        $results = $queue->process();
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX: Clear queue
     */
    public function ajax_clear_queue() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'completed';
        
        $queue = new IPV_Queue();
        
        if ($type === 'all') {
            $queue->clear_all();
            $message = 'All queue items cleared';
        } else {
            $cleared = $queue->clear_completed();
            $message = sprintf('%d completed items cleared', $cleared);
        }
        
        wp_send_json_success(array('message' => $message));
    }
    
    /**
     * AJAX: Get system health
     */
    public function ajax_get_system_health() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $performance = new IPV_Performance();
        $health = $performance->get_system_health();
        
        wp_send_json_success($health);
    }
    
    /**
     * AJAX: Get performance metrics
     */
    public function ajax_get_performance_metrics() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $performance = new IPV_Performance();
        $metrics = $performance->get_metrics();
        
        wp_send_json_success($metrics);
    }
    
    /**
     * CRON: Process queue automatically
     */
    public function cron_process_queue() {
        $queue = new IPV_Queue();
        $queue->process();
    }
    
    /**
     * Render Performance page
     */
    public function render_performance_page() {
        $performance = new IPV_Performance();
        $cache = new IPV_Cache();
        $queue = new IPV_Queue();
        
        $health = $performance->get_system_health();
        $cache_stats = $cache->get_stats();
        $queue_stats = $queue->get_stats();
        $metrics = $performance->get_metrics();
        
        ?>
        <div class="wrap ipv-performance-page">
            <h1>📊 IPV Video Manager - Performance Monitor</h1>
            
            <div class="ipv-performance-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 20px 0;">
                
                <!-- System Health Card -->
                <div class="ipv-card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h2 style="margin-top: 0;">🏥 System Health</h2>
                    <div class="ipv-health-score" style="font-size: 48px; font-weight: bold; text-align: center; margin: 20px 0; color: <?php 
                        echo $health['status'] === 'good' ? '#10b981' : ($health['status'] === 'warning' ? '#f59e0b' : '#ef4444');
                    ?>;">
                        <?php echo round($health['overall_score']); ?>%
                    </div>
                    <div class="ipv-health-status" style="text-align: center; font-weight: bold; text-transform: uppercase;">
                        <?php echo esc_html($health['status']); ?>
                    </div>
                    
                    <div style="margin-top: 20px;">
                        <div style="margin: 10px 0;">
                            <strong>Database:</strong> 
                            <span class="ipv-status-badge" style="background: <?php echo $health['database']['status'] === 'good' ? '#10b981' : '#ef4444'; ?>; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px;">
                                <?php echo esc_html($health['database']['status']); ?>
                            </span>
                        </div>
                        <div style="margin: 10px 0;">
                            <strong>API:</strong> 
                            <span class="ipv-status-badge" style="background: <?php echo $health['api']['status'] === 'good' ? '#10b981' : '#ef4444'; ?>; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px;">
                                <?php echo esc_html($health['api']['status']); ?>
                            </span>
                        </div>
                        <div style="margin: 10px 0;">
                            <strong>Cache:</strong> 
                            <span class="ipv-status-badge" style="background: <?php echo $health['cache']['status'] === 'good' ? '#10b981' : ($health['cache']['status'] === 'warning' ? '#f59e0b' : '#ef4444'); ?>; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px;">
                                <?php echo esc_html($health['cache']['status']); ?>
                            </span>
                        </div>
                        <div style="margin: 10px 0;">
                            <strong>Queue:</strong> 
                            <span class="ipv-status-badge" style="background: <?php echo $health['queue']['status'] === 'good' ? '#10b981' : '#f59e0b'; ?>; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px;">
                                <?php echo esc_html($health['queue']['status']); ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- Cache Stats Card -->
                <div class="ipv-card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h2 style="margin-top: 0;">💾 Cache Statistics</h2>
                    <div style="margin: 15px 0;">
                        <div style="font-size: 14px; color: #666; margin-bottom: 5px;">Hit Rate</div>
                        <div style="font-size: 32px; font-weight: bold; color: #10b981;">
                            <?php echo round($cache_stats['hit_rate'], 1); ?>%
                        </div>
                    </div>
                    <div style="margin: 10px 0; padding: 10px 0; border-top: 1px solid #eee;">
                        <div><strong>Hits:</strong> <?php echo number_format($cache_stats['cache_hits']); ?></div>
                        <div><strong>Misses:</strong> <?php echo number_format($cache_stats['cache_misses']); ?></div>
                    </div>
                    <div style="margin-top: 15px;">
                        <button class="button" onclick="ipvClearCache()">🗑️ Clear Cache</button>
                        <button class="button button-primary" onclick="ipvWarmCache()">🔥 Warm Cache</button>
                    </div>
                </div>
                
                <!-- Queue Stats Card -->
                <div class="ipv-card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h2 style="margin-top: 0;">📋 Queue Status</h2>
                    <div style="margin: 10px 0;">
                        <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                            <span>Total:</span>
                            <strong><?php echo $queue_stats['total']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                            <span>Pending:</span>
                            <strong style="color: #f59e0b;"><?php echo $queue_stats['pending']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                            <span>Completed:</span>
                            <strong style="color: #10b981;"><?php echo $queue_stats['completed']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                            <span>Failed:</span>
                            <strong style="color: #ef4444;"><?php echo $queue_stats['failed']; ?></strong>
                        </div>
                    </div>
                    <div style="margin-top: 15px;">
                        <button class="button button-primary" onclick="ipvProcessQueue()">▶️ Process Queue</button>
                        <button class="button" onclick="ipvClearQueue('completed')">Clear Completed</button>
                    </div>
                </div>
                
                <!-- Memory & Disk Card -->
                <div class="ipv-card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h2 style="margin-top: 0;">💻 Resources</h2>
                    <div style="margin: 15px 0;">
                        <div style="margin-bottom: 15px;">
                            <div style="font-size: 14px; color: #666;">Memory Usage</div>
                            <div style="background: #f3f4f6; height: 20px; border-radius: 10px; overflow: hidden; margin: 5px 0;">
                                <div style="background: <?php echo $health['memory_usage']['status'] === 'good' ? '#10b981' : '#ef4444'; ?>; height: 100%; width: <?php echo $health['memory_usage']['usage_percent']; ?>%;"></div>
                            </div>
                            <div style="font-size: 12px; color: #666;">
                                <?php echo $health['memory_usage']['memory_usage']; ?> / <?php echo $health['memory_usage']['memory_limit']; ?> 
                                (<?php echo round($health['memory_usage']['usage_percent'], 1); ?>%)
                            </div>
                        </div>
                        
                        <div>
                            <div style="font-size: 14px; color: #666;">Disk Space</div>
                            <div style="background: #f3f4f6; height: 20px; border-radius: 10px; overflow: hidden; margin: 5px 0;">
                                <div style="background: <?php echo $health['disk_space']['status'] === 'good' ? '#10b981' : '#ef4444'; ?>; height: 100%; width: <?php echo $health['disk_space']['used_percent']; ?>%;"></div>
                            </div>
                            <div style="font-size: 12px; color: #666;">
                                <?php echo $health['disk_space']['free_space']; ?> free 
                                (<?php echo round($health['disk_space']['used_percent'], 1); ?>% used)
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Performance Metrics Table -->
            <?php if (!empty($metrics)): ?>
            <div class="ipv-card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-top: 20px;">
                <h2>⚡ Performance Metrics</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Operation</th>
                            <th>Count</th>
                            <th>Avg Time</th>
                            <th>Min Time</th>
                            <th>Max Time</th>
                            <th>Last Execution</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($metrics as $operation => $data): ?>
                        <tr>
                            <td><strong><?php echo esc_html($operation); ?></strong></td>
                            <td><?php echo number_format($data['count']); ?></td>
                            <td><?php echo round($data['avg_time'], 3); ?>s</td>
                            <td><?php echo round($data['min_time'], 3); ?>s</td>
                            <td><?php echo round($data['max_time'], 3); ?>s</td>
                            <td><?php echo $data['last_execution'] ? esc_html($data['last_execution']) : '-'; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            
            <script>
            function ipvClearCache() {
                if (!confirm('Are you sure you want to clear all cache?')) return;
                
                jQuery.post(ajaxurl, {
                    action: 'ipv_clear_cache',
                    nonce: ipvAdmin.nonce
                }, function(response) {
                    if (response.success) {
                        alert('Cache cleared successfully!');
                        location.reload();
                    }
                });
            }
            
            function ipvWarmCache() {
                jQuery.post(ajaxurl, {
                    action: 'ipv_warm_cache',
                    nonce: ipvAdmin.nonce
                }, function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    }
                });
            }
            
            function ipvProcessQueue() {
                jQuery.post(ajaxurl, {
                    action: 'ipv_process_queue',
                    nonce: ipvAdmin.nonce
                }, function(response) {
                    if (response.success) {
                        alert('Queue processed: ' + response.data.processed + ' completed, ' + response.data.failed + ' failed');
                        location.reload();
                    }
                });
            }
            
            function ipvClearQueue(type) {
                if (!confirm('Clear ' + type + ' queue items?')) return;
                
                jQuery.post(ajaxurl, {
                    action: 'ipv_clear_queue',
                    nonce: ipvAdmin.nonce,
                    type: type
                }, function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    }
                });
            }
            </script>
        </div>
        <?php
    }
    
    /**
     * ===================================================================
     * STEP 3B: DASHBOARD & ANALYTICS - NEW FUNCTIONS
     * ===================================================================
     */
    
    /**
     * AJAX: Get dashboard stats
     */
    public function ajax_get_dashboard_stats() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $analytics = new IPV_Analytics();
        $stats = $analytics->get_dashboard_stats();
        
        wp_send_json_success($stats);
    }
    
    /**
     * AJAX: Get SEO score for video
     */
    public function ajax_get_seo_score() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        if (!$post_id) {
            wp_send_json_error('Post ID required');
        }
        
        $analytics = new IPV_Analytics();
        $seo_score = $analytics->get_seo_score($post_id);
        
        wp_send_json_success($seo_score);
    }
    
    /**
     * AJAX: Get calendar data
     */
    public function ajax_get_calendar_data() {
        check_ajax_referer('ipv_video_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $month = isset($_POST['month']) ? sanitize_text_field($_POST['month']) : null;
        
        $analytics = new IPV_Analytics();
        $calendar = $analytics->get_calendar_data($month);
        
        wp_send_json_success($calendar);
    }
    
    /**
     * Render Dashboard page
     */
    public function render_dashboard_page() {
        $analytics = new IPV_Analytics();
        $stats = $analytics->get_dashboard_stats();
        $costs = $analytics->get_api_costs();
        
        ?>
        <div class="wrap ipv-dashboard-page">
            <h1>📊 IPV Video Manager - Dashboard</h1>
            
            <!-- Stats Overview Cards -->
            <div class="ipv-stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0;">
                
                <!-- Total Videos -->
                <div class="ipv-stat-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">📹 Total Videos</div>
                    <div style="font-size: 42px; font-weight: bold;"><?php echo number_format($stats['total_videos']); ?></div>
                    <div style="font-size: 12px; opacity: 0.8; margin-top: 10px;">All published & drafts</div>
                </div>
                
                <!-- Total Views -->
                <div class="ipv-stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">👁️ Total Views</div>
                    <div style="font-size: 42px; font-weight: bold;"><?php echo number_format($stats['total_views']); ?></div>
                    <div style="font-size: 12px; opacity: 0.8; margin-top: 10px;">Across all videos</div>
                </div>
                
                <!-- This Month -->
                <div class="ipv-stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">📅 This Month</div>
                    <div style="font-size: 42px; font-weight: bold;"><?php echo number_format($stats['published_this_month']); ?></div>
                    <div style="font-size: 12px; opacity: 0.8; margin-top: 10px;">Videos published</div>
                </div>
                
                <!-- Avg Views -->
                <div class="ipv-stat-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">📈 Avg Views</div>
                    <div style="font-size: 42px; font-weight: bold;"><?php echo number_format($stats['avg_views_per_video']); ?></div>
                    <div style="font-size: 12px; opacity: 0.8; margin-top: 10px;">Per video</div>
                </div>
                
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin: 20px 0;">
                
                <!-- Left Column: Charts & Top Videos -->
                <div>
                    
                    <!-- Views Trend Chart -->
                    <div class="ipv-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px;">
                        <h2 style="margin-top: 0; display: flex; align-items: center; gap: 10px;">
                            📈 Views Trend (Last 30 Days)
                        </h2>
                        <canvas id="ipv-views-chart" style="max-height: 300px;"></canvas>
                    </div>
                    
                    <!-- Top Performing Videos -->
                    <div class="ipv-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                        <h2 style="margin-top: 0;">🔥 Top Performing Videos</h2>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th>Video</th>
                                    <th style="width: 120px; text-align: right;">Views</th>
                                    <th style="width: 150px;">Published</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stats['top_performing'] as $video): ?>
                                <tr>
                                    <td>
                                        <strong>
                                            <a href="<?php echo esc_url($video['url']); ?>" target="_blank">
                                                <?php echo esc_html($video['title']); ?>
                                            </a>
                                        </strong>
                                    </td>
                                    <td style="text-align: right; font-weight: bold; color: #f5576c;">
                                        <?php echo number_format($video['views']); ?>
                                    </td>
                                    <td>
                                        <?php echo date('M d, Y', strtotime($video['published'])); ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($stats['top_performing'])): ?>
                                <tr>
                                    <td colspan="3" style="text-align: center; color: #999;">No videos yet</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
                
                <!-- Right Column: API Costs & Recent Activity -->
                <div>
                    
                    <!-- API Costs -->
                    <div class="ipv-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px;">
                        <h2 style="margin-top: 0;">💰 API Costs Estimate</h2>
                        
                        <div style="margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <div style="display: flex; justify-content: space-between; margin: 10px 0;">
                                <span>Supadata:</span>
                                <strong>$<?php echo number_format($costs['supadata']['total'], 2); ?></strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin: 10px 0;">
                                <span>OpenAI:</span>
                                <strong>$<?php echo number_format($costs['openai']['total'], 2); ?></strong>
                            </div>
                            <hr style="border: none; border-top: 2px solid #dee2e6; margin: 15px 0;">
                            <div style="display: flex; justify-content: space-between; margin: 10px 0; font-size: 18px;">
                                <span><strong>Total:</strong></span>
                                <strong style="color: #f5576c;">$<?php echo number_format($costs['total'], 2); ?></strong>
                            </div>
                        </div>
                        
                        <div style="font-size: 12px; color: #666; text-align: center; padding: 10px; background: #fff3cd; border-radius: 6px;">
                            ℹ️ Monthly estimate: <strong>$<?php echo number_format($costs['monthly_estimate'], 2); ?></strong>
                        </div>
                    </div>
                    
                    <!-- Recent Activity -->
                    <div class="ipv-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                        <h2 style="margin-top: 0;">🕐 Recent Activity</h2>
                        <div style="max-height: 400px; overflow-y: auto;">
                            <?php foreach ($stats['recent_activity'] as $activity): ?>
                            <div style="padding: 12px; margin: 8px 0; background: #f8f9fa; border-radius: 6px; border-left: 4px solid <?php echo $activity['status'] === 'publish' ? '#43e97b' : '#f5a623'; ?>;">
                                <div style="font-weight: bold; margin-bottom: 5px;">
                                    <?php echo esc_html($activity['title']); ?>
                                </div>
                                <div style="font-size: 12px; color: #666;">
                                    <span class="ipv-badge" style="background: <?php echo $activity['status'] === 'publish' ? '#43e97b' : '#f5a623'; ?>; color: white; padding: 2px 8px; border-radius: 3px; font-size: 10px; text-transform: uppercase;">
                                        <?php echo esc_html($activity['status']); ?>
                                    </span>
                                    • <?php echo esc_html($activity['action']); ?>
                                    • <?php echo human_time_diff(strtotime($activity['modified']), current_time('timestamp')); ?> ago
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php if (empty($stats['recent_activity'])): ?>
                            <p style="text-align: center; color: #999; padding: 20px;">No recent activity</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            
            <!-- Publishing Frequency -->
            <div class="ipv-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-top: 20px;">
                <h2 style="margin-top: 0;">📅 Publishing Frequency</h2>
                <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 10px; text-align: center;">
                    <?php foreach ($stats['publishing_frequency']['daily'] as $day): ?>
                    <div style="padding: 15px; background: <?php echo $day['count'] > 0 ? '#43e97b' : '#f8f9fa'; ?>; border-radius: 8px; color: <?php echo $day['count'] > 0 ? 'white' : '#666'; ?>;">
                        <div style="font-size: 12px; font-weight: bold; margin-bottom: 5px;"><?php echo $day['day']; ?></div>
                        <div style="font-size: 24px; font-weight: bold;"><?php echo $day['count']; ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                    <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                        <div style="font-size: 14px; color: #666; margin-bottom: 5px;">This Week</div>
                        <div style="font-size: 32px; font-weight: bold; color: #4facfe;"><?php echo $stats['publishing_frequency']['weekly']; ?></div>
                    </div>
                    <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                        <div style="font-size: 14px; color: #666; margin-bottom: 5px;">This Month</div>
                        <div style="font-size: 32px; font-weight: bold; color: #43e97b;"><?php echo $stats['publishing_frequency']['monthly']; ?></div>
                    </div>
                </div>
            </div>
            
        </div>
        
        <!-- Chart.js for graphs -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
        <script>
        jQuery(document).ready(function($) {
            // Views Trend Chart
            const ctx = document.getElementById('ipv-views-chart');
            if (ctx) {
                const viewsTrend = <?php echo wp_json_encode($stats['views_trend']); ?>;
                
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: viewsTrend.map(d => {
                            const date = new Date(d.date);
                            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                        }),
                        datasets: [{
                            label: 'Views',
                            data: viewsTrend.map(d => d.views),
                            borderColor: '#f5576c',
                            backgroundColor: 'rgba(245, 87, 108, 0.1)',
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return value.toLocaleString();
                                    }
                                }
                            }
                        }
                    }
                });
            }
        });
        </script>
        <?php
    }
    
    /**
     * ===================================================================
     * STEP 3D: INTEGRATIONS - NEW FUNCTION
     * ===================================================================
     */
    
    /**
     * Render Integrations page
     */
    public function render_integrations_page() {
        // Save settings
        if (isset($_POST['ipv_save_integrations']) && check_admin_referer('ipv_integrations', 'ipv_integrations_nonce')) {
            // Telegram
            update_option('ipv_telegram_enabled', isset($_POST['ipv_telegram_enabled']) ? '1' : '0');
            update_option('ipv_telegram_bot_token', sanitize_text_field($_POST['ipv_telegram_bot_token']));
            update_option('ipv_telegram_chat_id', sanitize_text_field($_POST['ipv_telegram_chat_id']));
            
            // Discord
            update_option('ipv_discord_enabled', isset($_POST['ipv_discord_enabled']) ? '1' : '0');
            update_option('ipv_discord_webhook_url', esc_url_raw($_POST['ipv_discord_webhook_url']));
            
            // Mailchimp
            update_option('ipv_mailchimp_enabled', isset($_POST['ipv_mailchimp_enabled']) ? '1' : '0');
            update_option('ipv_mailchimp_api_key', sanitize_text_field($_POST['ipv_mailchimp_api_key']));
            update_option('ipv_mailchimp_list_id', sanitize_text_field($_POST['ipv_mailchimp_list_id']));
            
            echo '<div class="notice notice-success"><p>✅ Integration settings saved!</p></div>';
        }
        
        $notifications = new IPV_Notifications();
        $settings = $notifications->get_settings();
        
        ?>
        <div class="wrap ipv-integrations-page">
            <h1>🧩 IPV Video Manager - Integrations</h1>
            <p>Configure integrations with third-party services and tools.</p>
            
            <!-- Integration Status Cards -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 30px 0;">
                
                <!-- Elementor -->
                <div class="ipv-integration-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                        <div style="font-size: 40px;">🎨</div>
                        <div>
                            <h3 style="margin: 0;">Elementor</h3>
                            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Page Builder Widgets</p>
                        </div>
                    </div>
                    <?php if (IPV_Elementor::is_elementor_active()): ?>
                        <div style="padding: 10px; background: #d4edda; border-radius: 6px; color: #155724; font-size: 14px;">
                            ✅ <strong>Active</strong> - 3 widgets available
                        </div>
                        <ul style="margin-top: 15px; font-size: 14px; color: #666;">
                            <li>🎬 Video Player Widget</li>
                            <li>🎞️ Video Grid Widget</li>
                            <li>📋 Video List Widget</li>
                        </ul>
                    <?php else: ?>
                        <div style="padding: 10px; background: #f8d7da; border-radius: 6px; color: #721c24; font-size: 14px;">
                            ❌ <strong>Not Available</strong> - Elementor not installed
                        </div>
                        <p style="margin-top: 15px; font-size: 14px;">
                            <a href="https://elementor.com" target="_blank" class="button">Install Elementor</a>
                        </p>
                    <?php endif; ?>
                </div>
                
                <!-- Gutenberg -->
                <div class="ipv-integration-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                        <div style="font-size: 40px;">📝</div>
                        <div>
                            <h3 style="margin: 0;">Gutenberg</h3>
                            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Block Editor</p>
                        </div>
                    </div>
                    <div style="padding: 10px; background: #d4edda; border-radius: 6px; color: #155724; font-size: 14px;">
                        ✅ <strong>Active</strong> - 2 blocks available
                    </div>
                    <ul style="margin-top: 15px; font-size: 14px; color: #666;">
                        <li>🎬 Video Player Block</li>
                        <li>🎞️ Video Grid Block</li>
                    </ul>
                </div>
                
                <!-- WooCommerce -->
                <div class="ipv-integration-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                        <div style="font-size: 40px;">🛒</div>
                        <div>
                            <h3 style="margin: 0;">WooCommerce</h3>
                            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Product Videos</p>
                        </div>
                    </div>
                    <?php if (IPV_WooCommerce::is_woocommerce_active()): ?>
                        <div style="padding: 10px; background: #d4edda; border-radius: 6px; color: #155724; font-size: 14px;">
                            ✅ <strong>Active</strong> - Link videos to products
                        </div>
                        <ul style="margin-top: 15px; font-size: 14px; color: #666;">
                            <li>📦 Product Video Tab</li>
                            <li>🎬 Video Metabox</li>
                            <li>📋 Video Column in Products List</li>
                        </ul>
                    <?php else: ?>
                        <div style="padding: 10px; background: #f8d7da; border-radius: 6px; color: #721c24; font-size: 14px;">
                            ❌ <strong>Not Available</strong> - WooCommerce not installed
                        </div>
                        <p style="margin-top: 15px; font-size: 14px;">
                            <a href="https://woocommerce.com" target="_blank" class="button">Install WooCommerce</a>
                        </p>
                    <?php endif; ?>
                </div>
                
            </div>
            
            <!-- Notifications Settings -->
            <div class="ipv-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-top: 20px;">
                <h2>🔔 Notification Settings</h2>
                <p>Send automatic notifications when new videos are published.</p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('ipv_integrations', 'ipv_integrations_nonce'); ?>
                    
                    <table class="form-table">
                        
                        <!-- Telegram -->
                        <tr>
                            <th colspan="2"><h3>📱 Telegram</h3></th>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label>
                                    <input type="checkbox" name="ipv_telegram_enabled" value="1" 
                                           <?php checked($settings['telegram']['enabled'], '1'); ?>>
                                    Enable Telegram Notifications
                                </label>
                            </th>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row"><label>Bot Token</label></th>
                            <td>
                                <input type="text" name="ipv_telegram_bot_token" 
                                       value="<?php echo esc_attr($settings['telegram']['bot_token']); ?>" 
                                       class="regular-text" placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz">
                                <p class="description">Get from <a href="https://t.me/botfather" target="_blank">@BotFather</a></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label>Chat ID</label></th>
                            <td>
                                <input type="text" name="ipv_telegram_chat_id" 
                                       value="<?php echo esc_attr($settings['telegram']['chat_id']); ?>" 
                                       class="regular-text" placeholder="-100123456789">
                                <p class="description">Your group/channel chat ID</p>
                            </td>
                        </tr>
                        
                        <!-- Discord -->
                        <tr>
                            <th colspan="2"><h3 style="margin-top: 30px;">💬 Discord</h3></th>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label>
                                    <input type="checkbox" name="ipv_discord_enabled" value="1" 
                                           <?php checked($settings['discord']['enabled'], '1'); ?>>
                                    Enable Discord Notifications
                                </label>
                            </th>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row"><label>Webhook URL</label></th>
                            <td>
                                <input type="url" name="ipv_discord_webhook_url" 
                                       value="<?php echo esc_attr($settings['discord']['webhook_url']); ?>" 
                                       class="regular-text" placeholder="https://discord.com/api/webhooks/...">
                                <p class="description">Create webhook in Discord server settings</p>
                            </td>
                        </tr>
                        
                        <!-- Mailchimp -->
                        <tr>
                            <th colspan="2"><h3 style="margin-top: 30px;">📧 Mailchimp</h3></th>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label>
                                    <input type="checkbox" name="ipv_mailchimp_enabled" value="1" 
                                           <?php checked($settings['mailchimp']['enabled'], '1'); ?>>
                                    Enable Mailchimp Campaigns
                                </label>
                            </th>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row"><label>API Key</label></th>
                            <td>
                                <input type="text" name="ipv_mailchimp_api_key" 
                                       value="<?php echo esc_attr($settings['mailchimp']['api_key']); ?>" 
                                       class="regular-text" placeholder="abc123xyz-us1">
                                <p class="description">Get from Mailchimp Account → Extras → API Keys</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label>List ID</label></th>
                            <td>
                                <input type="text" name="ipv_mailchimp_list_id" 
                                       value="<?php echo esc_attr($settings['mailchimp']['list_id']); ?>" 
                                       class="regular-text" placeholder="abc123xyz">
                                <p class="description">Your audience/list ID</p>
                            </td>
                        </tr>
                        
                    </table>
                    
                    <p class="submit">
                        <button type="submit" name="ipv_save_integrations" class="button button-primary button-large">
                            💾 Save Integration Settings
                        </button>
                    </p>
                </form>
            </div>
            
        </div>
        <?php
    }
}

// Initialize plugin
function ipv_video_manager() {
    return IPV_Video_Manager::instance();
}

/**
 * Helper function: Normalize transcript data
 * Converte transcript da qualsiasi formato (array, JSON, string) a stringa pulita
 * 
 * @param mixed $transcript Transcript in any format
 * @return string Clean transcript text
 */
function ipv_normalize_transcript($transcript) {
    // Caso 1: Se è una stringa JSON, decodificala
    if (is_string($transcript) && (substr($transcript, 0, 1) === '[' || substr($transcript, 0, 1) === '{')) {
        $decoded = json_decode($transcript, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $transcript = $decoded;
        }
    }
    
    // Caso 2: Se è un array, convertilo in stringa
    if (is_array($transcript)) {
        $text_parts = array();
        
        // Array multidimensionale (con chiavi 'content', 'text', etc)
        if (isset($transcript['content'])) {
            $text_parts[] = $transcript['content'];
        } elseif (isset($transcript['text'])) {
            $text_parts[] = $transcript['text'];
        } elseif (isset($transcript['transcript'])) {
            $text_parts[] = $transcript['transcript'];
        } else {
            // Array di elementi - estrai il testo da ciascuno
            foreach ($transcript as $item) {
                if (is_array($item)) {
                    if (isset($item['content'])) {
                        $text_parts[] = $item['content'];
                    } elseif (isset($item['text'])) {
                        $text_parts[] = $item['text'];
                    } elseif (isset($item['transcript'])) {
                        $text_parts[] = $item['transcript'];
                    } else {
                        // Se è un array senza chiavi note, skippa
                        continue;
                    }
                } elseif (is_string($item)) {
                    $text_parts[] = $item;
                }
            }
        }
        
        $transcript = implode("\n\n", $text_parts);
    }
    
    // Assicurati che sia una stringa
    return (string) $transcript;
}

ipv_video_manager();
