# SupaData Integration - Documentazione Completa

## 📋 Panoramica

Integrazione completa con **SupaData API v1** per ottenere transcript da:
- ✅ YouTube
- ✅ TikTok  
- ✅ Instagram
- ✅ X (Twitter)
- ✅ File pubblici (MP4, MP3, WEBM, etc.)

## 🔑 API Key

Ottieni la tua API key su: https://dash.supadata.ai/organizations/api-key

## 🚀 Quick Start

### 1. Configurazione Base

```php
// Nelle impostazioni WordPress (Settings API)
$settings = [
    'supadata_key' => 'YOUR_API_KEY',
    'supadata_base' => 'https://api.supadata.ai/v1', // default
    'supadata_timeout' => 60, // secondi
    'supadata_mode' => 'auto', // auto|native|generate
    'supadata_lang' => 'en' // ISO 639-1
];

update_option('ipv_settings', $settings);
```

### 2. Test Connessione

```php
$result = IPV_SupaData::test_connection();

if ($result['success']) {
    echo "✓ API key valida!";
} else {
    echo "✗ Errore: " . $result['message'];
}
```

### 3. Fetch Transcript Base

```php
// Transcript YouTube (mode auto)
$transcript = IPV_SupaData::fetch_transcript('dQw4w9WgXcQ');

if ($transcript) {
    echo "Lingua: " . $transcript['lang'] . "\n";
    echo "Content: " . $transcript['content'] . "\n";
    echo "Altre lingue: " . implode(', ', $transcript['availableLangs']);
}
```

## 📖 Metodi API

### `fetch_transcript($youtube_id, $options = [])`

Recupera transcript da qualsiasi piattaforma supportata.

**Parametri:**
- `$youtube_id` (string): ID video YouTube (opzionale se URL in meta)
- `$options` (array): Opzioni aggiuntive

**Opzioni disponibili:**

```php
$options = [
    'lang' => 'it',          // ISO 639-1 (en, it, es, fr, de, etc.)
    'mode' => 'auto',        // auto|native|generate
    'text' => true,          // true=plain text, false=chunks con timestamp
    'chunkSize' => 100       // max caratteri per chunk (solo se text=false)
];
```

**Ritorna:**
```php
[
    'content' => string,           // Transcript text
    'lang' => string,              // Lingua (ISO 639-1)
    'availableLangs' => array      // Lingue disponibili
]
// oppure null in caso di errore
```

**Esempi:**

```php
// 1) Transcript YouTube in italiano (mode auto)
$result = IPV_SupaData::fetch_transcript('dQw4w9WgXcQ', [
    'lang' => 'it',
    'mode' => 'auto'
]);

// 2) Solo sottotitoli nativi (no AI generation)
$result = IPV_SupaData::fetch_transcript('dQw4w9WgXcQ', [
    'mode' => 'native' // Evita costi AI
]);

// 3) Forza generazione AI (utile se sottotitoli mancanti)
$result = IPV_SupaData::fetch_transcript('dQw4w9WgXcQ', [
    'mode' => 'generate' // Usa AI (costa 2 crediti/minuto)
]);

// 4) Transcript con timestamp
$result = IPV_SupaData::fetch_transcript('dQw4w9WgXcQ', [
    'text' => false,    // Chunks con timestamp
    'chunkSize' => 200
]);

// 5) TikTok video
$result = IPV_SupaData::fetch_transcript('', [
    // Imposta URL in meta '_ipv_youtube_url' prima
]);

// 6) File MP4 pubblico
// Imposta URL in meta: https://bucket.s3.amazonaws.com/video.mp4
$result = IPV_SupaData::fetch_transcript('');
```

---

### `test_connection()`

Testa la connessione API e valida l'API key.

**Ritorna:**
```php
[
    'success' => bool,      // true se connessione OK
    'message' => string,    // Messaggio descrittivo
    'code' => int          // HTTP status code
]
```

**Esempi:**

```php
$test = IPV_SupaData::test_connection();

switch ($test['code']) {
    case 200:
        echo "✓ Connessione OK!";
        break;
    case 401:
        echo "✗ API key non valida";
        break;
    case 404:
        echo "✓ API key valida (video test non trovato, normale)";
        break;
    default:
        echo "✗ Errore: " . $test['message'];
}
```

---

### `validate_url($url)`

Valida se un URL è supportato da SupaData.

**Parametri:**
- `$url` (string): URL da validare

**Ritorna:**
```php
[
    'valid' => bool,        // true se valido
    'platform' => string,   // youtube.com|tiktok.com|instagram.com|x.com|file|unknown
    'message' => string     // Messaggio descrittivo
]
```

**Esempi:**

```php
// YouTube
$check = IPV_SupaData::validate_url('https://www.youtube.com/watch?v=abc123');
// ['valid' => true, 'platform' => 'youtube.com', 'message' => 'URL youtube.com valido']

// TikTok
$check = IPV_SupaData::validate_url('https://www.tiktok.com/@user/video/123');
// ['valid' => true, 'platform' => 'tiktok.com', ...]

// File MP4
$check = IPV_SupaData::validate_url('https://cdn.example.com/video.mp4');
// ['valid' => true, 'platform' => 'file', 'message' => 'File URL valido (MP4)']

// URL non supportato
$check = IPV_SupaData::validate_url('https://facebook.com/video/123');
// ['valid' => false, 'platform' => 'unknown', 'message' => 'URL non supportato...']
```

---

### `estimate_credits($mode, $duration_minutes = null)`

Stima i crediti necessari per una richiesta.

**Parametri:**
- `$mode` (string): 'native'|'generate'|'auto'
- `$duration_minutes` (int|null): Durata video in minuti (solo per generate)

**Ritorna:** int|string (numero crediti o 'varies')

**Esempi:**

```php
// Native transcript: sempre 1 credito
$credits = IPV_SupaData::estimate_credits('native');
// => 1

// Generate per video 5 minuti: 2 crediti/minuto
$credits = IPV_SupaData::estimate_credits('generate', 5);
// => 10 crediti

// Auto mode: varia
$credits = IPV_SupaData::estimate_credits('auto', 10);
// => 'varies' (dipende se trova native o genera)
```

---

## 🎯 Mode: Quando usare quale?

### `mode=auto` (Default, Consigliato)
- ✅ Cerca prima sottotitoli nativi (1 credito)
- ✅ Se non trova, genera con AI (2 crediti/min)
- ✅ Migliore compromesso qualità/costi

**Usa quando:**
- Non sai se il video ha sottotitoli
- Vuoi massima affidabilità
- Il costo non è un problema

```php
$result = IPV_SupaData::fetch_transcript($video_id, [
    'mode' => 'auto' // Default, migliore scelta
]);
```

---

### `mode=native` (Solo Sottotitoli)
- ✅ Solo transcript esistenti (1 credito)
- ✅ Nessun costo AI generation
- ❌ Fallisce se sottotitoli assenti

**Usa quando:**
- Vuoi evitare costi AI
- Sai che il video ha sottotitoli
- Elabori molti video (batch)

```php
$result = IPV_SupaData::fetch_transcript($video_id, [
    'mode' => 'native' // Solo se sottotitoli esistono
]);

if ($result === null) {
    echo "Sottotitoli non disponibili";
}
```

---

### `mode=generate` (Solo AI Generation)
- ✅ Sempre genera con AI (2 crediti/min)
- ✅ Funziona anche senza sottotitoli
- ❌ Più costoso

**Usa quando:**
- Sottotitoli nativi sono di bassa qualità
- Video non ha sottotitoli
- Vuoi transcript nella lingua del video (ignora lang param)

```php
$result = IPV_SupaData::fetch_transcript($video_id, [
    'mode' => 'generate' // Forza AI generation
]);
```

---

## 🌍 Lingue Supportate

Codici ISO 639-1 comuni:

| Codice | Lingua |
|--------|--------|
| `en` | English |
| `it` | Italiano |
| `es` | Español |
| `fr` | Français |
| `de` | Deutsch |
| `pt` | Português |
| `ru` | Русский |
| `zh` | 中文 |
| `ja` | 日本語 |
| `ko` | 한국어 |

**Lista completa:** https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes

**Gestione lingue non disponibili:**

```php
$result = IPV_SupaData::fetch_transcript($video_id, [
    'lang' => 'it' // Preferenza italiano
]);

if ($result && $result['lang'] !== 'it') {
    echo "Italiano non disponibile. Lingue disponibili: ";
    echo implode(', ', $result['availableLangs']);
    
    // Fallback: riprova con inglese
    $result = IPV_SupaData::fetch_transcript($video_id, [
        'lang' => 'en'
    ]);
}
```

---

## ⚙️ Configurazione Avanzata

### Timeout Personalizzato

```php
// Per video lunghi: aumenta timeout
$settings['supadata_timeout'] = 120; // 2 minuti
update_option('ipv_settings', $settings);
```

### Polling Asincrono

Il plugin gestisce automaticamente:
- ✅ HTTP 202 (job asincrono)
- ✅ Polling intelligente con backoff esponenziale
- ✅ Stati job: queued → active → completed/failed
- ✅ Timeout configurabile

**Non serve fare nulla!** Il plugin gestisce tutto automaticamente.

---

## 📊 Pricing

### Crediti SupaData

| Operazione | Costi |
|-----------|-------|
| Native transcript | 1 credito |
| Generated transcript | 2 crediti/minuto |
| Mode auto | 1-2+ crediti (varia) |

### Esempi Pratici

```php
// Video 10 minuti con sottotitoli (mode=native)
// 1 credito

// Video 10 minuti senza sottotitoli (mode=auto)
// 20 crediti (genera 10 minuti × 2)

// Video 5 minuti (mode=generate)
// 10 crediti (forza generation)
```

**💡 Tip:** Usa `mode=native` per batch processing e risparmia crediti!

---

## 🐛 Debugging & Logs

Tutti gli errori sono loggati automaticamente in `IPV_Logger`:

```php
// Abilita logging debug
add_filter('ipv_log_level', function() {
    return 'debug'; // debug|info|warn|error
});

// Visualizza logs
$logs = IPV_Logger::get_logs();
foreach ($logs as $log) {
    echo "[{$log['level']}] {$log['message']}\n";
}
```

**Logs SupaData tipici:**

```
[info] SupaData: Processing youtube.com URL: https://youtu.be/abc123
[debug] SupaData: Request endpoint: https://api.supadata.ai/v1/transcript?url=...
[debug] SupaData: Response code: 202
[info] SupaData: Job asincrono ricevuto: 123e4567-e89b-12d3-a456-426614174000
[debug] SupaData: Polling job (elapsed: 2s)...
[info] SupaData: Job status: active
[debug] SupaData: Polling job (elapsed: 5s)...
[info] SupaData: Job status: completed
```

---

## 🔧 Troubleshooting

### Errore: "API key non valida"
```php
// Verifica API key
$test = IPV_SupaData::test_connection();
echo $test['message'];

// Se 401: controlla key su https://dash.supadata.ai
```

### Errore: "Video non trovato"
```php
// Verifica URL
$check = IPV_SupaData::validate_url($video_url);
if (!$check['valid']) {
    echo "URL non valido: " . $check['message'];
}
```

### Timeout durante polling
```php
// Aumenta timeout nelle settings
$settings['supadata_timeout'] = 180; // 3 minuti
update_option('ipv_settings', $settings);
```

### Rate Limit (429)
```php
// Aggiungi delay tra richieste
foreach ($video_ids as $id) {
    $result = IPV_SupaData::fetch_transcript($id);
    sleep(1); // 1 secondo tra richieste
}
```

---

## ✅ Best Practices

### 1. Usa mode=native per batch
```php
// Elaborazione batch: minimizza costi
$videos = get_posts(['post_type' => 'ipv_video']);

foreach ($videos as $video) {
    $result = IPV_SupaData::fetch_transcript($video->ID, [
        'mode' => 'native' // Solo 1 credito per video
    ]);
    
    if ($result) {
        update_post_meta($video->ID, '_transcript', $result['content']);
    }
    
    sleep(1); // Evita rate limit
}
```

### 2. Cache i risultati
```php
// Salva transcript in post meta
$transcript = IPV_SupaData::fetch_transcript($video_id);
if ($transcript) {
    update_post_meta($post_id, '_ipv_transcript', $transcript['content']);
    update_post_meta($post_id, '_ipv_transcript_lang', $transcript['lang']);
}

// Riusa invece di ri-fetcare
$cached = get_post_meta($post_id, '_ipv_transcript', true);
if ($cached) {
    return $cached; // Usa cache
}
```

### 3. Gestisci fallback lingue
```php
$preferred_langs = ['it', 'en', 'es']; // Ordine preferenza

$result = null;
foreach ($preferred_langs as $lang) {
    $result = IPV_SupaData::fetch_transcript($video_id, [
        'lang' => $lang,
        'mode' => 'native'
    ]);
    
    if ($result) {
        break; // Trovato!
    }
}
```

### 4. Monitora crediti
```php
// Stima prima di fetchare
$duration = 10; // minuti
$mode = 'auto';

$estimated = IPV_SupaData::estimate_credits($mode, $duration);
echo "Costo stimato: {$estimated} crediti";

// Procedi solo se accettabile
if ($estimated <= 20) {
    $result = IPV_SupaData::fetch_transcript($video_id);
}
```

---

## 🧪 Testing

Esegui test suite completa:

```bash
# Via WP-CLI
wp eval-file includes/class-supadata-tests.php

# Oppure includi nel plugin
require_once 'includes/class-supadata-tests.php';
IPV_SupaData_Tests::run_all();
```

---

## 📚 Risorse

- **API Docs:** https://docs.supadata.ai/api-reference/transcript
- **Dashboard:** https://dash.supadata.ai
- **Pricing:** https://supadata.ai/pricing
- **Support:** https://supadata.ai/support

---

## 🎉 Conclusione

L'integrazione SupaData è ora completa e production-ready!

**Features implementate:**
- ✅ Tutte le piattaforme supportate (YouTube, TikTok, Instagram, X, File)
- ✅ Mode: auto, native, generate
- ✅ Gestione sincrona e asincrona (HTTP 200/202)
- ✅ Polling intelligente con backoff
- ✅ Multi-lingua con fallback
- ✅ Validazione URL
- ✅ Logging completo
- ✅ Test suite
- ✅ Error handling
- ✅ Stima crediti

**Pronto per la produzione!** 🚀
