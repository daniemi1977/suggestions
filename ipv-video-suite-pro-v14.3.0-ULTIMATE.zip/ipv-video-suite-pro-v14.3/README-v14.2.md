# 🎬 IPV Video Suite Pro v14.2 - Commercial Edition

**Enterprise WordPress Plugin per "Il Punto di Vista"**

Plugin completo per la gestione professionale di contenuti video YouTube con automazione AI, ottimizzazione SEO e analytics integrate.

---

## 🚀 VERSIONE 14.2.0 - NOVITÀ

### ✨ Prompt AI Specifico per "Il Punto di Vista"
- ✅ Ottimizzato per temi del canale (esoterismo, spiritualità, misteri, geopolitica, UFO, disclosure)
- ✅ Comprende lo stile e il tono del canale
- ✅ Genera contenuti mirati per l'audience specifica
- ✅ Descrizioni strutturate e SEO-friendly
- ✅ Hashtag sempre include #IlPuntoDiVista + tags pertinenti

### 🔧 Miglioramenti Tecnici
- ✅ Max tokens aumentato a 3000 (descrizioni più dettagliate)
- ✅ Temperature 0.7 (creatività bilanciata)
- ✅ Timeout 90 secondi (trascrizioni lunghe)
- ✅ Limita trascrizione a 15000 caratteri (controllo costi)
- ✅ System prompt migliorato per JSON più affidabile

---

## 📦 CARATTERISTICHE COMPLETE

### 🎥 Import & Gestione Video
- ✅ **Import automatico da YouTube** (singolo, bulk, canale completo)
- ✅ **Bulk Import** da lista ID, URL o channel
- ✅ **Filtri avanzati** (tutti, shorts, live, orizzontali)
- ✅ **Thumbnail automatiche** con rigenerazione bulk
- ✅ **Metadata completi** (durata, views, data pubblicazione)

### 📝 Trascrizioni & AI
- ✅ **SupaData Integration** per trascrizioni automatiche
- ✅ **OpenAI GPT-4o/Mini** per generazione contenuti
- ✅ **16 campi dedicati** compilati automaticamente:
  - Titolo ottimizzato SEO
  - Descrizione strutturata (max 1200 caratteri)
  - Minutaggio dettagliato con timestamp
  - Argomenti e temi
  - Ospiti e persone menzionate
  - Eventi e conferenze
  - Sponsor e link utili
  - Link social (Telegram, Facebook, Instagram)
  - Hashtag ottimizzati
  - Contatti e donazioni

### 📊 Dashboard & Analytics
- ✅ **Dashboard professionale** con metriche in tempo reale
- ✅ **Analytics video** (views, engagement, performance)
- ✅ **Logger avanzato** con tracking operazioni
- ✅ **Cache intelligente** per ottimizzazione performance
- ✅ **Admin columns** personalizzate
- ✅ **Stato configurazione** chiaro e visivo

### 🎨 Frontend
- ✅ **Video Wall** moderno e responsive
- ✅ **Griglia adattiva** (3/2/1 colonne)
- ✅ **Lazy loading** con "Carica più video"
- ✅ **Badge tipo video** (Short/Live)
- ✅ **Overlay YouTube** con play button
- ✅ **Dark mode** support
- ✅ **Link configurabili** (YouTube o CPT)

### 🛠️ Tools & Bulk Operations
- ✅ **Rigenerazione bulk** thumbnail
- ✅ **Rigenerazione bulk** trascrizioni
- ✅ **Bulk AI generation** per tutti i video
- ✅ **Export** contenuti in formato testo
- ✅ **Filtri intelligenti** (tutti/solo mancanti)
- ✅ **Log operazioni** in tempo reale

---

## 📥 INSTALLAZIONE

### Requisiti
- WordPress 5.8+
- PHP 7.4+
- OpenAI API Key (per generazione AI)
- YouTube Data API Key (per import YouTube)
- SupaData API Key (opzionale, per trascrizioni)

### Procedura
1. **Backup** del sito WordPress
2. **Disattiva** eventuali plugin IPV Video precedenti
3. **Elimina** vecchie versioni
4. **Carica** ipv-video-suite-pro-v14.2.0.zip
5. **Attiva** il plugin
6. **Configura** le API keys

---

## ⚙️ CONFIGURAZIONE

### 1️⃣ YouTube API
1. Vai su [Google Cloud Console](https://console.cloud.google.com)
2. Crea progetto o usa uno esistente
3. Abilita **YouTube Data API v3**
4. Crea credenziali → API Key
5. In WordPress: **Video → Impostazioni**
6. Incolla la API Key nel campo "YouTube API Key"
7. Salva

### 2️⃣ OpenAI API
1. Vai su [OpenAI Platform](https://platform.openai.com/api-keys)
2. Crea nuova API Key
3. In WordPress: **Video → Impostazioni**
4. Incolla la API Key nel campo "OpenAI API Key"
5. Seleziona modello (consigliato: **GPT-4o Mini**)
6. Salva

**Costi OpenAI:**
- GPT-4o Mini: ~€0.002 per video (~€0.07 per 36 video)
- GPT-4o: ~€0.01 per video (~€0.36 per 36 video)

### 3️⃣ SupaData (Opzionale)
1. Vai su [SupaData.ai](https://supadata.ai)
2. Registrati e ottieni API Key
3. In WordPress: **Video → Impostazioni**
4. Incolla la API Key nel campo "SupaData API Key"
5. Salva

---

## 🎬 UTILIZZO

### Import Singolo Video
1. **Video → Aggiungi Nuovo**
2. Incolla YouTube URL o ID
3. Clicca "Importa"
4. ✅ Video importato con metadata

### Import Bulk
1. **Video → Bulk Import**
2. Scegli metodo:
   - **Lista IDs**: Un ID per riga
   - **Lista URLs**: Un URL per riga
   - **Canale**: ID o handle canale
3. Seleziona opzioni:
   - ☑️ Auto-fetch trascrizioni
   - ☑️ Solo video orizzontali
   - ☑️ Filtro tipo (tutti/shorts/live)
4. Clicca **"Importa"**
5. Attendi completamento
6. ✅ Video importati!

### Generazione AI
#### Singolo Video
1. Apri video esistente
2. Scorri a "📝 Campi Video"
3. Verifica che ci sia la trascrizione
4. Clicca **"Genera con AI"**
5. Attendi 10-15 secondi
6. ✅ Campi popolati!

#### Bulk AI (Tutti i Video)
1. **Video → Bulk Tools**
2. Sezione "Rigenera Trascrizioni"
3. Se necessario, scarica trascrizioni mancanti
4. **Video → Dashboard** (o singoli video)
5. Per ogni video con trascrizione ma senza campi AI:
   - Apri video
   - Clicca "Genera con AI"

**Tip per 36 Video:**
- Usa Import Bulk con "Auto-fetch trascrizioni" ✅
- Poi bulk-genera AI aprendo ogni video (o usa script custom)
- Tempo totale: ~1-2 ore per 36 video

### Rigenerazione Bulk
#### Thumbnail
1. **Video → Bulk Tools**
2. Sezione "Rigenera Thumbnail"
3. Seleziona filtro (tutti/solo mancanti)
4. Clicca **"Rigenera Thumbnail"**
5. Attendi completamento
6. ✅ Thumbnail aggiornate!

#### Trascrizioni
1. **Video → Bulk Tools**
2. Sezione "Rigenera Trascrizioni"
3. Seleziona filtro (tutti/solo mancanti)
4. Clicca **"Rigenera Trascrizioni"**
5. Attendi completamento
6. ✅ Trascrizioni scaricate!

---

## 📊 STRUTTURA CAMPI

Il plugin genera automaticamente **16 campi** per ogni video:

| Campo | Descrizione | Esempio |
|-------|-------------|---------|
| **title_opt** | Titolo ottimizzato SEO | "Il Mistero degli UFO: Disclosure 2025" |
| **descrizione** | Descrizione completa strutturata | Intro + Contenuto + Sponsor + CTA |
| **sponsor** | Nome sponsor + link | "Biovital – Progetto Italia" |
| **minutaggio** | Timestamp con sezioni | "00:00 – Intro\n05:30 – Argomento 1" |
| **argomenti** | Lista argomenti | "UFO\nDisclosure\nGeopolitica" |
| **ospiti** | Nome ospiti | "Dr. Mario Rossi\nProf.ssa Laura Bianchi" |
| **persone** | Persone menzionate | "Nikola Tesla\nAlbert Einstein" |
| **regia** | Produzione | "Il Punto di Vista" |
| **eventi** | Eventi citati | "Conferenza Disclosure – Milano – 15/02/25" |
| **link_utili** | Link risorse | "Documento PDF – https://..." |
| **donazioni** | Link donazioni | "https://paypal.me/adrianfiorelli" |
| **abbonati** | Handle YouTube | "/ @ilpuntodivista" |
| **temi** | Categorie tematiche | "Esoterismo\nSpiritualità\nMisteri" |
| **hashtag** | Hashtag ottimizzati | "#IlPuntoDiVista #UFO #Disclosure" |
| **social** | Link social (TG/FB/IG) | Object con URL |
| **contatti** | Email redazione | "ilpuntodivistaredazione@gmail.com" |

---

## 🎯 CASI D'USO

### Caso 1: Canale Nuovo (0 Video)
1. Configura API keys
2. Import bulk da canale YouTube
3. Attiva "Auto-fetch trascrizioni"
4. Attendi import completo
5. Genera AI per tutti i video
6. ✅ Canale pronto!

**Tempo:** 2-3 ore per 50 video  
**Costo:** ~€0.10 (GPT-4o Mini)

### Caso 2: Canale Esistente (36 Video come il tuo)
1. Configura API keys
2. Se video già importati:
   - Vai in Bulk Tools
   - Rigenera trascrizioni mancanti
3. Apri ogni video
4. Clicca "Genera con AI"
5. ✅ Video ottimizzati!

**Tempo:** ~1-2 ore manuale  
**Costo:** ~€0.07 (GPT-4o Mini)

### Caso 3: Manutenzione Continua
1. Nuovo video su YouTube
2. Import in WordPress
3. Trascrizione auto-fetch ✅
4. AI generation automatica ✅
5. Pubblica con contenuti ottimizzati
6. ✅ 100% automatico!

**Tempo:** 2 minuti per video  
**Costo:** ~€0.002 per video

---

## 🐛 TROUBLESHOOTING

### OpenAI non genera
**Sintomi:** Campi restano vuoti  
**Cause:**
- API Key non configurata
- API Key invalida
- Credito esaurito
- Trascrizione mancante

**Soluzioni:**
1. Verifica API Key in Impostazioni
2. Controlla credito su [OpenAI Usage](https://platform.openai.com/usage)
3. Verifica che video abbia trascrizione
4. Controlla `wp-content/debug.log` per errori
5. Riprova dopo qualche minuto

### YouTube Import fallisce
**Sintomi:** "Errore durante import"  
**Cause:**
- API Key YouTube non configurata
- Quota API esaurita
- Video privato/non disponibile
- ID/URL errato

**Soluzioni:**
1. Verifica API Key YouTube in Impostazioni
2. Controlla quota su [Google Cloud Console](https://console.cloud.google.com)
3. Verifica che video sia pubblico
4. Controlla formato ID/URL
5. Attendi reset quota (giornaliero)

### SupaData 401/403
**Sintomi:** "Authentication failed"  
**Cause:**
- API Key non configurata
- API Key invalida
- Header errato

**Soluzioni:**
1. Verifica API Key SupaData in Impostazioni
2. Controlla che sia nel formato corretto
3. Plugin usa header `x-api-key` (corretto)
4. Contatta supporto SupaData se persiste

### Trascrizioni mancanti
**Sintomi:** Campo "Transcript" vuoto  
**Cause:**
- SupaData non configurato
- Video senza sottotitoli
- Lingua non supportata

**Soluzioni:**
1. Configura SupaData API Key
2. Verifica che video YouTube abbia sottotitoli
3. Usa Bulk Tools → Rigenera Trascrizioni
4. Come alternativa, incolla manualmente da YouTube

### Performance lente
**Sintomi:** Dashboard lenta, import lenti  
**Cause:**
- Cache disabilitata
- Molti video
- Server lento

**Soluzioni:**
1. Cache è integrata e attiva
2. Aumenta PHP memory_limit (256MB+)
3. Aumenta max_execution_time (300s+)
4. Considera hosting migliore per molti video

---

## 📁 STRUTTURA FILES

```
ipv-video-suite-pro/
├── ipv-video-suite-pro.php          # File principale
├── includes/
│   ├── class-ajax.php               # Gestione AJAX
│   ├── class-analytics.php          # Analytics video
│   ├── class-bulk-importer.php      # Import bulk
│   ├── class-bulk.php               # Bulk operations
│   ├── class-cache.php              # Sistema cache
│   ├── class-cpt.php                # Custom Post Type
│   ├── class-dashboard.php          # Dashboard admin
│   ├── class-fields.php             # Campi video + OpenAI ⭐
│   ├── class-logger.php             # Sistema logging
│   ├── class-settings.php           # Impostazioni ⭐
│   ├── class-supadata.php           # SupaData API
│   ├── class-tools.php              # Tools bulk
│   ├── class-youtube.php            # YouTube API
│   ├── class-wall.php               # Video wall
│   ├── class-frontend-wall.php      # Frontend wall
│   ├── class-admin-columns.php      # Colonne admin
│   └── admin-menu-fix.php           # Fix menu admin
├── admin/                            # UI admin
├── assets/                           # CSS/JS/Images
├── blocks/                           # Gutenberg blocks
└── languages/                        # Traduzioni

45 file PHP | ~850KB | Enterprise-Grade
```

---

## 🔄 CHANGELOG

### v14.2.0 (2025-10-19)
✨ **Prompt AI Specifico per "Il Punto di Vista"**
- Ottimizzato per temi del canale (esoterismo, spiritualità, misteri, geopolitica, UFO)
- Comprende stile e tono del canale
- Descrizioni strutturate (intro + contenuto + sponsor + CTA)
- Hashtag sempre include #IlPuntoDiVista
- System prompt migliorato

🔧 **Miglioramenti Tecnici**
- Max tokens: 3000 (vs 2000)
- Temperature: 0.7 (vs 0.3)
- Timeout: 90s (vs 60s)
- Limita trascrizione a 15000 caratteri
- JSON parsing più robusto

### v13.2.3 (Base)
✅ Tutte le feature commerciali
✅ OpenAI settings funzionanti
✅ Bulk AI generation nel bulk importer
✅ SupaData authentication fixed
✅ Logger e cache avanzati

---

## 💰 COSTI OPERATIVI

### OpenAI (Generazione AI)
| Modello | Costo/Video | 36 Video | 100 Video |
|---------|-------------|----------|-----------|
| GPT-4o Mini | €0.002 | €0.07 | €0.20 |
| GPT-4o | €0.01 | €0.36 | €1.00 |

**Consigliato:** GPT-4o Mini (qualità ottima, costo minimale)

### YouTube API
- **Gratuito** fino a 10,000 quote/giorno
- Import video: ~3 quote/video
- Capacità: ~3,000 video/giorno
- Reset: ogni giorno alle 00:00 PT

### SupaData
- Variabile secondo piano sottoscritto
- Check pricing su supadata.ai

---

## 🚀 ROADMAP FUTURA

### Pianificato v15.0
- [ ] Generazione AI completamente automatica in bulk (1-click per tutti i video)
- [ ] Templates personalizzabili per prompt AI
- [ ] Integrazione Elementor PRO con widget avanzati
- [ ] Shortcode generator visuale
- [ ] Export/Import configurazioni
- [ ] Multi-lingua support
- [ ] REST API endpoints

### In Considerazione
- [ ] WordPress Multisite support
- [ ] Integration con altri servizi trascrizione
- [ ] Custom AI models support
- [ ] Scheduled imports automatici
- [ ] Email notifications

---

## 📞 SUPPORTO

### Documentazione
- README.md (questo file)
- CHANGELOG.md (storico versioni)
- INSTALL.md (guida installazione)
- File inline documentation (PHPDoc)

### Debug
- Attiva WP_DEBUG in wp-config.php
- Controlla wp-content/debug.log
- Logger integrato nel plugin
- Dashboard mostra errori in tempo reale

### Contatti
- **Email:** ilpuntodivistaredazione@gmail.com
- **Telegram:** https://t.me/il_punto_divista
- **Instagram:** https://instagram.com/_ilpuntodivista._

---

## 📄 LICENZA

GPL v2 or later

---

## 🙏 CREDITS

**Sviluppato per:** Il Punto di Vista  
**Canale YouTube:** @ilpuntodivista  
**Powered by:** OpenAI GPT-4o, YouTube Data API v3, SupaData  
**Version:** 14.2.0 Commercial Edition  

---

**🎬 Plugin Enterprise per Gestione Video Professionale**  
*Automatizza, Ottimizza, Scala*
