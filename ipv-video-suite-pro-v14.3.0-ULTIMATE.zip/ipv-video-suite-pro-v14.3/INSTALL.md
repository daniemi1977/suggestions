# Quick Installation Guide

## 📦 Installation

### Method 1: WordPress Admin (Recommended)

1. **Download** the plugin ZIP file
2. Go to **Plugins > Add New** in WordPress admin
3. Click **Upload Plugin**
4. Choose the ZIP file and click **Install Now**
5. Click **Activate Plugin**

### Method 2: FTP Upload

1. **Extract** the ZIP file
2. **Upload** the `ipv-video-suite-pro` folder to `/wp-content/plugins/`
3. Go to **Plugins** in WordPress admin
4. **Activate** IPV Video Suite Pro - Enhanced

---

## ⚙️ Quick Configuration

### Step 1: YouTube API Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project or select existing one
3. Enable **YouTube Data API v3**
4. Create credentials > API key
5. Copy the API key

### Step 2: SupaData API Setup

1. Go to [SupaData Dashboard](https://dash.supadata.ai)
2. Sign up or log in
3. Navigate to **Organizations > API Key**
4. Create a new API key
5. Copy the API key (starts with `sk_`)

### Step 3: Configure Plugin

1. In WordPress, go to **Video > Settings**
2. **YouTube Configuration:**
   - Paste your YouTube API Key
   - Enter your channel handle (e.g., `@ilpuntodivista`)
   - Enable "Only horizontal videos" if you want to skip Shorts
3. **SupaData Configuration:**
   - Paste your SupaData API Key
   - Leave Base URL as default (`https://api.supadata.ai/v1`)
   - Select Mode: **auto** (recommended)
   - Choose preferred language (optional)
   - Set timeout to **60** seconds (recommended)
   - Enable "Auto-fetch on Import" if you want automatic transcripts
4. **Import Settings:**
   - Enable "Auto Import" for scheduled imports
   - Choose import interval (Hourly, Daily, etc.)
   - Set max videos per import (20 recommended)
5. Click **Save Settings**

### Step 4: Test Connection

1. Scroll down on the settings page
2. Click **Test Connection SupaData**
3. Verify you see "Connection successful!"

---

## 🚀 First Import

### Manual Import

1. Go to **Video > Dashboard** (or use admin bar menu)
2. Click **Import Now**
3. Wait for the import to complete
4. Check the results and logs

### Check Results

1. Go to **Video > All Videos**
2. You should see your imported videos
3. Edit a video to see its metadata
4. If auto-fetch was enabled, transcripts are in post meta

---

## 📝 Using Transcripts

### View Transcript

```php
<?php
$transcript = ipv_get_transcript($post_id);
if ($transcript) {
    echo $transcript['content']; // Full transcript text
    echo $transcript['lang'];     // Language (e.g., 'en')
}
?>
```

### Fetch Transcript Manually

```php
<?php
// For a specific video
$result = ipv_fetch_transcript('VIDEO_ID', $post_id, [
    'mode' => 'auto',
    'lang' => 'it',
    'save_to_post' => true
]);
?>
```

---

## 🔧 Troubleshooting

### Videos Not Importing

✅ Check YouTube API key is correct  
✅ Verify channel handle starts with `@`  
✅ Check WordPress cron is working  
✅ Look at logs in Dashboard  

### Transcripts Not Fetching

✅ Check SupaData API key is correct  
✅ Verify you have credits available  
✅ Test connection on settings page  
✅ Check logs for error details  
✅ Try mode `native` first to see if video has transcripts  

### Cron Not Working

✅ Check `DISABLE_WP_CRON` is not set in wp-config.php  
✅ Verify "Auto Import" is enabled in settings  
✅ Test manual import first  
✅ Check WordPress cron events in dashboard  

---

## 📚 Next Steps

1. Read the full [README.md](README.md) for detailed documentation
2. Check [CHANGELOG.md](CHANGELOG.md) for version history
3. Explore the Dashboard for statistics and controls
4. Configure display settings for your wall

---

## 💡 Pro Tips

- **Use mode `auto`** for best balance of quality and cost
- **Cache transcripts** by enabling post meta storage
- **Monitor your SupaData credits** regularly
- **Test with native mode first** for popular videos
- **Set appropriate timeout** (60s for most videos)
- **Enable auto-fetch gradually** to control costs
- **Check logs regularly** for any issues

---

## 🆘 Need Help?

1. Check the logs in **Video > Dashboard**
2. Review settings in **Video > Settings**
3. Test connections using test buttons
4. Read troubleshooting section in README
5. Check [SupaData Documentation](https://docs.supadata.ai)

---

**Enjoy your enhanced video suite!** 🎬✨
