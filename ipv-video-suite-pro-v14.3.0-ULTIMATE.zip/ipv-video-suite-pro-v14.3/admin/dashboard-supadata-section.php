<!-- SupaData Testing Section for Admin Dashboard -->
<div class="tab-pane fade" id="supadata-test" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="bi bi-broadcast"></i> SupaData API - Test & Configurazione
                    </h5>
                </div>
                <div class="card-body">
                    <!-- API Status -->
                    <div class="alert alert-info mb-4">
                        <div class="d-flex align-items-center">
                            <div class="spinner-border spinner-border-sm me-2" role="status" id="supadata-status-spinner" style="display: none;">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <strong id="supadata-status-text">Stato: Non testato</strong>
                        </div>
                        <div id="supadata-status-details" class="mt-2" style="display: none;"></div>
                    </div>

                    <!-- Test Connection Button -->
                    <div class="mb-4">
                        <button type="button" class="btn btn-primary" id="test-supadata-connection">
                            <i class="bi bi-wifi"></i> Test Connessione API
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="refresh-supadata-config">
                            <i class="bi bi-arrow-clockwise"></i> Ricarica Configurazione
                        </button>
                    </div>

                    <hr>

                    <!-- Current Configuration -->
                    <div class="mb-4">
                        <h6 class="fw-bold">Configurazione Attuale</h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-borderless">
                                <tbody>
                                    <tr>
                                        <td class="text-muted" style="width: 150px;">Base URL:</td>
                                        <td><code id="config-base-url">-</code></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">API Key:</td>
                                        <td><code id="config-api-key">-</code></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Mode:</td>
                                        <td><span class="badge bg-secondary" id="config-mode">-</span></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Language:</td>
                                        <td><span class="badge bg-info" id="config-lang">-</span></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Timeout:</td>
                                        <td><span id="config-timeout">-</span> secondi</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <hr>

                    <!-- URL Validation Test -->
                    <div class="mb-4">
                        <h6 class="fw-bold">Test Validazione URL</h6>
                        <p class="text-muted small">Verifica se un URL è supportato da SupaData</p>
                        
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" id="test-url-input" 
                                   placeholder="https://www.youtube.com/watch?v=dQw4w9WgXcQ">
                            <button class="btn btn-outline-primary" type="button" id="validate-url-btn">
                                <i class="bi bi-check-circle"></i> Valida URL
                            </button>
                        </div>

                        <div id="url-validation-result" style="display: none;"></div>
                    </div>

                    <hr>

                    <!-- Transcript Fetch Test -->
                    <div class="mb-4">
                        <h6 class="fw-bold">Test Fetch Transcript</h6>
                        <p class="text-muted small">Scarica transcript da un video</p>
                        
                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label small">Video ID/URL</label>
                                <input type="text" class="form-control" id="transcript-video-id" 
                                       placeholder="jNQXAC9IVRw">
                                <small class="text-muted">ID YouTube o URL completo</small>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small">Mode</label>
                                <select class="form-select" id="transcript-mode">
                                    <option value="auto">Auto (Default)</option>
                                    <option value="native">Native Only</option>
                                    <option value="generate">Generate (AI)</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small">Language</label>
                                <select class="form-select" id="transcript-lang">
                                    <option value="">Auto-detect</option>
                                    <option value="en">English</option>
                                    <option value="it">Italiano</option>
                                    <option value="es">Español</option>
                                    <option value="fr">Français</option>
                                    <option value="de">Deutsch</option>
                                </select>
                            </div>
                        </div>

                        <button type="button" class="btn btn-success" id="fetch-transcript-btn">
                            <i class="bi bi-download"></i> Fetch Transcript
                        </button>

                        <div id="transcript-result" class="mt-3" style="display: none;"></div>
                    </div>

                    <hr>

                    <!-- Credit Estimation -->
                    <div class="mb-4">
                        <h6 class="fw-bold">Stima Crediti</h6>
                        <p class="text-muted small">Calcola i crediti necessari per una richiesta</p>
                        
                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label small">Mode</label>
                                <select class="form-select" id="credit-mode">
                                    <option value="native">Native (1 credit)</option>
                                    <option value="generate">Generate (2 credits/min)</option>
                                    <option value="auto">Auto (varies)</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small">Durata Video (minuti)</label>
                                <input type="number" class="form-control" id="credit-duration" 
                                       placeholder="10" min="1" value="10">
                            </div>
                        </div>

                        <button type="button" class="btn btn-outline-primary" id="estimate-credits-btn">
                            <i class="bi bi-calculator"></i> Calcola Crediti
                        </button>

                        <div id="credit-result" class="mt-3" style="display: none;"></div>
                    </div>

                    <hr>

                    <!-- Supported Platforms -->
                    <div class="mb-4">
                        <h6 class="fw-bold">Piattaforme Supportate</h6>
                        <div class="row g-2">
                            <div class="col-md-4">
                                <div class="d-flex align-items-center p-2 border rounded">
                                    <i class="bi bi-youtube text-danger fs-4 me-2"></i>
                                    <div>
                                        <strong>YouTube</strong>
                                        <br><small class="text-muted">Video & Shorts</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center p-2 border rounded">
                                    <i class="bi bi-tiktok text-dark fs-4 me-2"></i>
                                    <div>
                                        <strong>TikTok</strong>
                                        <br><small class="text-muted">Video clips</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center p-2 border rounded">
                                    <i class="bi bi-instagram text-danger fs-4 me-2"></i>
                                    <div>
                                        <strong>Instagram</strong>
                                        <br><small class="text-muted">Reels & IGTV</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center p-2 border rounded">
                                    <i class="bi bi-twitter-x text-dark fs-4 me-2"></i>
                                    <div>
                                        <strong>X (Twitter)</strong>
                                        <br><small class="text-muted">Video tweets</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center p-2 border rounded">
                                    <i class="bi bi-file-earmark-play text-primary fs-4 me-2"></i>
                                    <div>
                                        <strong>File URL</strong>
                                        <br><small class="text-muted">MP4, MP3, WebM...</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center p-2 border rounded bg-light">
                                    <i class="bi bi-plus-circle text-muted fs-4 me-2"></i>
                                    <div>
                                        <strong>Altri formati</strong>
                                        <br><small class="text-muted">In arrivo...</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pricing Info -->
                    <div class="alert alert-light border">
                        <h6 class="fw-bold mb-2">💰 Pricing SupaData</h6>
                        <ul class="mb-0 small">
                            <li><strong>Native transcript:</strong> 1 credito</li>
                            <li><strong>Generated transcript:</strong> 2 crediti per minuto</li>
                            <li><strong>Mode auto:</strong> 1-2+ crediti (dipende dalla disponibilità)</li>
                        </ul>
                        <a href="https://supadata.ai/pricing" target="_blank" class="btn btn-sm btn-outline-primary mt-2">
                            <i class="bi bi-box-arrow-up-right"></i> Vedi Pricing Completo
                        </a>
                    </div>

                    <!-- Documentation Links -->
                    <div class="alert alert-info border-info">
                        <h6 class="fw-bold mb-2">📚 Documentazione</h6>
                        <div class="d-flex gap-2 flex-wrap">
                            <a href="https://docs.supadata.ai/api-reference/transcript" target="_blank" class="btn btn-sm btn-outline-info">
                                <i class="bi bi-book"></i> API Docs
                            </a>
                            <a href="https://dash.supadata.ai" target="_blank" class="btn btn-sm btn-outline-info">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </a>
                            <a href="<?php echo plugin_dir_url(__FILE__); ?>SUPADATA-DOCS.md" target="_blank" class="btn btn-sm btn-outline-info">
                                <i class="bi bi-file-text"></i> Docs Plugin
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    
    // Load configuration on page load
    loadSupaDataConfig();

    // Test Connection
    $('#test-supadata-connection').click(function() {
        const $btn = $(this);
        const $spinner = $('#supadata-status-spinner');
        const $status = $('#supadata-status-text');
        const $details = $('#supadata-status-details');

        $btn.prop('disabled', true);
        $spinner.show();
        $status.text('Testando connessione...');
        $details.hide();

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'ipv_test_supadata_connection',
                nonce: '<?php echo wp_create_nonce("ipv_nonce"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    const result = response.data;
                    
                    if (result.success) {
                        $status.html('<i class="bi bi-check-circle-fill text-success"></i> Connessione riuscita!');
                        $details.html(`
                            <strong>Status:</strong> ${result.message}<br>
                            <strong>HTTP Code:</strong> ${result.code}
                        `).removeClass('alert-danger').addClass('alert-success').show();
                    } else {
                        $status.html('<i class="bi bi-x-circle-fill text-danger"></i> Connessione fallita');
                        $details.html(`
                            <strong>Errore:</strong> ${result.message}<br>
                            <strong>HTTP Code:</strong> ${result.code}
                        `).removeClass('alert-success').addClass('alert-danger').show();
                    }
                } else {
                    $status.html('<i class="bi bi-x-circle-fill text-danger"></i> Errore');
                    $details.html('<strong>Errore:</strong> ' + response.data).addClass('alert-danger').show();
                }
            },
            error: function() {
                $status.html('<i class="bi bi-x-circle-fill text-danger"></i> Errore di rete');
                $details.html('Impossibile contattare il server').addClass('alert-danger').show();
            },
            complete: function() {
                $btn.prop('disabled', false);
                $spinner.hide();
            }
        });
    });

    // Refresh Configuration
    $('#refresh-supadata-config').click(function() {
        loadSupaDataConfig();
    });

    // Validate URL
    $('#validate-url-btn').click(function() {
        const url = $('#test-url-input').val().trim();
        const $result = $('#url-validation-result');

        if (!url) {
            $result.html('<div class="alert alert-warning">Inserisci un URL</div>').show();
            return;
        }

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'ipv_validate_supadata_url',
                nonce: '<?php echo wp_create_nonce("ipv_nonce"); ?>',
                url: url
            },
            success: function(response) {
                if (response.success) {
                    const result = response.data;
                    const alertClass = result.valid ? 'alert-success' : 'alert-danger';
                    const icon = result.valid ? 'check-circle' : 'x-circle';
                    
                    $result.html(`
                        <div class="alert ${alertClass}">
                            <i class="bi bi-${icon}-fill"></i> <strong>${result.message}</strong><br>
                            <small>Piattaforma: <code>${result.platform}</code></small>
                        </div>
                    `).show();
                }
            }
        });
    });

    // Fetch Transcript
    $('#fetch-transcript-btn').click(function() {
        const $btn = $(this);
        const videoId = $('#transcript-video-id').val().trim();
        const mode = $('#transcript-mode').val();
        const lang = $('#transcript-lang').val();
        const $result = $('#transcript-result');

        if (!videoId) {
            $result.html('<div class="alert alert-warning">Inserisci un Video ID o URL</div>').show();
            return;
        }

        $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Fetching...');
        $result.html('<div class="alert alert-info">⏳ Downloading transcript... Questo può richiedere alcuni secondi.</div>').show();

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'ipv_fetch_supadata_transcript',
                nonce: '<?php echo wp_create_nonce("ipv_nonce"); ?>',
                video_id: videoId,
                mode: mode,
                lang: lang
            },
            timeout: 90000, // 90 secondi
            success: function(response) {
                if (response.success) {
                    const result = response.data;
                    
                    $result.html(`
                        <div class="alert alert-success">
                            <h6><i class="bi bi-check-circle-fill"></i> Transcript Scaricato!</h6>
                            <hr>
                            <p><strong>Lingua:</strong> <span class="badge bg-info">${result.lang}</span></p>
                            <p><strong>Lingue disponibili:</strong> ${result.availableLangs.join(', ')}</p>
                            <p><strong>Lunghezza:</strong> ${result.content.length} caratteri</p>
                            <hr>
                            <p><strong>Preview:</strong></p>
                            <div class="p-3 bg-light rounded" style="max-height: 300px; overflow-y: auto;">
                                <pre class="mb-0">${result.content.substring(0, 1000)}${result.content.length > 1000 ? '...' : ''}</pre>
                            </div>
                        </div>
                    `).show();
                } else {
                    $result.html(`
                        <div class="alert alert-danger">
                            <i class="bi bi-x-circle-fill"></i> <strong>Errore:</strong> ${response.data}
                        </div>
                    `).show();
                }
            },
            error: function(xhr, status) {
                let errorMsg = 'Errore di rete';
                if (status === 'timeout') {
                    errorMsg = 'Timeout: il video potrebbe essere troppo lungo o il server non risponde';
                }
                $result.html(`<div class="alert alert-danger"><i class="bi bi-x-circle-fill"></i> ${errorMsg}</div>`).show();
            },
            complete: function() {
                $btn.prop('disabled', false).html('<i class="bi bi-download"></i> Fetch Transcript');
            }
        });
    });

    // Estimate Credits
    $('#estimate-credits-btn').click(function() {
        const mode = $('#credit-mode').val();
        const duration = parseInt($('#credit-duration').val()) || 10;
        const $result = $('#credit-result');

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'ipv_estimate_supadata_credits',
                nonce: '<?php echo wp_create_nonce("ipv_nonce"); ?>',
                mode: mode,
                duration: duration
            },
            success: function(response) {
                if (response.success) {
                    const credits = response.data.credits;
                    const explanation = response.data.explanation;
                    
                    $result.html(`
                        <div class="alert alert-info">
                            <h6><i class="bi bi-calculator"></i> Stima Crediti</h6>
                            <hr>
                            <p class="mb-0">
                                <strong>Crediti stimati:</strong> 
                                <span class="badge bg-primary fs-5">${credits}</span>
                                <br>
                                <small class="text-muted">${explanation}</small>
                            </p>
                        </div>
                    `).show();
                }
            }
        });
    });

    // Load SupaData Configuration
    function loadSupaDataConfig() {
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'ipv_get_supadata_config',
                nonce: '<?php echo wp_create_nonce("ipv_nonce"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    const config = response.data;
                    
                    $('#config-base-url').text(config.base_url || 'Non configurato');
                    $('#config-api-key').text(config.api_key ? '••••' + config.api_key.slice(-8) : 'Non configurata');
                    $('#config-mode').text(config.mode || 'auto');
                    $('#config-lang').text(config.lang || 'auto');
                    $('#config-timeout').text(config.timeout || '30');
                }
            }
        });
    }
});
</script>

<style>
#supadata-test .table-borderless td {
    padding: 0.25rem 0.5rem;
}
#supadata-test pre {
    font-size: 0.85rem;
    line-height: 1.4;
    white-space: pre-wrap;
    word-wrap: break-word;
}
</style>
