<?php
/**
 * Admin Page: Bulk Import
 * Interfaccia per importazione massiva video
 */

if (!defined('ABSPATH')) exit;

$settings = IPV_Settings::get();
$has_youtube_api = !empty($settings['youtube_api_key']);
$has_supadata_api = !empty($settings['supadata_key']);
?>

<div class="wrap ipv-bulk-import-page">
    <h1><?php _e('📥 Importazione Massiva Video', 'ipv'); ?></h1>
    
    <?php if (!$has_youtube_api): ?>
        <div class="notice notice-error">
            <p>
                <strong><?php _e('YouTube API Key mancante!', 'ipv'); ?></strong>
                <?php _e('Configura la tua YouTube Data API v3 Key nelle', 'ipv'); ?>
                <a href="<?php echo admin_url('edit.php?post_type=ipv_video&page=ipv-settings'); ?>">
                    <?php _e('impostazioni', 'ipv'); ?>
                </a>
            </p>
        </div>
    <?php endif; ?>
    
    <div class="ipv-bulk-tabs">
        <button class="ipv-tab-btn active" data-tab="channel">
            <span class="dashicons dashicons-video-alt3"></span>
            <?php _e('Da Canale', 'ipv'); ?>
        </button>
        <button class="ipv-tab-btn" data-tab="ids">
            <span class="dashicons dashicons-admin-links"></span>
            <?php _e('Da Video IDs', 'ipv'); ?>
        </button>
        <button class="ipv-tab-btn" data-tab="urls">
            <span class="dashicons dashicons-admin-page"></span>
            <?php _e('Da URLs', 'ipv'); ?>
        </button>
        <button class="ipv-tab-btn" data-tab="help">
            <span class="dashicons dashicons-info"></span>
            <?php _e('Aiuto', 'ipv'); ?>
        </button>
    </div>
    
    <!-- TAB 1: Importa da Canale -->
    <div class="ipv-tab-content active" data-tab="channel">
        <div class="ipv-card">
            <h2><?php _e('Importa da Canale YouTube', 'ipv'); ?></h2>
            <p><?php _e('Importa tutti i video da un canale YouTube usando Channel ID o Handle (@nomeutente)', 'ipv'); ?></p>
            
            <form id="ipv-bulk-import-channel-form" class="ipv-bulk-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="channel_input"><?php _e('Channel ID / Handle', 'ipv'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="text" 
                                id="channel_input" 
                                name="channel" 
                                class="regular-text" 
                                placeholder="@nomeutente o UC..." 
                                <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                            >
                            <p class="description">
                                <?php _e('Esempi: @ilpuntodivista, UCxxx...', 'ipv'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="max_results"><?php _e('Max Video', 'ipv'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="number" 
                                id="max_results" 
                                name="max_results" 
                                value="50" 
                                min="1" 
                                max="500" 
                                class="small-text"
                                <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                            >
                            <p class="description">
                                <?php _e('Numero massimo di video da importare (1-500)', 'ipv'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="filter_type"><?php _e('Filtra per Tipo', 'ipv'); ?></label>
                        </th>
                        <td>
                            <select 
                                id="filter_type" 
                                name="filter_type"
                                <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                            >
                                <option value="all"><?php _e('Tutti i video', 'ipv'); ?></option>
                                <option value="normal"><?php _e('Solo video normali', 'ipv'); ?></option>
                                <option value="short"><?php _e('Solo Shorts', 'ipv'); ?></option>
                                <option value="live"><?php _e('Solo Live', 'ipv'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <?php _e('Opzioni', 'ipv'); ?>
                        </th>
                        <td>
                            <label>
                                <input 
                                    type="checkbox" 
                                    id="auto_transcripts_channel" 
                                    name="auto_transcripts" 
                                    value="1"
                                    <?php echo !$has_supadata_api ? 'disabled' : ''; ?>
                                >
                                <?php _e('Auto-fetch trascrizioni SupaData', 'ipv'); ?>
                                <?php if (!$has_supadata_api): ?>
                                    <span class="description" style="color: #dc3232;">
                                        (<?php _e('SupaData API non configurata', 'ipv'); ?>)
                                    </span>
                                <?php endif; ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button 
                        type="submit" 
                        class="button button-primary button-large"
                        <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                    >
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Avvia Importazione', 'ipv'); ?>
                    </button>
                    
                    <button 
                        type="button" 
                        id="preview_channel_btn" 
                        class="button button-secondary"
                        <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                    >
                        <span class="dashicons dashicons-visibility"></span>
                        <?php _e('Anteprima (primi 10)', 'ipv'); ?>
                    </button>
                </p>
            </form>
            
            <div id="channel_preview" class="ipv-preview" style="display: none;"></div>
        </div>
    </div>
    
    <!-- TAB 2: Importa da IDs -->
    <div class="ipv-tab-content" data-tab="ids">
        <div class="ipv-card">
            <h2><?php _e('Importa da Lista Video IDs', 'ipv'); ?></h2>
            <p><?php _e('Inserisci una lista di video IDs YouTube (uno per riga, separati da virgole o spazi)', 'ipv'); ?></p>
            
            <form id="ipv-bulk-import-ids-form" class="ipv-bulk-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="video_ids"><?php _e('Video IDs', 'ipv'); ?></label>
                        </th>
                        <td>
                            <textarea 
                                id="video_ids" 
                                name="video_ids" 
                                rows="10" 
                                class="large-text code"
                                placeholder="dQw4w9WgXcQ&#10;J7p4bzqLvCw&#10;kJQP7kiw5Fk"
                                <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                            ></textarea>
                            <p class="description">
                                <?php _e('Inserisci video IDs YouTube (11 caratteri). Supporta newline, virgole, spazi.', 'ipv'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <?php _e('Opzioni', 'ipv'); ?>
                        </th>
                        <td>
                            <label>
                                <input 
                                    type="checkbox" 
                                    id="auto_transcripts_ids" 
                                    name="auto_transcripts" 
                                    value="1"
                                    <?php echo !$has_supadata_api ? 'disabled' : ''; ?>
                                >
                                <?php _e('Auto-fetch trascrizioni SupaData', 'ipv'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button 
                        type="submit" 
                        class="button button-primary button-large"
                        <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                    >
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Importa Video IDs', 'ipv'); ?>
                    </button>
                </p>
            </form>
        </div>
    </div>
    
    <!-- TAB 3: Importa da URLs -->
    <div class="ipv-tab-content" data-tab="urls">
        <div class="ipv-card">
            <h2><?php _e('Importa da Lista URLs', 'ipv'); ?></h2>
            <p><?php _e('Inserisci una lista di URLs complete YouTube (una per riga)', 'ipv'); ?></p>
            
            <form id="ipv-bulk-import-urls-form" class="ipv-bulk-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="video_urls"><?php _e('Video URLs', 'ipv'); ?></label>
                        </th>
                        <td>
                            <textarea 
                                id="video_urls" 
                                name="video_urls" 
                                rows="10" 
                                class="large-text code"
                                placeholder="https://www.youtube.com/watch?v=dQw4w9WgXcQ&#10;https://youtu.be/J7p4bzqLvCw"
                                <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                            ></textarea>
                            <p class="description">
                                <?php _e('Supporta youtube.com/watch?v= e youtu.be/', 'ipv'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <?php _e('Opzioni', 'ipv'); ?>
                        </th>
                        <td>
                            <label>
                                <input 
                                    type="checkbox" 
                                    id="auto_transcripts_urls" 
                                    name="auto_transcripts" 
                                    value="1"
                                    <?php echo !$has_supadata_api ? 'disabled' : ''; ?>
                                >
                                <?php _e('Auto-fetch trascrizioni SupaData', 'ipv'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button 
                        type="submit" 
                        class="button button-primary button-large"
                        <?php echo !$has_youtube_api ? 'disabled' : ''; ?>
                    >
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Importa URLs', 'ipv'); ?>
                    </button>
                </p>
            </form>
        </div>
    </div>
    
    <!-- TAB 4: Aiuto -->
    <div class="ipv-tab-content" data-tab="help">
        <div class="ipv-card">
            <h2><?php _e('💡 Guida Bulk Import', 'ipv'); ?></h2>
            
            <h3><?php _e('Metodo 1: Da Canale YouTube', 'ipv'); ?></h3>
            <ol>
                <li><?php _e('Vai sul canale YouTube che vuoi importare', 'ipv'); ?></li>
                <li><?php _e('Copia l\'handle (es: @nomeutente) o il Channel ID (es: UCxxx...)', 'ipv'); ?></li>
                <li><?php _e('Incollalo nel campo "Channel ID / Handle"', 'ipv'); ?></li>
                <li><?php _e('Scegli quanti video importare (max 500)', 'ipv'); ?></li>
                <li><?php _e('Opzionale: filtra per tipo (tutti, normali, shorts, live)', 'ipv'); ?></li>
                <li><?php _e('Click "Avvia Importazione"', 'ipv'); ?></li>
            </ol>
            
            <h3><?php _e('Metodo 2: Da Lista Video IDs', 'ipv'); ?></h3>
            <ol>
                <li><?php _e('Raccogli i video IDs che vuoi importare', 'ipv'); ?></li>
                <li><?php _e('Un video ID YouTube è composto da 11 caratteri (es: dQw4w9WgXcQ)', 'ipv'); ?></li>
                <li><?php _e('Incollali nel campo "Video IDs" (uno per riga, o separati da virgole/spazi)', 'ipv'); ?></li>
                <li><?php _e('Click "Importa Video IDs"', 'ipv'); ?></li>
            </ol>
            
            <h3><?php _e('Metodo 3: Da Lista URLs', 'ipv'); ?></h3>
            <ol>
                <li><?php _e('Raccogli gli URLs completi dei video YouTube', 'ipv'); ?></li>
                <li><?php _e('Supporta formati: youtube.com/watch?v=xxx e youtu.be/xxx', 'ipv'); ?></li>
                <li><?php _e('Incollali nel campo "Video URLs" (uno per riga)', 'ipv'); ?></li>
                <li><?php _e('Click "Importa URLs"', 'ipv'); ?></li>
            </ol>
            
            <h3><?php _e('⚙️ Opzioni Avanzate', 'ipv'); ?></h3>
            <ul>
                <li>
                    <strong><?php _e('Auto-fetch trascrizioni:', 'ipv'); ?></strong>
                    <?php _e('Se abilitato, scarica automaticamente le trascrizioni via SupaData API per ogni video importato', 'ipv'); ?>
                </li>
                <li>
                    <strong><?php _e('Filtra per tipo:', 'ipv'); ?></strong>
                    <?php _e('Puoi importare solo shorts, solo video normali, o tutto', 'ipv'); ?>
                </li>
            </ul>
            
            <h3><?php _e('📋 Script JavaScript per estrazione IDs', 'ipv'); ?></h3>
            <p><?php _e('Vuoi estrarre automaticamente tutti i video IDs da un canale? Usa questo script:', 'ipv'); ?></p>
            <pre class="ipv-code"><code>// 1. Vai su youtube.com/@nomeutente/videos
// 2. Apri Console (F12 → tab Console)
// 3. Incolla questo codice:

(async function() {
  let ids = new Set();
  let lastHeight = 0;
  
  while (true) {
    // Scroll fino in fondo
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 2000));
    
    // Estrai video IDs
    document.querySelectorAll('a[href*="/watch?v="]').forEach(a => {
      let match = a.href.match(/watch\?v=([a-zA-Z0-9_-]{11})/);
      if (match) ids.add(match[1]);
    });
    
    // Stop se non scrollabile
    if (document.body.scrollHeight === lastHeight) break;
    lastHeight = document.body.scrollHeight;
    
    console.log(`Trovati ${ids.size} video...`);
  }
  
  // Copia negli appunti
  let result = Array.from(ids).join('\n');
  navigator.clipboard.writeText(result);
  console.log(`✅ ${ids.size} video IDs copiati negli appunti!`);
})();</code></pre>
            
            <h3><?php _e('❓ FAQ', 'ipv'); ?></h3>
            <dl>
                <dt><strong><?php _e('Quanto tempo ci vuole?', 'ipv'); ?></strong></dt>
                <dd><?php _e('Dipende dal numero di video. Circa 1-2 secondi per video (include download thumbnail).', 'ipv'); ?></dd>
                
                <dt><strong><?php _e('Cosa succede ai video già importati?', 'ipv'); ?></strong></dt>
                <dd><?php _e('Vengono saltati automaticamente. Nessun duplicato.', 'ipv'); ?></dd>
                
                <dt><strong><?php _e('Posso importare da più canali?', 'ipv'); ?></strong></dt>
                <dd><?php _e('Sì! Esegui l\'importazione una volta per canale.', 'ipv'); ?></dd>
                
                <dt><strong><?php _e('Come verifico l\'importazione?', 'ipv'); ?></strong></dt>
                <dd><?php _e('Vai su IPV Video → Tutti i Video per vedere i video importati.', 'ipv'); ?></dd>
            </dl>
        </div>
    </div>
    
    <!-- Progress Modal -->
    <div id="ipv-bulk-progress-modal" class="ipv-modal" style="display: none;">
        <div class="ipv-modal-content">
            <div class="ipv-modal-header">
                <h2><?php _e('Importazione in Corso...', 'ipv'); ?></h2>
            </div>
            <div class="ipv-modal-body">
                <div class="ipv-progress-bar">
                    <div class="ipv-progress-fill" style="width: 0%"></div>
                </div>
                <div class="ipv-progress-info">
                    <p class="ipv-progress-status"><?php _e('Inizializzazione...', 'ipv'); ?></p>
                    <p class="ipv-progress-details"></p>
                </div>
                <div class="ipv-progress-log"></div>
            </div>
        </div>
    </div>
</div>

<style>
.ipv-bulk-import-page {
    max-width: 1200px;
}

.ipv-bulk-tabs {
    display: flex;
    gap: 10px;
    margin: 20px 0;
    border-bottom: 2px solid #ddd;
}

.ipv-tab-btn {
    background: #f0f0f1;
    border: 1px solid #c3c4c7;
    border-bottom: none;
    padding: 10px 20px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s;
}

.ipv-tab-btn:hover {
    background: #e8e8e8;
}

.ipv-tab-btn.active {
    background: #fff;
    border-bottom: 2px solid #fff;
    margin-bottom: -2px;
}

.ipv-tab-btn .dashicons {
    margin-right: 5px;
}

.ipv-tab-content {
    display: none;
    padding: 20px 0;
}

.ipv-tab-content.active {
    display: block;
}

.ipv-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 20px;
}

.ipv-card h2 {
    margin-top: 0;
}

.ipv-bulk-form .form-table th {
    width: 200px;
}

.ipv-code {
    background: #f6f7f7;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 15px;
    overflow-x: auto;
    font-size: 13px;
}

.ipv-preview {
    margin-top: 20px;
    padding: 15px;
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.ipv-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 100000;
    align-items: center;
    justify-content: center;
}

.ipv-modal.active {
    display: flex;
}

.ipv-modal-content {
    background: #fff;
    border-radius: 8px;
    max-width: 600px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
}

.ipv-modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
}

.ipv-modal-header h2 {
    margin: 0;
}

.ipv-modal-body {
    padding: 20px;
}

.ipv-progress-bar {
    height: 30px;
    background: #f0f0f1;
    border-radius: 15px;
    overflow: hidden;
    margin-bottom: 15px;
}

.ipv-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #2271b1, #135e96);
    transition: width 0.3s;
}

.ipv-progress-info {
    margin-bottom: 15px;
}

.ipv-progress-status {
    font-weight: bold;
    margin-bottom: 5px;
}

.ipv-progress-details {
    color: #666;
    font-size: 13px;
}

.ipv-progress-log {
    max-height: 200px;
    overflow-y: auto;
    background: #f6f7f7;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 10px;
    font-size: 12px;
    font-family: monospace;
}

.ipv-log-entry {
    padding: 2px 0;
}

.ipv-log-entry.success {
    color: #00a32a;
}

.ipv-log-entry.error {
    color: #d63638;
}

.ipv-log-entry.info {
    color: #2271b1;
}
</style>
