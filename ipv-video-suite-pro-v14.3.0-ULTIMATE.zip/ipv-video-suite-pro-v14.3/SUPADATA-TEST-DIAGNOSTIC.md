# SupaData Test Failed - Guida Diagnostica

## 🔍 Hai ricevuto "SupaData Test Failed"?

Questa guida ti aiuterà a identificare e risolvere il problema.

---

## ✅ Correzioni Applicate in v12.1.1

### 1. **Endpoint API Corretto**
**PRIMA (Errato):**
```
/transcript?url=...
```

**DOPO (Corretto):**
```
/youtube/transcript?url=...  (per YouTube)
/transcript?url=...          (per altri)
```

### 2. **Migliore Gestione Errori**
- ✅ HTTP 200: Risposta immediata OK
- ✅ HTTP 202: Job asincrono OK
- ✅ HTTP 401: API key invalida
- ✅ HTTP 404: Endpoint non trovato
- ✅ HTTP 429: Rate limit superato
- ✅ Dettagli errore completi

### 3. **Logging Migliorato**
- Debug dettagliato delle richieste
- Body response per troubleshooting
- Platform detection logging

---

## 🐛 Possibili Cause del Test Failed

### 1. **API Key Non Valida** (HTTP 401)
**Sintomi:**
```
✗ Test Failed: API key non valida
Details: Verifica che la tua API key sia corretta
```

**Soluzione:**
1. Vai su https://dash.supadata.ai/organizations/api-key
2. Copia la tua API key
3. Incollala in **Settings → IPV Video Suite → SupaData API Key**
4. Clicca **Save Changes**
5. Riprova il test

---

### 2. **Endpoint Non Trovato** (HTTP 404)
**Sintomi:**
```
✗ Test Failed: Endpoint non trovato (404)
Details: Endpoint non trovato. Potrebbe essere necessario...
```

**Possibili Cause:**
- API endpoint cambiato da SupaData
- URL base errato nelle impostazioni
- Plugin non aggiornato

**Soluzione:**
1. Verifica URL base: dovrebbe essere `https://api.supadata.ai/v1`
2. Aggiorna a v12.1.1 (include fix endpoint)
3. Se persiste, contatta SupaData support

---

### 3. **Rate Limit Raggiunto** (HTTP 429)
**Sintomi:**
```
✗ Test Failed: Rate limit raggiunto
Details: Hai superato il limite di richieste...
```

**Soluzione:**
- Aspetta 5-10 minuti
- Verifica quante richieste hai fatto
- Controlla il tuo piano su SupaData dashboard

---

### 4. **Errore di Connessione** (HTTP 0)
**Sintomi:**
```
✗ Test Failed: Errore di connessione
Details: Impossibile raggiungere SupaData API
```

**Possibili Cause:**
- Server WordPress non può raggiungere internet
- Firewall blocca connessioni
- SSL/TLS issues
- SupaData API temporaneamente down

**Soluzione:**
1. Verifica connessione internet del server
2. Controlla firewall regole (allow https://api.supadata.ai)
3. Verifica stato SupaData su https://status.supadata.ai (se esiste)
4. Controlla WordPress debug log per dettagli

---

### 5. **Altro Errore HTTP**
**Sintomi:**
```
✗ Test Failed: Errore API: [messaggio]
HTTP XXX
```

**Soluzione:**
1. Leggi il messaggio di errore completo
2. Controlla WordPress error log
3. Vai in **Dashboard → SupaData Status** per vedere log dettagliati
4. Copia l'errore e cerca nella documentazione SupaData

---

## 🔧 Come Testare Dopo Le Correzioni

### Test Manuale Completo

#### 1. **Verifica Configurazione**
```
Settings → IPV Video Suite
┌─────────────────────────────────┐
│ SupaData API Key: sk_xxx...     │
│ Base URL: https://api.supadata.ai/v1 │
│ Timeout: 30 seconds              │
│ Mode: auto                       │
└─────────────────────────────────┘
[Save Changes] [Test Connection]
```

#### 2. **Clicca Test Connection**
Dovresti vedere:
```
✓ Connessione riuscita! API key valida.
Details: Transcript ricevuto. Lang: en
HTTP 200
```

#### 3. **Se Test OK, Importa Video**
```
Videos → Add New
┌─────────────────────────────────┐
│ YouTube URL: https://youtube.com/watch?v=... │
└─────────────────────────────────┘
[Fetch Transcript]
```

#### 4. **Verifica Dashboard**
```
Dashboard → SupaData Status
┌─────────────────────────────────┐
│ Last Request: Success            │
│ Response Time: 1.2s              │
│ Platform: youtube.com            │
│ Transcript Length: 1234 chars    │
└─────────────────────────────────┘
```

---

## 📊 Tabella Stati HTTP

| Codice | Significato | Azione Plugin | Esito Test |
|--------|-------------|---------------|------------|
| 200 | OK - Risposta immediata | Transcript salvato | ✓ PASS |
| 202 | Accepted - Job asincrono | Polling attivo | ✓ PASS |
| 401 | Unauthorized | Errore API key | ✗ FAIL |
| 404 | Not Found | Errore endpoint | ✗ FAIL |
| 429 | Rate Limited | Retry dopo wait | ✗ FAIL |
| 500 | Server Error | Errore SupaData | ✗ FAIL |
| 503 | Service Unavailable | SupaData down | ✗ FAIL |

---

## 🔍 Debug Avanzato

### 1. **Abilita WordPress Debug**
Aggiungi a `wp-config.php`:
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

### 2. **Controlla Log File**
```bash
tail -f wp-content/debug.log
```

Cerca linee con:
```
[IPV] SupaData: Test connessione...
[IPV] SupaData: Response code: XXX
[IPV] SupaData test error: ...
```

### 3. **Test API Diretto con cURL**
```bash
curl -X GET 'https://api.supadata.ai/v1/youtube/transcript?url=https://www.youtube.com/watch?v=jNQXAC9IVRw&text=true&mode=native' \
  -H 'x-api-key: YOUR_API_KEY_HERE'
```

**Risposta attesa (200):**
```json
{
  "content": "...",
  "lang": "en",
  "availableLangs": ["en"]
}
```

**Errore API key (401):**
```json
{
  "error": "Invalid API key"
}
```

### 4. **Verifica Headers WordPress**
Alcuni server potrebbero bloccare header custom. Test:
```php
// In wp-admin/admin-ajax.php o plugin test file
$response = wp_remote_get('https://api.supadata.ai/v1/youtube/transcript?url=https://youtube.com/watch?v=jNQXAC9IVRw&text=true', [
    'headers' => [
        'x-api-key' => 'YOUR_KEY'
    ]
]);
var_dump($response);
```

---

## 📞 Quando Contattare Support

Contatta support se:

1. ✅ Hai verificato API key corretta
2. ✅ Test cURL funziona ma plugin fallisce
3. ✅ Hai controllato logs e non capisci l'errore
4. ✅ Hai aggiornato a v12.1.1

**Informazioni da fornire:**
- Versione plugin: v12.1.1
- Codice HTTP ricevuto: (es: 401, 404, etc.)
- Messaggio errore completo
- WordPress error log excerpt
- Output test cURL (se disponibile)

---

## 🎯 Checklist Finale

Prima di dire "non funziona":

- [ ] API key configurata e copiata correttamente
- [ ] URL base è `https://api.supadata.ai/v1`
- [ ] Plugin aggiornato a v12.1.1
- [ ] Test connection cliccato in settings
- [ ] WordPress debug log controllato
- [ ] Connessione internet del server OK
- [ ] Firewall permette api.supadata.ai
- [ ] Test cURL eseguito con successo
- [ ] Credits sufficienti su SupaData account

---

## ✨ Se Test Passa Ma Import Fallisce

Problema diverso! Vedi:
- `TROUBLESHOOTING-IMPORT.md` per problemi di import
- `SUPADATA-INTEGRATION-README.md` per dettagli integrazione

---

## 📚 Riferimenti

- **SupaData Docs:** https://docs.supadata.ai
- **API Reference:** `SUPADATA-DOCS.md`
- **Integration Guide:** `SUPADATA-INTEGRATION-README.md`
- **Plugin README:** `README.md`

---

**Versione:** 12.1.1  
**Ultima modifica:** Ottobre 2025  
**Correzioni:** Endpoint fix + Better error handling
