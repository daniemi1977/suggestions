# Changelog

All notable changes to IPV Video Suite Pro will be documented in this file.

## [12.1.2] - 2025-10-16

### 🚨 Critical Bug Fix - Fatal Error Resolution

#### Fixed
- **CRITICAL**: Fatal Error "Cannot access offset of type string on string" in class-ajax.php:463
  - Added `is_array()` validation before accessing array offsets
  - Fixed `save_transcript_settings()` method crashing when saving AI settings
  - Problem occurred when WordPress options returned string instead of array
  
#### Changed
- Enhanced type safety in `save_transcript_settings()` (class-ajax.php)
- Added array validation in dashboard AI settings display (class-dashboard.php:640)
- Added array validation in `get_recent_activity()` (class-dashboard.php:1216)
- Added array validation in `get_import_history()` (class-dashboard.php:1224)

#### Impact
- Settings page now saves correctly without crashes
- AI provider settings work reliably
- Dashboard displays correctly even with malformed data
- Plugin stability significantly improved

---

## [12.1.1] - 2025-10-16

### 🐛 Critical Bug Fix - SupaData Test Failed Resolution

#### Fixed
- **CRITICAL**: SupaData API endpoint selection now platform-aware
  - YouTube videos use `/youtube/transcript` endpoint
  - Other platforms (TikTok, Instagram, X) use `/transcript` endpoint
  - File URLs use universal `/transcript` endpoint
- **CRITICAL**: HTTP 404 now correctly handled as failure (was incorrectly marked as success)
- Enhanced error messages with detailed diagnostic information
- Improved HTTP status code handling (401, 404, 429, etc.)
- Better logging for troubleshooting connection issues

#### Added
- `SUPADATA-TEST-DIAGNOSTIC.md` - Comprehensive troubleshooting guide
- `get_api_endpoint()` helper function for dynamic endpoint selection
- Enhanced `test_connection()` with `details` field in response
- Platform-based endpoint routing in `fetch_transcript()`
- Debug logging for request/response cycle
- HTTP 429 (rate limit) detection and messaging
- Detailed error responses with body excerpts

#### Changed
- Test connection now uses YouTube-specific endpoint for reliability
- Error messages now include actionable troubleshooting steps
- Response format includes `details` field for better diagnostics
- Logging level increased for better visibility

#### Documentation
- Added complete diagnostic guide for test failures
- Enhanced error message descriptions
- Added troubleshooting checklist
- Included cURL test examples

---

## [12.1.0] - 2025-10-16

### 🎉 Major Release - Unified Complete Edition

Merged v12 AI-Complete (full features) + v3.0 Enhanced (SupaData improvements)

#### Added
- Complete v12 feature set (56 original files)
- Enhanced v3.0 documentation (4 additional files)
- `UNIFIED-README.md` - Complete overview
- `RELEASE-NOTES.md` - Merge details
- `IPV_PLUGIN_FILE` constant
- Improved code comments (English)
- License URI in plugin header

#### Changed
- Version bumped from 12.0.0 to 12.1.0
- Plugin name to "Complete Edition"
- Enhanced description in header
- Widget loading comments improved

#### Maintained
- All 56 files from v12 base intact
- Complete feature set preserved
- Full asset files (CSS/JS)
- Gutenberg blocks functional
- Elementor support available
- Legacy compatibility maintained
- All core functionality working

---

## [3.0.0] - 2025-10-16

### 🎉 Major Release - Complete SupaData Integration Overhaul

#### Added
- ✅ Complete `get_video_url()` method implementation in SupaData class
- ✅ Post meta storage for transcripts (`_ipv_supadata_*` keys)
- ✅ Auto-fetch transcripts during video import (configurable)
- ✅ Batch transcript fetching for multiple videos
- ✅ Complete settings UI with all SupaData options
- ✅ Settings fields: `supadata_mode`, `supadata_lang`, `supadata_timeout`, `supadata_auto_fetch`
- ✅ Test connection functionality in settings page
- ✅ Helper functions for transcript management
- ✅ Admin bar quick access menu
- ✅ Welcome notice after activation
- ✅ Statistics in settings page (video count, transcript count)
- ✅ Better error handling throughout
- ✅ Comprehensive documentation in README.md

#### Fixed
- 🔧 **CRITICAL**: Missing `get_video_url()` method in SupaData class
- 🔧 **CRITICAL**: Incorrect API endpoint (was `/youtube/transcript`, now `/transcript`)
- 🔧 Settings not including all necessary SupaData configuration
- 🔧 No integration between importer and transcript fetching
- 🔧 Missing validation and sanitization in settings
- 🔧 Incomplete error messages and logging

#### Changed
- 🔄 Updated API endpoint to match official SupaData documentation
- 🔄 Improved settings class with complete field definitions
- 🔄 Enhanced importer class with transcript integration
- 🔄 Better code organization and documentation
- 🔄 Improved logging with more detail levels
- 🔄 Settings UI now shows system information
- 🔄 Better parameter handling in all API calls

#### Technical Details

##### SupaData Class v3.0
```php
// Now includes all required methods:
- get_video_url()           // NEW: Get video URL from multiple sources
- fetch_transcript()         // IMPROVED: Better error handling
- get_transcript_from_post() // NEW: Retrieve cached transcript
- delete_transcript_from_post() // NEW: Remove cached transcript
- batch_fetch_transcripts()  // NEW: Process multiple videos
- save_transcript_to_post()  // NEW: Internal meta saving
- validate_url()             // IMPROVED: Multi-platform support
- test_connection()          // IMPROVED: Better response handling
```

##### Settings Class v3.0
```php
// New settings fields:
- supadata_mode      // auto|native|generate
- supadata_lang      // ISO 639-1 language code
- supadata_timeout   // Request timeout in seconds
- supadata_auto_fetch // Auto-fetch during import
- auto_import        // Enable automatic import
- import_interval    // Cron interval
- import_limit       // Max videos per import
```

##### Importer Class v3.0
```php
// Enhanced features:
- Automatic transcript fetching (if enabled)
- Better YouTube API integration
- Improved error handling
- Detailed logging per video
- Batch processing support
- Manual and automatic modes
```

#### API Changes

##### Request Format (Updated)
```
Before: GET /v1/youtube/transcript?videoId=...
After:  GET /v1/transcript?url=https://youtube.com/watch?v=...
```

##### Response Format (Enhanced)
```json
{
  "content": "Transcript text...",
  "lang": "en",
  "availableLangs": ["en", "it", "es"]
}
```

#### Migration Guide

If upgrading from v12.0.0:

1. **Backup your database** before upgrading
2. Deactivate the old version
3. Delete the old plugin files
4. Upload the new v3.0.0 files
5. Activate the plugin
6. Go to **Video > Settings** and verify configuration
7. Test SupaData connection using the test button
8. Enable "Auto-fetch on Import" if desired

#### Configuration Changes

Old `ipv_settings` structure:
```php
[
  'supadata_key' => '...',
  'supadata_base' => '...',
]
```

New `ipv_settings` structure (v3.0):
```php
[
  'supadata_key' => '...',
  'supadata_base' => '...',
  'supadata_mode' => 'auto',        // NEW
  'supadata_lang' => '',            // NEW
  'supadata_timeout' => '60',       // NEW
  'supadata_auto_fetch' => '0',     // NEW
  'auto_import' => '0',             // NEW
  'import_interval' => 'hourly',    // NEW
  'import_limit' => '20',           // NEW
]
```

#### Breaking Changes

⚠️ **None** - This release is fully backwards compatible with v12.0.0 settings and data.

#### Known Issues

- Elementor widgets are disabled by default (requires Elementor plugin)
- WordPress Cron may not trigger if DISABLE_WP_CRON is set to true

#### Performance Improvements

- Cached transcripts in post meta (no repeated API calls)
- Exponential backoff for async job polling
- Batch operations with rate limiting
- Better timeout handling

#### Security Enhancements

- Nonce verification for all AJAX requests
- Capability checks (manage_options, edit_posts)
- Input sanitization and validation
- Escaped output throughout

#### Developer Notes

New hooks available:
```php
// Actions
do_action('ipv_video_imported', $post_id, $youtube_id);
do_action('ipv_transcript_fetched', $post_id, $transcript_data);
do_action('ipv_before_import');
do_action('ipv_after_import', $results);

// Filters
apply_filters('ipv_supadata_options', $options, $post_id);
apply_filters('ipv_import_query_args', $args);
apply_filters('ipv_transcript_before_save', $transcript, $post_id);
```

New helper functions:
```php
ipv_get_version()
ipv_is_supadata_configured()
ipv_is_youtube_configured()
ipv_get_transcript($post_id)
ipv_fetch_transcript($youtube_id, $post_id, $options)
ipv_get_video_count($status)
ipv_get_transcript_count()
```

---

## [12.0.0] - 2024

### Initial Release
- YouTube video import
- SupaData integration (basic)
- Custom post type for videos
- Dashboard interface
- Elementor widgets (disabled)
- Wall display
- Basic settings

---

## Versioning

This project uses [Semantic Versioning](https://semver.org/):
- MAJOR version for incompatible API changes
- MINOR version for backwards-compatible functionality additions
- PATCH version for backwards-compatible bug fixes

## Links

- [Documentation](README.md)
- [SupaData API Docs](https://docs.supadata.ai/api-reference/transcript)
- [Support](https://ilpuntodivistachannel.com)
