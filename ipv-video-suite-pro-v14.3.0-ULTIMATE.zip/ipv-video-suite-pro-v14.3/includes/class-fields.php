<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_Fields')){
class IPV_Fields {

    public static function init(){
        add_action('add_meta_boxes', array(__CLASS__,'add_metabox'));
        add_action('save_post_ipv_video', array(__CLASS__,'save_meta'), 10, 2);
        add_action('admin_post_ipv_fields_generate', array(__CLASS__,'handle_generate'));
        add_action('admin_post_ipv_fields_export_txt', array(__CLASS__,'handle_export_txt'));
        // Transcript viewer
        add_action('add_meta_boxes', function(){
            add_meta_box('ipv_transcript_box','Trascrizione (SupaData)', array(__CLASS__,'render_transcript'), 'ipv_video', 'normal', 'default');
        }, 12);
    }

    public static function add_metabox(){
        add_meta_box('ipv_fields_compact','IPDV — Layout Compatto (Campi)', array(__CLASS__, 'render_box'), 'ipv_video', 'normal', 'high');
    }

    protected static function field_text($id,$label,$value,$placeholder=''){
        printf('<p><label for="%s"><strong>%s</strong></label><br/>', esc_attr($id), esc_html($label));
        printf('<input type="text" id="%s" name="%s" value="%s" class="widefat" placeholder="%s"/>',
            esc_attr($id), esc_attr($id), esc_attr($value), esc_attr($placeholder));
        echo '</p>';
    }
    protected static function field_textarea($id,$label,$value,$rows=5,$placeholder=''){
        printf('<p><label for="%s"><strong>%s</strong></label><br/>', esc_attr($id), esc_html($label));
        printf('<textarea id="%s" name="%s" rows="%d" class="widefat" placeholder="%s">%s</textarea>',
            esc_attr($id), esc_attr($id), intval($rows), esc_attr($placeholder), esc_textarea($value));
        echo '</p>';
    }

    public static function render_box($post){
        wp_nonce_field('ipv_fields_save','ipv_fields_nonce');
        $vals = array(
            '_ipv_title_opt'       => get_post_meta($post->ID, '_ipv_title_opt', true),
            '_ipv_descrizione'     => get_post_meta($post->ID, '_ipv_descrizione', true),
            '_ipv_sponsor'         => get_post_meta($post->ID, '_ipv_sponsor', true),
            '_ipv_minutaggio'      => get_post_meta($post->ID, '_ipv_minutaggio', true),
            '_ipv_argomenti'       => get_post_meta($post->ID, '_ipv_argomenti', true),
            '_ipv_ospiti'          => get_post_meta($post->ID, '_ipv_ospiti', true),
            '_ipv_persone'         => get_post_meta($post->ID, '_ipv_persone', true),
            '_ipv_regia'           => get_post_meta($post->ID, '_ipv_regia', true),
            '_ipv_eventi'          => get_post_meta($post->ID, '_ipv_eventi', true),
            '_ipv_link_utili'      => get_post_meta($post->ID, '_ipv_link_utili', true),
            '_ipv_donazioni'       => get_post_meta($post->ID, '_ipv_donazioni', true),
            '_ipv_abbonati'        => get_post_meta($post->ID, '_ipv_abbonati', true),
            '_ipv_social_telegram' => get_post_meta($post->ID, '_ipv_social_telegram', true),
            '_ipv_social_facebook' => get_post_meta($post->ID, '_ipv_social_facebook', true),
            '_ipv_social_instagram'=> get_post_meta($post->ID, '_ipv_social_instagram', true),
            '_ipv_contatti'        => get_post_meta($post->ID, '_ipv_contatti', true),
            '_ipv_temi'            => get_post_meta($post->ID, '_ipv_temi', true),
            '_ipv_hashtag'         => get_post_meta($post->ID, '_ipv_hashtag', true),
        );
        $gen_url = wp_nonce_url( admin_url('admin-post.php?action=ipv_fields_generate&post_id='.$post->ID), 'ipv_fields_generate' );
        $exp_url = wp_nonce_url( admin_url('admin-post.php?action=ipv_fields_export_txt&post_id='.$post->ID), 'ipv_fields_export' );

        echo '<p style="display:flex;gap:8px">';
        echo '<a class="button button-primary" href="'.esc_url($gen_url).'">Genera dai Transcript (AI)</a>';
        echo '<a class="button" href="'.esc_url($exp_url).'">Esporta .txt (layout compatto)</a>';
        echo '</p>';

        echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">';
        echo '<div>';
        self::field_text('_ipv_title_opt','Titolo ottimizzato', $vals['_ipv_title_opt']);
        self::field_textarea('_ipv_descrizione','Descrizione (max ~1200 char)', $vals['_ipv_descrizione'], 6);
        self::field_text('_ipv_sponsor','Sponsor', $vals['_ipv_sponsor'], 'Biovital – Progetto Italia …');
        self::field_textarea('_ipv_minutaggio','Minutaggio (una riga per voce: 00:00 – Titolo)', $vals['_ipv_minutaggio'], 6);
        self::field_textarea('_ipv_argomenti','Argomenti (uno per riga)', $vals['_ipv_argomenti'], 4);
        self::field_textarea('_ipv_eventi','Eventi (uno per riga: Data – Evento – Link/Modalità)', $vals['_ipv_eventi'], 4);
        self::field_textarea('_ipv_link_utili','Link utili (uno per riga)', $vals['_ipv_link_utili'], 4);
        echo '</div><div>';
        self::field_textarea('_ipv_ospiti','Ospiti (uno per riga)', $vals['_ipv_ospiti'], 4);
        self::field_textarea('_ipv_persone','Persone menzionate (uno per riga)', $vals['_ipv_persone'], 4);
        self::field_text('_ipv_regia','Regia', $vals['_ipv_regia'], 'Il Punto di Vista');
        self::field_text('_ipv_donazioni','Donazioni (URL)', $vals['_ipv_donazioni'], 'https://paypal.me/adrianfiorelli');
        self::field_text('_ipv_abbonati','Abbonati al canale (/ @handle )', $vals['_ipv_abbonati'], '/ @ilpuntodivista');
        self::field_text('_ipv_social_telegram','Telegram', $vals['_ipv_social_telegram'], 'https://t.me/il_punto_divista');
        self::field_text('_ipv_social_facebook','Facebook', $vals['_ipv_social_facebook'], 'https://facebook.com/groups/4102938329737588');
        self::field_text('_ipv_social_instagram','Instagram', $vals['_ipv_social_instagram'], 'https://instagram.com/_ilpuntodivista._');
        self::field_text('_ipv_contatti','Contatti (email)', $vals['_ipv_contatti'], 'ilpuntodivistaredazione@gmail.com');
        self::field_textarea('_ipv_temi','Temi del canale (uno per riga)', $vals['_ipv_temi'], 3, 'Esoterismo…');
        self::field_textarea('_ipv_hashtag','Hashtag (separati da spazi o righe)', $vals['_ipv_hashtag'], 3, '#ipdv #misteri …');
        echo '</div></div>';
    }

    public static function render_transcript($post){
        $raw = get_post_meta($post->ID, '_ipv_transcript', true);
        $lines = $raw ? substr_count($raw, "\n") + 1 : 0;
        echo '<p><small>Righe: '.intval($lines).'</small></p>';
        echo '<textarea readonly style="width:100%;height:260px">'.esc_textarea($raw).'</textarea>';
        $reload = wp_nonce_url( admin_url('admin-post.php?action=ipv_tool_transcript&post_id='.$post->ID), 'ipv_tool_transcript' );
        echo '<p><a class="button" href="'.esc_url($reload).'">Ricarica Trascrizione (SupaData)</a></p>';
    }

    public static function save_meta($post_id, $post){
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        if (!isset($_POST['ipv_fields_nonce']) || !wp_verify_nonce($_POST['ipv_fields_nonce'],'ipv_fields_save')) return;

        $keys = array('_ipv_title_opt','_ipv_descrizione','_ipv_sponsor','_ipv_minutaggio','_ipv_argomenti','_ipv_ospiti','_ipv_persone','_ipv_regia','_ipv_eventi','_ipv_link_utili','_ipv_donazioni','_ipv_abbonati','_ipv_social_telegram','_ipv_social_facebook','_ipv_social_instagram','_ipv_contatti','_ipv_temi','_ipv_hashtag');
        foreach($keys as $k){
            if (isset($_POST[$k])) update_post_meta($post_id, $k, wp_kses_post($_POST[$k]));
        }
        if (!empty($_POST['_ipv_title_opt'])){
            wp_update_post(array('ID'=>$post_id,'post_title'=>sanitize_text_field($_POST['_ipv_title_opt'])));
        }
    }

    public static function handle_generate(){
        if (!current_user_can('edit_posts')) wp_die('Not allowed');
        if (empty($_GET['post_id'])) wp_die('Missing post_id');
        check_admin_referer('ipv_fields_generate');
        $post_id = absint($_GET['post_id']);
        self::generate_for_post($post_id);
        wp_safe_redirect( get_edit_post_link($post_id,'') ); exit;
    }

    public static function generate_for_post($post_id){
        error_log("🚀 IPV: Inizio generate_for_post per post_id={$post_id}");
        
        $transcript = get_post_meta($post_id, '_ipv_transcript', true);
        if (!$transcript && class_exists('IPV_SupaData')){
            error_log("📥 IPV: Trascrizione non trovata, scarico da SupaData...");
            $st = get_option('ipv_settings', array());
            $lang = !empty($st['supadata_lang']) ? $st['supadata_lang'] : 'it';
            $yid = get_post_meta($post_id,'_ipv_youtube_id',true);
            if (!$yid){
                $url = get_post_meta($post_id,'_ipv_youtube_url',true);
                if ($url && preg_match('~v=([A-Za-z0-9_-]{11})~',$url,$m)) $yid = $m[1];
            }
            if ($yid){
                error_log("📹 IPV: YouTube ID trovato: {$yid}");
                $transcript = IPV_SupaData::fetch_transcript($yid, $post_id, array('lang'=>$lang,'save'=>true));
                if($transcript) error_log("✅ IPV: Trascrizione scaricata (".strlen($transcript)." caratteri)");
                else error_log("❌ IPV: Errore scaricamento trascrizione da SupaData");
            } else {
                error_log("❌ IPV: YouTube ID non trovato");
            }
        } else if($transcript) {
            error_log("✅ IPV: Trascrizione già presente (".strlen($transcript)." caratteri)");
        }
        
        if (!$transcript) {
            error_log("❌ IPV: Nessuna trascrizione disponibile, esco");
            return false;
        }

        $o = get_option('ipv_settings', array());
        $api_key = !empty($o['openai_api_key']) ? $o['openai_api_key'] : '';
        $model   = !empty($o['openai_model']) ? $o['openai_model'] : 'gpt-4o-mini';
        
        if (!$api_key) {
            error_log("❌ IPV: OpenAI API Key non configurata! Vai in Impostazioni > IPV Video per configurarla.");
            return false;
        }
        
        error_log("🤖 IPV: Chiamo OpenAI (modello: {$model})...");
        $prompt = self::build_prompt();
        $json   = self::call_openai_json($prompt, $transcript, $api_key, $model);
        
        if (!$json || !is_array($json)) {
            error_log("❌ IPV: Risposta OpenAI non valida o vuota");
            return false;
        }

        error_log("✅ IPV: Risposta OpenAI ricevuta, salvo i dati...");
        self::save_from_json($post_id, $json);
        update_post_meta($post_id, '_ipv_ai_status', 'generated');
        update_post_meta($post_id, '_ipv_ai_raw_content', wp_json_encode($json));
        error_log("🎉 IPV: Generazione completata con successo!");
        return true;
    }

    protected static function build_prompt(){
        $fallback_sponsor   = "Biovital – Progetto Italia\nSostieni il progetto: 👉 https://biovital-italia.com/?bio=17";
        $fallback_donazioni = "https://paypal.me/adrianfiorelli";
        $fallback_abbonati  = "/ @ilpuntodivista";
        $fallback_regia     = "Il Punto di Vista";
        
        $p  = "Sei un esperto di ottimizzazione video per il canale YouTube \"Il Punto di Vista\", che tratta temi di esoterismo, spiritualità, misteri, geopolitica, disclosure alternativo, cospirazioni, archeologia misteriosa, fenomeni paranormali e UFO.\n\n";
        
        $p .= "Il canale ha uno stile:\n";
        $p .= "- Approfondito e informativo\n";
        $p .= "- Professionale ma accessibile\n";
        $p .= "- Critico verso le narrazioni ufficiali\n";
        $p .= "- Interessato a verità nascoste e conoscenze alternative\n";
        $p .= "- Audience: persone curiose, liberi pensatori, ricercatori indipendenti\n\n";
        
        $p .= "In base alla trascrizione seguente, genera SOLO JSON valido (UTF-8) con queste chiavi esatte:\n\n";
        
        $p .= "- title_opt: string (max 70 caratteri, accattivante, ottimizzato SEO per YouTube, che catturi l'attenzione su temi del canale)\n";
        $p .= "- descrizione: string (max 1200 caratteri, strutturata così:)\n";
        $p .= "  * Paragrafo introduttivo accattivante (2-3 frasi che catturano l'attenzione)\n";
        $p .= "  * Paragrafo principale con argomenti trattati (3-4 frasi dettagliate)\n";
        $p .= "  * Menzione sponsor (se presente) o fallback Biovital\n";
        $p .= "  * Sezione \"In questo video:\" con punti elenco degli argomenti\n";
        $p .= "  * Invito all'azione (iscrizione, like, commenti, condivisione)\n";
        $p .= "- sponsor: string (nome sponsor con link se disponibile, altrimenti usa fallback Biovital)\n";
        $p .= "- minutaggio: array di stringhe formato 'MM:SS – Titolo sezione' (identifica le tappe principali del video, minimo 5-8 timestamp)\n";
        $p .= "- argomenti: array di stringhe (argomenti principali trattati, max 10)\n";
        $p .= "- ospiti: array di stringhe (nomi completi ospiti/intervistati, se presenti)\n";
        $p .= "- persone: array di stringhe (personaggi storici, esperti, figure menzionate nel video)\n";
        $p .= "- regia: string (chi ha curato la regia/produzione, default \"Il Punto di Vista\")\n";
        $p .= "- eventi: array di stringhe formato 'DATA – Nome Evento – Modalità/Link' (conferenze, incontri, eventi menzionati)\n";
        $p .= "- link_utili: array di stringhe (URL o 'Titolo – URL' di risorse, documenti, fonti citate)\n";
        $p .= "- donazioni: string (URL per donazioni, fallback PayPal)\n";
        $p .= "- abbonati: string (handle YouTube, formato '/ @ilpuntodivista')\n";
        $p .= "- temi: array di stringhe (temi e categorie del video: Esoterismo, Spiritualità, Misteri, Geopolitica, UFO, Disclosure, ecc.)\n";
        $p .= "- hashtag: array di stringhe (max 30 hashtag pertinenti, SEMPRE includere #IlPuntoDiVista, poi altri rilevanti per il contenuto specifico come #UFO #Disclosure #Mistero #Esoterismo #Spiritualità #Geopolitica ecc.)\n";
        $p .= "- social: object con chiavi telegram, facebook, instagram (URL social del canale)\n";
        $p .= "- contatti: string (email redazione: ilpuntodivistaredazione@gmail.com)\n\n";
        
        $p .= "REGOLE IMPORTANTI:\n";
        $p .= "1. Mantieni tutte le sezioni. Se mancano informazioni, usa 'nessuno' o i fallback indicati\n";
        $p .= "2. NON aggiungere testo fuori dal JSON (no markdown, no backtick, no commenti)\n";
        $p .= "3. Il title_opt deve essere accattivante e ottimizzato per YouTube (max 70 caratteri)\n";
        $p .= "4. La descrizione deve essere completa, ben strutturata, SEO-friendly e invitante\n";
        $p .= "5. Il minutaggio deve avere timestamp accurati basati sulla trascrizione (formato MM:SS)\n";
        $p .= "6. Gli hashtag devono essere pertinenti e sempre includere #IlPuntoDiVista\n";
        $p .= "7. Usa un tono professionale ma accessibile, adatto al pubblico del canale\n";
        $p .= "8. Evidenzia gli aspetti più intriganti e misteriosi del contenuto\n\n";
        
        $p .= "FALLBACK da usare se le informazioni mancano:\n";
        $p .= "- sponsor: {$fallback_sponsor}\n";
        $p .= "- donazioni: {$fallback_donazioni}\n";
        $p .= "- abbonati: {$fallback_abbonati}\n";
        $p .= "- regia: {$fallback_regia}\n";
        $p .= "- social.telegram: https://t.me/il_punto_divista\n";
        $p .= "- social.facebook: https://facebook.com/groups/4102938329737588\n";
        $p .= "- social.instagram: https://instagram.com/_ilpuntodivista._\n";
        $p .= "- contatti: ilpuntodivistaredazione@gmail.com\n";
        $p .= "- temi: [\"Esoterismo\", \"Spiritualità\", \"Misteri\", \"Geopolitica\", \"Divulgazione alternativa\"]\n\n";
        
        $p .= "Restituisci SOLO il JSON valido, senza altro testo prima o dopo.\n";
        
        return $p;
    }

    protected static function call_openai_json($prompt, $transcript, $api_key, $model){
        // Limita la trascrizione a ~15000 caratteri per evitare costi eccessivi
        $transcript_limited = mb_substr($transcript, 0, 15000);
        
        $body = array(
            'model' => $model,
            'messages' => array(
                array('role'=>'system','content'=>'Sei un esperto di ottimizzazione video per YouTube specializzato nel canale "Il Punto di Vista". Restituisci SOLO JSON valido, senza markdown, backtick o altro testo.'),
                array('role'=>'user','content'=> $prompt . "\n\n--- TRANSCRIPT ---\n" . $transcript_limited)
            ),
            'temperature' => 0.7,
            'max_tokens' => 3000,
        );
        $args = array(
            'timeout' => 90,
            'headers' => array('Authorization'=>'Bearer '.$api_key,'Content-Type'=>'application/json'),
            'body'    => wp_json_encode($body),
        );
        
        error_log("🌐 IPV: Invio richiesta a OpenAI...");
        $r = wp_remote_post('https://api.openai.com/v1/chat/completions', $args);
        
        if (is_wp_error($r)) {
            error_log("❌ IPV: Errore wp_remote_post: " . $r->get_error_message());
            return null;
        }
        
        $code = wp_remote_retrieve_response_code($r);
        $payload = json_decode(wp_remote_retrieve_body($r), true);
        
        error_log("📡 IPV: Risposta OpenAI - Status Code: {$code}");
        
        if ($code !== 200) {
            $error_msg = isset($payload['error']['message']) ? $payload['error']['message'] : 'Errore sconosciuto';
            error_log("❌ IPV: Errore OpenAI API (code {$code}): {$error_msg}");
            return null;
        }
        
        if (empty($payload['choices'][0]['message']['content'])) {
            error_log("❌ IPV: Risposta OpenAI vuota o malformata");
            return null;
        }
        
        $txt = trim($payload['choices'][0]['message']['content']);
        error_log("📝 IPV: Contenuto risposta: " . substr($txt, 0, 200) . "...");
        
        $data = json_decode($txt, true);
        if (is_array($data)) {
            error_log("✅ IPV: JSON parsato correttamente");
            return $data;
        }
        
        // Try to extract JSON from markdown code block
        if (preg_match('/```json(.*?)```/is', $txt, $m)){
            $data = json_decode(trim($m[1]), true);
            if (is_array($data)) {
                error_log("✅ IPV: JSON estratto da markdown code block");
                return $data;
            }
        }
        
        error_log("❌ IPV: Impossibile parsare il JSON dalla risposta OpenAI");
        return null;
    }

    protected static function save_from_json($post_id, $j){
        $g = function($k,$d=''){ return isset($j[$k]) ? $j[$k] : $d; };
        $title = sanitize_text_field($g('title_opt',''));
        if ($title){ update_post_meta($post_id,'_ipv_title_opt',$title); wp_update_post(array('ID'=>$post_id,'post_title'=>$title)); }
        $descr = wp_kses_post($g('descrizione','')); update_post_meta($post_id,'_ipv_descrizione',$descr);
        $sponsor = wp_kses_post($g('sponsor','')); update_post_meta($post_id,'_ipv_sponsor',$sponsor);
        $minu = $g('minutaggio',array()); if (is_array($minu)) $minu = implode("\n", array_map('sanitize_text_field',$minu)); update_post_meta($post_id,'_ipv_minutaggio',$minu);
        $arg = $g('argomenti',array()); if (is_array($arg)) $arg = implode("\n", array_map('sanitize_text_field',$arg)); update_post_meta($post_id,'_ipv_argomenti',$arg);
        $osp = $g('ospiti',array()); if (is_array($osp)) $osp = implode("\n", array_map('sanitize_text_field',$osp)); update_post_meta($post_id,'_ipv_ospiti',$osp);
        $per = $g('persone',array()); if (is_array($per)) $per = implode("\n", array_map('sanitize_text_field',$per)); update_post_meta($post_id,'_ipv_persone',$per);
        $reg = sanitize_text_field($g('regia','Il Punto di Vista')); update_post_meta($post_id,'_ipv_regia',$reg);
        $evt = $g('eventi',array()); if (is_array($evt)) $evt = implode("\n", array_map('sanitize_text_field',$evt)); update_post_meta($post_id,'_ipv_eventi',$evt);
        $links = $g('link_utili',array()); if (is_array($links)) $links = implode("\n", array_map('sanitize_text_field',$links)); update_post_meta($post_id,'_ipv_link_utili',$links);
        $don = esc_url_raw($g('donazioni','https://paypal.me/adrianfiorelli')); update_post_meta($post_id,'_ipv_donazioni',$don);
        $abb = sanitize_text_field($g('abbonati','/ @ilpuntodivista')); update_post_meta($post_id,'_ipv_abbonati',$abb);
        $temi = $g('temi',array()); if (is_array($temi)) $temi = implode("\n", array_map('sanitize_text_field',$temi)); update_post_meta($post_id,'_ipv_temi',$temi);
        $hash = $g('hashtag',array()); if (is_array($hash)) { $hash = ' ' . implode(' ', array_map(function($h){ $h = trim($h); if ($h!=='' && $h[0] !== '#') $h = '#'.$h; return sanitize_text_field($h); }, $hash)); } update_post_meta($post_id,'_ipv_hashtag', trim($hash));

        $soc = $g('social', array());
        $tg = is_array($soc) && !empty($soc['telegram']) ? esc_url_raw($soc['telegram']) : '';
        $fb = is_array($soc) && !empty($soc['facebook']) ? esc_url_raw($soc['facebook']) : '';
        $ig = is_array($soc) && !empty($soc['instagram']) ? esc_url_raw($soc['instagram']) : '';
        update_post_meta($post_id,'_ipv_social_telegram',$tg);
        update_post_meta($post_id,'_ipv_social_facebook',$fb);
        update_post_meta($post_id,'_ipv_social_instagram',$ig);

        $cont = sanitize_text_field($g('contatti','ilpuntodivistaredazione@gmail.com')); update_post_meta($post_id,'_ipv_contatti',$cont);
    }

    public static function handle_export_txt(){
        if (!current_user_can('edit_posts')) wp_die('Not allowed');
        if (empty($_GET['post_id'])) wp_die('Missing post_id');
        check_admin_referer('ipv_fields_export');
        $post_id = absint($_GET['post_id']);
        $g = function($k,$d=''){ $v=get_post_meta($post_id,$k,true); return ($v!==''&&$v!==null)?$v:$d; };
        $title = get_the_title($post_id); $title_opt = $g('_ipv_title_opt',$title); $descr=$g('_ipv_descrizione','non indicato');
        $sponsor=$g('_ipv_sponsor','Biovital – Progetto Italia\nSostieni il progetto: 👉 https://biovital-italia.com/?bio=17');
        $minu=$g('_ipv_minutaggio','00:00 – Intro'); $arg=$g('_ipv_argomenti','nessuno'); $osp=$g('_ipv_ospiti','nessuno'); $per=$g('_ipv_persone','nessuno');
        $reg=$g('_ipv_regia','Il Punto di Vista'); $evt=$g('_ipv_eventi','Nessun evento in programma'); $lnk=$g('_ipv_link_utili','');
        $don=$g('_ipv_donazioni','https://paypal.me/adrianfiorelli'); $abb=$g('_ipv_abbonati','/ @ilpuntodivista');
        $tg=$g('_ipv_social_telegram','https://t.me/il_punto_divista'); $fb=$g('_ipv_social_facebook','https://facebook.com/groups/4102938329737588'); $ig=$g('_ipv_social_instagram','https://instagram.com/_ilpuntodivista._');
        $ct=$g('_ipv_contatti','ilpuntodivistaredazione@gmail.com'); $temi=$g('_ipv_temi','Esoterismo – Spiritualità – Misteri – Geopolitica – Divulgazione alternativa'); $hash=$g('_ipv_hashtag','');

        $dash=function($s){ $s=trim((string)$s); if($s==='') return 'nessuno'; $out=array(); foreach(preg_split('/\r?\n/',$s) as $l){ $l=trim($l); if($l==='') continue; $out[]=(strpos($l,'–')===0||strpos($l,'-')===0)?$l:'– '.$l; } return implode("\n",$out); };

        $txt  = "📺 **Titolo episodio**\n\n".$title_opt."\n\n---\n\n";
        $txt .= "📌 **Descrizione**\n\n".$descr."\n\n---\n\n";
        $txt .= "🎁 **Sponsor**\n\n".$sponsor."\n\n---\n\n";
        $txt .= "⏱️ **Minutaggio**\n\n".$minu."\n\n---\n\n";
        $txt .= "📖 **Argomenti trattati**\n\n".$dash($arg)."\n\n---\n\n";
        $txt .= "👤 **Ospiti**\n\n".$dash($osp)."\n\n---\n\n";
        $txt .= "📌 **Persone menzionate**\n\n".$dash($per)."\n\n---\n\n";
        $txt .= "🎥 **Regia**\n\n".$reg."\n\n---\n\n";
        $txt .= "🔔 **Eventi**\n\n".$evt."\n\n---\n\n";
        if (strlen(trim($lnk))>0){ $txt .= "🔗 **Link utili**\n\n".$lnk."\n\n---\n\n"; }
        $txt .= "❤️ **Donazioni**\n\nPer sostenere il canale e i progetti de **Il Punto di Vista** basta fare una donazione a questo link:\n\n👉 ".$don."\n\nGrazie in anticipo a tutti i pirati 🖤🏴‍☠️\n\n---\n\n";
        $txt .= "🙏 **Abbonati al canale**\n\n".$abb."\n\n---\n\n";
        $txt .= "🌐 **Social**\n\nTelegram 👉 ".$tg."\n\nFacebook 👉 ".$fb."\n\nInstagram 👉 ".$ig."\n\n---\n\n";
        $txt .= "📩 **Contatti**\n\n✉️ ".$ct."\n\n---\n\n";
        $txt .= "🎯 **Temi del canale**\n\n".$temi."\n\n---\n\n";
        $txt .= "#️⃣ **Hashtag**\n\n".$hash."\n";
        $fname=sanitize_title(get_the_title($post_id)); if(!$fname) $fname='episodio'; $fname.='-layout-compatto.txt';
        nocache_headers(); header('Content-Type: text/plain; charset=utf-8'); header('Content-Disposition: attachment; filename="'.$fname.'"'); echo $txt; exit;
    }
}}
