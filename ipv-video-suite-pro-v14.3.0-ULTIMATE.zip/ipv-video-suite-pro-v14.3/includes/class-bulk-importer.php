<?php
/**
 * Bulk Importer Class - SIMPLIFIED
 * Import massivo + rigenerazione thumbs/trascrizioni
 */

if (!defined('ABSPATH')) exit;

class IPV_Bulk_Importer {
    
    public static function init() {
        // AJAX handlers
        add_action('wp_ajax_ipv_bulk_import_ids', [__CLASS__, 'ajax_import_ids']);
        add_action('wp_ajax_ipv_bulk_regenerate_thumbs', [__CLASS__, 'ajax_regenerate_thumbs']);
        add_action('wp_ajax_ipv_bulk_regenerate_transcripts', [__CLASS__, 'ajax_regenerate_transcripts']);
        
        // Menu admin
        add_action('admin_menu', [__CLASS__, 'add_admin_menu'], 20);
        
        // Assets
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_assets']);
    }
    
    public static function add_admin_menu() {
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            'Bulk Tools',
            '🔧 Bulk Tools',
            'manage_options',
            'ipv-bulk-tools',
            [__CLASS__, 'render_admin_page']
        );
    }
    
    public static function enqueue_admin_assets($hook) {
        if ($hook !== 'ipv_video_page_ipv-bulk-tools') return;
        
        wp_enqueue_style('ipv-bulk-tools', IPV_PLUGIN_URL . 'assets/bulk-import.css', [], IPV_VSP_VER);
        wp_enqueue_script('ipv-bulk-tools', IPV_PLUGIN_URL . 'assets/bulk-import.js', ['jquery'], IPV_VSP_VER, true);
        
        wp_localize_script('ipv-bulk-tools', 'IPV_BULK', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ipv_bulk'),
        ]);
    }
    
    public static function render_admin_page() {
        ?>
        <div class="wrap">
            <h1>🔧 Bulk Tools - Video Import & Manutenzione</h1>
            
            <div class="ipv-bulk-container">
                
                <!-- IMPORT MASSIVO -->
                <div class="ipv-bulk-card">
                    <h2>📥 Import Video da YouTube</h2>
                    <p>Inserisci video IDs YouTube (1 per riga)</p>
                    
                    <form id="bulk-import-form">
                        <textarea id="video_ids" rows="15" placeholder="dQw4w9WgXcQ&#10;J7p4bzqLvCw&#10;kJQP7kiw5Fk" style="width: 100%; font-family: monospace;"></textarea>
                        
                        <p>
                            <label>
                                <input type="checkbox" id="auto_transcripts" value="1">
                                Auto-fetch trascrizioni SupaData
                            </label>
                        </p>
                        
                        <button type="submit" class="button button-primary button-large">
                            📥 Importa Video
                        </button>
                    </form>
                </div>
                
                <!-- RIGENERA THUMBS -->
                <div class="ipv-bulk-card">
                    <h2>🖼️ Rigenera Thumbnail</h2>
                    <p>Scarica nuovamente le thumbnail da YouTube per tutti i video</p>
                    
                    <form id="regenerate-thumbs-form">
                        <p>
                            <label>
                                <input type="radio" name="thumb_filter" value="all" checked>
                                Tutti i video
                            </label>
                            <br>
                            <label>
                                <input type="radio" name="thumb_filter" value="missing">
                                Solo video senza thumbnail
                            </label>
                        </p>
                        
                        <button type="submit" class="button button-secondary button-large">
                            🖼️ Rigenera Thumbnail
                        </button>
                    </form>
                </div>
                
                <!-- RIGENERA TRASCRIZIONI -->
                <div class="ipv-bulk-card">
                    <h2>📝 Rigenera Trascrizioni</h2>
                    <p>Scarica trascrizioni SupaData per tutti i video</p>
                    
                    <form id="regenerate-transcripts-form">
                        <p>
                            <label>
                                <input type="radio" name="transcript_filter" value="all" checked>
                                Tutti i video
                            </label>
                            <br>
                            <label>
                                <input type="radio" name="transcript_filter" value="missing">
                                Solo video senza trascrizione
                            </label>
                        </p>
                        
                        <button type="submit" class="button button-secondary button-large">
                            📝 Rigenera Trascrizioni
                        </button>
                    </form>
                </div>
                
            </div>
            
            <!-- PROGRESS -->
            <div id="bulk-progress" style="display: none; margin-top: 30px; padding: 20px; background: white; border: 1px solid #ccc;">
                <h3 id="progress-title">Elaborazione in corso...</h3>
                <div style="background: #f0f0f0; height: 30px; border-radius: 5px; overflow: hidden; margin: 15px 0;">
                    <div id="progress-bar" style="background: #2271b1; height: 100%; width: 0%; transition: width 0.3s;"></div>
                </div>
                <p id="progress-text">0 / 0</p>
                <div id="progress-log" style="max-height: 300px; overflow-y: auto; background: #f9f9f9; padding: 10px; font-family: monospace; font-size: 12px;"></div>
            </div>
        </div>
        
        <style>
        .ipv-bulk-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .ipv-bulk-card {
            background: white;
            border: 1px solid #ccd0d4;
            padding: 20px;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .ipv-bulk-card h2 {
            margin-top: 0;
            font-size: 18px;
        }
        .ipv-bulk-card textarea {
            border: 1px solid #8c8f94;
            padding: 10px;
            font-size: 13px;
        }
        .ipv-bulk-card button {
            margin-top: 10px;
        }
        </style>
        <?php
    }
    
    /**
     * AJAX: Import video da IDs
     */
    public static function ajax_import_ids() {
        check_ajax_referer('ipv_bulk', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permessi insufficienti']);
        }
        
        $ids_input = sanitize_textarea_field($_POST['video_ids'] ?? '');
        $auto_transcripts = isset($_POST['auto_transcripts']) && $_POST['auto_transcripts'] === '1';
        
        if (empty($ids_input)) {
            wp_send_json_error(['message' => 'Inserisci almeno un video ID']);
        }
        
        $settings = IPV_Settings::get();
        $api_key = $settings['youtube_api_key'] ?? '';
        
        if (empty($api_key)) {
            wp_send_json_error(['message' => 'YouTube API Key non configurata']);
        }
        
        // Estrai IDs
        $video_ids = self::extract_video_ids($ids_input);
        
        if (empty($video_ids)) {
            wp_send_json_error(['message' => 'Nessun video ID valido trovato']);
        }
        
        // Fetch video details
        $videos = self::fetch_videos_by_ids($video_ids, $api_key);
        
        if (empty($videos)) {
            wp_send_json_error(['message' => 'Impossibile recuperare dettagli video']);
        }
        
        // Import
        $result = self::import_videos($videos, $auto_transcripts);
        
        wp_send_json_success($result);
    }
    
    /**
     * AJAX: Rigenera thumbnails
     */
    public static function ajax_regenerate_thumbs() {
        check_ajax_referer('ipv_bulk', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permessi insufficienti']);
        }
        
        $filter = sanitize_text_field($_POST['filter'] ?? 'all');
        
        $args = [
            'post_type' => 'ipv_video',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ];
        
        // Filtro solo video senza thumbnail
        if ($filter === 'missing') {
            $args['meta_query'] = [
                [
                    'key' => '_thumbnail_id',
                    'compare' => 'NOT EXISTS'
                ]
            ];
        }
        
        $video_ids = get_posts($args);
        
        if (empty($video_ids)) {
            wp_send_json_error(['message' => 'Nessun video trovato']);
        }
        
        $success = 0;
        $failed = 0;
        $log = [];
        
        foreach ($video_ids as $post_id) {
            $youtube_id = get_post_meta($post_id, '_ipv_youtube_id', true);
            
            if (!$youtube_id) {
                $failed++;
                $log[] = "Post $post_id: YouTube ID mancante";
                continue;
            }
            
            $result = IPV_Tools::download_youtube_thumbnail($youtube_id, $post_id);
            
            if ($result) {
                $success++;
                $log[] = "✓ Post $post_id: Thumbnail scaricata";
            } else {
                $failed++;
                $log[] = "✗ Post $post_id: Errore download";
            }
        }
        
        wp_send_json_success([
            'total' => count($video_ids),
            'success' => $success,
            'failed' => $failed,
            'log' => $log
        ]);
    }
    
    /**
     * AJAX: Rigenera trascrizioni
     */
    public static function ajax_regenerate_transcripts() {
        check_ajax_referer('ipv_bulk', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permessi insufficienti']);
        }
        
        $filter = sanitize_text_field($_POST['filter'] ?? 'all');
        
        $args = [
            'post_type' => 'ipv_video',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ];
        
        // Filtro solo video senza trascrizione
        if ($filter === 'missing') {
            $args['meta_query'] = [
                [
                    'key' => '_ipv_transcript',
                    'compare' => 'NOT EXISTS'
                ]
            ];
        }
        
        $video_ids = get_posts($args);
        
        if (empty($video_ids)) {
            wp_send_json_error(['message' => 'Nessun video trovato']);
        }
        
        // Verifica SupaData configurato
        if (!class_exists('IPV_SupaData')) {
            wp_send_json_error(['message' => 'SupaData non disponibile']);
        }
        
        $settings = IPV_Settings::get();
        if (empty($settings['supadata_key'])) {
            wp_send_json_error(['message' => 'SupaData API Key non configurata']);
        }
        
        $success = 0;
        $failed = 0;
        $log = [];
        
        foreach ($video_ids as $post_id) {
            $youtube_id = get_post_meta($post_id, '_ipv_youtube_id', true);
            
            if (!$youtube_id) {
                $failed++;
                $log[] = "Post $post_id: YouTube ID mancante";
                continue;
            }
            
            try {
                $result = IPV_SupaData::fetch_transcript($youtube_id, $post_id);
                
                if ($result && isset($result['content'])) {
                    $success++;
                    $log[] = "✓ Post $post_id: Trascrizione ottenuta";
                } else {
                    $failed++;
                    $log[] = "✗ Post $post_id: Nessuna trascrizione disponibile";
                }
            } catch (Exception $e) {
                $failed++;
                $log[] = "✗ Post $post_id: " . $e->getMessage();
            }
        }
        
        wp_send_json_success([
            'total' => count($video_ids),
            'success' => $success,
            'failed' => $failed,
            'log' => $log
        ]);
    }
    
    // ============================================
    // HELPER METHODS
    // ============================================
    
    protected static function extract_video_ids($input) {
        $lines = explode("\n", $input);
        $ids = [];
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            
            // Valida formato YouTube ID (11 caratteri)
            if (preg_match('/^[a-zA-Z0-9_-]{11}$/', $line)) {
                $ids[] = $line;
            }
        }
        
        return array_unique($ids);
    }
    
    public static function fetch_videos_by_ids($video_ids, $api_key) {
        $videos = [];
        $chunks = array_chunk($video_ids, 50);
        
        foreach ($chunks as $chunk) {
            $url = 'https://www.googleapis.com/youtube/v3/videos?' . http_build_query([
                'part' => 'snippet,contentDetails,statistics',
                'id' => implode(',', $chunk),
                'key' => $api_key
            ]);
            
            $response = wp_remote_get($url, ['timeout' => 30]);
            
            if (is_wp_error($response)) continue;
            
            $body = json_decode(wp_remote_retrieve_body($response), true);
            
            if (empty($body['items'])) continue;
            
            foreach ($body['items'] as $item) {
                $videos[] = [
                    'id' => $item['id'],
                    'title' => $item['snippet']['title'] ?? '',
                    'description' => $item['snippet']['description'] ?? '',
                    'published_at' => $item['snippet']['publishedAt'] ?? '',
                    'duration' => $item['contentDetails']['duration'] ?? 'PT0S',
                    'thumbnail_url' => $item['snippet']['thumbnails']['high']['url'] ?? '',
                    'view_count' => $item['statistics']['viewCount'] ?? 0,
                ];
            }
        }
        
        return $videos;
    }
    
    public static function import_videos($videos, $auto_transcripts = false) {
        $imported = 0;
        $skipped = 0;
        $log = [];
        
        foreach ($videos as $video) {
            $video_id = $video['id'];
            
            // Check se esiste
            $existing = get_posts([
                'post_type' => 'ipv_video',
                'meta_key' => '_ipv_youtube_id',
                'meta_value' => $video_id,
                'posts_per_page' => 1,
                'post_status' => 'any'
            ]);
            
            if ($existing) {
                $skipped++;
                $log[] = "$video_id: Già esistente (skip)";
                continue;
            }
            
            // Crea post
            $post_id = wp_insert_post([
                'post_type' => 'ipv_video',
                'post_status' => 'publish',
                'post_title' => $video['title'],
                'post_content' => '[embed]https://www.youtube.com/watch?v=' . $video_id . '[/embed]',
                'post_date' => gmdate('Y-m-d H:i:s', strtotime($video['published_at']))
            ]);
            
            if (is_wp_error($post_id)) {
                $log[] = "$video_id: Errore creazione";
                continue;
            }
            
            // Meta
            update_post_meta($post_id, '_ipv_youtube_id', $video_id);
            update_post_meta($post_id, '_ipv_youtube_url', 'https://www.youtube.com/watch?v=' . $video_id);
            update_post_meta($post_id, '_ipv_duration', $video['duration']);
            update_post_meta($post_id, '_ipv_published_at', $video['published_at']);
            update_post_meta($post_id, '_ipv_view_count', $video['view_count']);
            
            // Thumbnail
            IPV_Tools::download_youtube_thumbnail($video_id, $post_id);
            
            // Trascrizione
            if ($auto_transcripts && class_exists('IPV_SupaData')) {
                try {
                    IPV_SupaData::fetch_transcript($video_id, $post_id);
                    
                    // NUOVO: Genera automaticamente i campi con OpenAI dopo aver scaricato il transcript
                    if (class_exists('IPV_Fields')) {
                        $settings = IPV_Settings::get();
                        // Controlla se la generazione automatica è abilitata e se la chiave OpenAI è configurata
                        $auto_generate = isset($settings['openai_auto_generate']) ? $settings['openai_auto_generate'] : true;
                        $has_openai_key = !empty($settings['openai_api_key']);
                        
                        if ($auto_generate && $has_openai_key) {
                            IPV_Logger::info("Generazione automatica campi OpenAI per video_id: $video_id, post_id: $post_id");
                            $generated = IPV_Fields::generate_for_post($post_id);
                            if ($generated) {
                                $log[] = "$video_id: Importato + Trascrizione + AI Generato ✓✓";
                            } else {
                                $log[] = "$video_id: Importato + Trascrizione ✓ (AI fallito)";
                            }
                        } else {
                            $log[] = "$video_id: Importato + Trascrizione ✓ (AI disabilitato)";
                        }
                    } else {
                        $log[] = "$video_id: Importato + Trascrizione ✓";
                    }
                } catch (Exception $e) {
                    // Silent fail
                    $log[] = "$video_id: Importato ✓ (Trascrizione fallita)";
                }
            } else {
                $imported++;
                $log[] = "$video_id: Importato ✓";
            }
            
            if (!isset($imported) || !is_int($imported)) {
                $imported = 0;
            }
            $imported++;
        }
        
        return [
            'total' => count($videos),
            'imported' => $imported,
            'skipped' => $skipped,
            'log' => $log
        ];
    }
}
