<?php
/**
 * Analytics Class
 * Gestisce le statistiche e analytics
 */

if (!defined('ABSPATH')) exit;

class IPV_Analytics {
    
    /**
     * Get dashboard data
     */
    public static function get_dashboard_data() {
        return [
            'videos' => self::get_video_stats(),
            'imports' => self::get_import_stats(),
            'storage' => self::get_storage_stats(),
            'activity' => self::get_recent_activity()
        ];
    }
    
    /**
     * Get video statistics
     */
    public static function get_video_stats() {
        $args = [
            'post_type' => 'video',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ];
        
        $videos = new \WP_Query($args);
        $total = $videos->found_posts;
        
        // Count by status
        $published = new \WP_Query([
            'post_type' => 'video',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ]);
        
        $draft = new \WP_Query([
            'post_type' => 'video',
            'post_status' => 'draft',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ]);
        
        // Get recent (last 7 days)
        $recent = new \WP_Query([
            'post_type' => 'video',
            'post_status' => 'any',
            'date_query' => [
                [
                    'after' => '7 days ago'
                ]
            ],
            'posts_per_page' => -1,
            'fields' => 'ids'
        ]);
        
        return [
            'total' => $total,
            'published' => $published->found_posts,
            'draft' => $draft->found_posts,
            'recent' => $recent->found_posts
        ];
    }
    
    /**
     * Get import statistics
     */
    public static function get_import_stats() {
        global $wpdb;
        $table = $wpdb->prefix . 'ipv_logs';
        
        // Total imports
        $total = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE message LIKE '%import%' AND level = 'success'"
        );
        
        // Imports today
        $today = date('Y-m-d');
        $today_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE message LIKE '%import%' AND level = 'success' AND DATE(timestamp) = %s",
                $today
            )
        );
        
        // Imports this week
        $week_ago = date('Y-m-d', strtotime('-7 days'));
        $week_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE message LIKE '%import%' AND level = 'success' AND DATE(timestamp) >= %s",
                $week_ago
            )
        );
        
        // Failed imports
        $failed = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE message LIKE '%import%' AND level = 'error'"
        );
        
        return [
            'total' => intval($total),
            'today' => intval($today_count),
            'week' => intval($week_count),
            'failed' => intval($failed)
        ];
    }
    
    /**
     * Get storage statistics
     */
    public static function get_storage_stats() {
        $upload = wp_upload_dir();
        $base_dir = $upload['basedir'];
        
        $json_dir = trailingslashit($base_dir) . 'ipv-video-json/';
        $log_dir = trailingslashit($base_dir) . 'ipv-video-logs/';
        
        $json_size = self::get_directory_size($json_dir);
        $log_size = self::get_directory_size($log_dir);
        
        $json_count = 0;
        if (file_exists($json_dir)) {
            $json_count = count(glob($json_dir . '*.json'));
        }
        
        return [
            'json_files' => $json_count,
            'json_size' => $json_size,
            'json_size_formatted' => size_format($json_size),
            'log_size' => $log_size,
            'log_size_formatted' => size_format($log_size),
            'total_size' => $json_size + $log_size,
            'total_size_formatted' => size_format($json_size + $log_size)
        ];
    }
    
    /**
     * Get recent activity
     */
    public static function get_recent_activity($limit = 10) {
        global $wpdb;
        $table = $wpdb->prefix . 'ipv_logs';
        
        $logs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} ORDER BY timestamp DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
        
        return $logs;
    }
    
    /**
     * Calculate directory size
     */
    private static function get_directory_size($directory) {
        if (!file_exists($directory)) {
            return 0;
        }
        
        $size = 0;
        $files = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($directory, \RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($files as $file) {
            $size += $file->getSize();
        }
        
        return $size;
    }
    
    /**
     * Get video distribution by date
     */
    public static function get_video_distribution($days = 30) {
        global $wpdb;
        
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(post_date) as date, COUNT(*) as count 
                FROM {$wpdb->posts} 
                WHERE post_type = 'video' 
                AND post_date >= DATE_SUB(NOW(), INTERVAL %d DAY)
                GROUP BY DATE(post_date)
                ORDER BY date ASC",
                $days
            ),
            ARRAY_A
        );
        
        return $results;
    }
    
    /**
     * Get top categories
     */
    public static function get_top_categories($limit = 10) {
        $terms = get_terms([
            'taxonomy' => 'video_category',
            'orderby' => 'count',
            'order' => 'DESC',
            'number' => $limit,
            'hide_empty' => true
        ]);
        
        if (is_wp_error($terms)) {
            return [];
        }
        
        return array_map(function($term) {
            return [
                'name' => $term->name,
                'count' => $term->count,
                'slug' => $term->slug
            ];
        }, $terms);
    }
}