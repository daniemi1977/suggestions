<?php
if (!defined('ABSPATH')) exit;
add_action('admin_menu', function () {
    if (!post_type_exists('ipv_video')) { return; }
    add_menu_page(
        __('IPV Video','ipv'),
        __('IPV Video','ipv'),
        'edit_posts',
        'edit.php?post_type=ipv_video',
        '',
        'dashicons-video-alt2',
        25
    );
    add_submenu_page(
        'edit.php?post_type=ipv_video',
        __('Tutti i Video','ipv'),
        __('Tutti i Video','ipv'),
        'edit_posts',
        'edit.php?post_type=ipv_video'
    );
    add_submenu_page(
        'edit.php?post_type=ipv_video',
        __('Aggiungi nuovo','ipv'),
        __('Aggiungi nuovo','ipv'),
        'edit_posts',
        'post-new.php?post_type=ipv_video'
    );
    
    // HOTFIX: Aggiungo menu Impostazioni direttamente qui
    // perché IPV_Settings::menu() non appare per qualche motivo
    if (current_user_can('manage_options')) {
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            __('Impostazioni IPV Video', 'ipv'),
            __('⚙️ Impostazioni', 'ipv'),
            'manage_options',
            'ipv-settings',
            function() {
                if (class_exists('IPV_Settings') && method_exists('IPV_Settings', 'render_page')) {
                    IPV_Settings::render_page();
                } else {
                    echo '<div class="wrap"><h1>Errore</h1><p>Classe IPV_Settings non trovata!</p></div>';
                }
            }
        );
    }
}, 99);
