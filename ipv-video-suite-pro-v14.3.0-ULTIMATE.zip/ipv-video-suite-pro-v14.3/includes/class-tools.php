<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_Tools')){
class IPV_Tools {
    public static function init(){
        add_action('add_meta_boxes', array(__CLASS__,'add_tools_metabox'), 12);
        add_action('admin_post_ipv_tool_thumb', array(__CLASS__,'handle_thumb'));
        add_action('admin_post_ipv_tool_transcript', array(__CLASS__,'handle_transcript'));
        add_action('admin_post_ipv_tool_regen_ai', array(__CLASS__,'handle_regen_ai'));
        add_action('admin_post_ipv_tool_clear_ai', array(__CLASS__,'handle_clear_ai'));
    }
    public static function add_tools_metabox(){
        add_meta_box('ipv_tools','IPV Tools & Utility', array(__CLASS__,'render_tools'), 'ipv_video', 'side', 'default');
    }
    public static function render_tools($post){
        $thumb = wp_nonce_url(admin_url('admin-post.php?action=ipv_tool_thumb&post_id='.$post->ID),'ipv_tool_thumb');
        $trans = wp_nonce_url(admin_url('admin-post.php?action=ipv_tool_transcript&post_id='.$post->ID),'ipv_tool_transcript');
        $regen = wp_nonce_url(admin_url('admin-post.php?action=ipv_tool_regen_ai&post_id='.$post->ID),'ipv_tool_regen_ai');
        $clear = wp_nonce_url(admin_url('admin-post.php?action=ipv_tool_clear_ai&post_id='.$post->ID),'ipv_tool_clear_ai');
        echo '<p><a class="button" href="'.esc_url($thumb).'">Rigenera Thumbnail (YouTube)</a></p>';
        echo '<p><a class="button" href="'.esc_url($trans).'">Ricarica Trascrizione (SupaData)</a></p>';
        echo '<p><a class="button" href="'.esc_url($regen).'">Rigenera Testi (AI)</a></p>';
        echo '<p><a class="button" href="'.esc_url($clear).'">Svuota Dati AI</a></p>';
    }
    protected static function youtube_id_from_post($post_id){
        $yid=get_post_meta($post_id,'_ipv_youtube_id',true);
        if(!$yid){ $url=get_post_meta($post_id,'_ipv_youtube_url',true); if($url&&preg_match('~v=([A-Za-z0-9_-]{11})~',$url,$m)) $yid=$m[1]; }
        return $yid;
    }
    public static function handle_thumb(){
        if(!current_user_can('edit_posts')) wp_die('Not allowed');
        if(empty($_GET['post_id'])) wp_die('Missing post_id'); check_admin_referer('ipv_tool_thumb');
        $post_id=absint($_GET['post_id']); $yid=self::youtube_id_from_post($post_id);
        if($yid){ self::download_youtube_thumbnail($yid,$post_id); } wp_safe_redirect(get_edit_post_link($post_id,'')); exit;
    }
    public static function handle_transcript(){
        if(!current_user_can('edit_posts')) wp_die('Not allowed');
        if(empty($_GET['post_id'])) wp_die('Missing post_id'); check_admin_referer('ipv_tool_transcript');
        $post_id=absint($_GET['post_id']); $yid=self::youtube_id_from_post($post_id);
        if($yid && class_exists('IPV_SupaData')){ $st=get_option('ipv_settings',array()); $lang=!empty($st['supadata_lang'])?$st['supadata_lang']:'it'; IPV_SupaData::fetch_transcript($yid,$post_id,array('lang'=>$lang,'save'=>true)); }
        wp_safe_redirect(get_edit_post_link($post_id,'')); exit;
    }
    public static function handle_regen_ai(){
        if(!current_user_can('edit_posts')) wp_die('Not allowed');
        if(empty($_GET['post_id'])) wp_die('Missing post_id'); check_admin_referer('ipv_tool_regen_ai');
        $post_id=absint($_GET['post_id']); if(class_exists('IPV_Fields')) IPV_Fields::generate_for_post($post_id); wp_safe_redirect(get_edit_post_link($post_id,'')); exit;
    }
    public static function handle_clear_ai(){
        if(!current_user_can('edit_posts')) wp_die('Not allowed');
        if(empty($_GET['post_id'])) wp_die('Missing post_id'); check_admin_referer('ipv_tool_clear_ai');
        $post_id=absint($_GET['post_id']); foreach(array('_ipv_ai_raw_content','_ipv_ai_status') as $k) delete_post_meta($post_id,$k); wp_safe_redirect(get_edit_post_link($post_id,'')); exit;
    }
    public static function download_youtube_thumbnail($yid,$post_id){
        $cands=array(
            'https://i.ytimg.com/vi/'.$yid.'/maxresdefault.jpg',
            'https://i.ytimg.com/vi/'.$yid.'/sddefault.jpg',
            'https://i.ytimg.com/vi/'.$yid.'/hqdefault.jpg'
        );
        foreach($cands as $u){
            $tmp=download_url($u);
            if(is_wp_error($tmp)) continue;
            $file=array('name'=>basename($u),'tmp_name'=>$tmp);
            $id=media_handle_sideload($file,$post_id,'YouTube thumbnail '.$yid);
            if(!is_wp_error($id)){ set_post_thumbnail($post_id,$id); return $id; }
            @unlink($tmp);
        }
        return 0;
    }
}}
