<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_Elementor_Wall_Widget')):
class IPV_Elementor_Wall_Widget extends \Elementor\Widget_Base {
    public function get_name(){ return 'ipv_wall'; }
    public function get_title(){ return 'IPV Wall'; }
    public function get_icon(){ return 'eicon-posts-grid'; }
    public function get_categories(){ return ['general']; }
    protected function _register_controls(){
        $this->start_controls_section('content', ['label'=>'Contenuto']);
        $this->add_control('per_page', ['label'=>'Per page','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>5]);
        $this->add_control('only_horizontal', ['label'=>'Solo orizzontali','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();
    }
    protected function render(){
        $settings = $this->get_settings_for_display();
        echo do_shortcode('[ipv_wall per_page="'.intval($settings['per_page']).'" only_horizontal="'.($settings['only_horizontal']=='yes'?'1':'0').'"]');
    }
}
endif;
