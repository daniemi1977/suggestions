<?php

if (!defined('ABSPATH')) exit;

/**
 * Frontend Video Wall - Griglia stile Google Podcasts
 */
class IPV_Frontend_Wall {
    
    public static function init() {
        add_shortcode('ipv_video_wall', [__CLASS__, 'shortcode']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('wp_ajax_ipv_load_more_videos', [__CLASS__, 'ajax_load_more']);
        add_action('wp_ajax_nopriv_ipv_load_more_videos', [__CLASS__, 'ajax_load_more']);
    }
    
    /**
     * Enqueue frontend assets
     */
    public static function enqueue_assets() {
        if (self::should_load_assets()) {
            wp_enqueue_style(
                'ipvcpt-wall',
                IPV_PLUGIN_URL . 'assets/wall.css',
                [],
                IPVCPT_VERSION
            );
            
            wp_enqueue_script(
                'ipvcpt-wall',
                IPV_PLUGIN_URL . 'assets/wall.js',
                ['jquery'],
                IPVCPT_VERSION,
                true
            );
            
            wp_localize_script('ipvcpt-wall', 'IPVCPTWall', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('ipvcpt_wall_nonce')
            ]);
        }
    }
    
    /**
     * Check if we should load assets
     */
    protected static function should_load_assets() {
        global $post;
        
        // Load on home
        if (is_front_page() || is_home()) {
            return true;
        }
        
        // Load if shortcode present
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'ipv_video_wall')) {
            return true;
        }
        
        // Load on archive
        if (is_post_type_archive(IPVCPT_CPT) || is_singular(IPVCPT_CPT)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Shortcode handler
     * 
     * Usage: [ipv_video_wall columns="3" limit="12" layout="grid"]
     */
    public static function shortcode($atts) {
        $atts = shortcode_atts([
            'columns'     => 3,
            'limit'       => 12,
            'layout'      => 'grid', // grid, masonry
            'show_logo'   => true,
            'show_handle' => true,
            'orderby'     => 'date',
            'order'       => 'DESC',
            'category'    => '', // future: filter by category
            'load_more'   => true
        ], $atts);
        
        $query_args = [
            'post_type'      => IPVCPT_CPT,
            'posts_per_page' => intval($atts['limit']),
            'post_status'    => 'publish',
            'orderby'        => $atts['orderby'],
            'order'          => $atts['order'],
            'meta_query'     => [
                [
                    'key'     => 'ipv_is_stream',
                    'value'   => '1',
                    'compare' => '='
                ]
            ]
        ];
        
        $query = new \WP_Query($query_args);
        
        ob_start();
        
        if ($query->have_posts()) {
            $columns_class = 'ipv-wall-cols-' . intval($atts['columns']);
            $layout_class = 'ipv-wall-layout-' . esc_attr($atts['layout']);
            
            echo '<div class="ipv-video-wall ' . $columns_class . ' ' . $layout_class . '" data-columns="' . esc_attr($atts['columns']) . '">';
            
            while ($query->have_posts()) {
                $query->the_post();
                self::render_video_card(get_the_ID(), $atts);
            }
            
            echo '</div>';
            
            // Load More button
            if ($atts['load_more'] && $query->max_num_pages > 1) {
                echo '<div class="ipv-load-more-wrapper">';
                echo '<button class="ipv-load-more-btn" data-page="1" data-max-pages="' . $query->max_num_pages . '" data-atts="' . esc_attr(json_encode($atts)) . '">';
                echo 'Carica altri video';
                echo '</button>';
                echo '</div>';
            }
            
            wp_reset_postdata();
        } else {
            echo '<p class="ipv-no-videos">Nessun video disponibile al momento.</p>';
        }
        
        return ob_get_clean();
    }
    
    /**
     * Render single video card
     */
    protected static function render_video_card($post_id, $atts) {
        $video_id = get_post_meta($post_id, 'ipv_video_id', true);
        $video_url = get_post_meta($post_id, 'ipv_video_url', true);
        $thumb_url = get_post_meta($post_id, 'ipv_thumb_url', true);
        $source = get_post_meta($post_id, 'ipv_source', true);
        $title = get_the_title($post_id);
        $permalink = get_permalink($post_id);
        
        // Fallback thumbnail
        if (!$thumb_url && has_post_thumbnail($post_id)) {
            $thumb_url = get_the_post_thumbnail_url($post_id, 'large');
        }
        
        if (!$thumb_url) {
            $thumb_url = IPV_PLUGIN_URL . 'assets/placeholder.jpg';
        }
        
        // Handle/username
        $handle = $source ? $source : '@ilpuntodivista';
        
        ?>
        <div class="ipv-video-card" data-video-id="<?php echo esc_attr($video_id); ?>">
            <a href="<?php echo esc_url($permalink); ?>" class="ipv-video-link">
                
                <!-- Thumbnail Background -->
                <div class="ipv-video-thumb" style="background-image: url('<?php echo esc_url($thumb_url); ?>');">
                    
                    <!-- Dark Overlay -->
                    <div class="ipv-video-overlay"></div>
                    
                    <!-- Logo Top Left -->
                    <?php if ($atts['show_logo']): ?>
                    <div class="ipv-video-logo">
                        <img src="<?php echo esc_url(IPV_PLUGIN_URL . 'assets/logo-icon.png'); ?>" alt="IPV" />
                    </div>
                    <?php endif; ?>
                    
                    <!-- Play Button -->
                    <div class="ipv-video-play">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M8 5v14l11-7z"/>
                        </svg>
                    </div>
                    
                    <!-- Title Overlay -->
                    <div class="ipv-video-info">
                        <h3 class="ipv-video-title"><?php echo esc_html($title); ?></h3>
                        
                        <?php if ($atts['show_handle']): ?>
                        <div class="ipv-video-handle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                            </svg>
                            <?php echo esc_html($handle); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                </div>
            </a>
        </div>
        <?php
    }
    
    /**
     * AJAX Load More
     */
    public static function ajax_load_more() {
        check_ajax_referer('ipvcpt_wall_nonce', 'nonce');
        
        $page = intval($_POST['page'] ?? 1);
        $atts = json_decode(stripslashes($_POST['atts'] ?? '{}'), true);
        
        $query_args = [
            'post_type'      => IPVCPT_CPT,
            'posts_per_page' => intval($atts['limit'] ?? 12),
            'post_status'    => 'publish',
            'orderby'        => $atts['orderby'] ?? 'date',
            'order'          => $atts['order'] ?? 'DESC',
            'paged'          => $page + 1,
            'meta_query'     => [
                [
                    'key'     => 'ipv_is_stream',
                    'value'   => '1',
                    'compare' => '='
                ]
            ]
        ];
        
        $query = new \WP_Query($query_args);
        
        ob_start();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                self::render_video_card(get_the_ID(), $atts);
            }
        }
        
        $html = ob_get_clean();
        
        wp_send_json_success([
            'html'      => $html,
            'page'      => $page + 1,
            'has_more'  => $query->max_num_pages > ($page + 1)
        ]);
    }
}