<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_Settings')) {
class IPV_Settings {
    public static function init(){ 
        add_action('admin_init', [__CLASS__, 'register']); 
        add_action('admin_menu', [__CLASS__, 'menu'], 999); // Priorità alta per evitare rimozione
    }
    
    public static function menu(){
        // Forza la creazione del menu con priorità alta
        $page = add_submenu_page(
            'edit.php?post_type=ipv_video',
            __('Impostazioni IPV Video', 'ipv'),
            __('⚙️ Impostazioni', 'ipv'),
            'manage_options',
            'ipv-settings',
            [__CLASS__, 'render_page']
        );
        
        // Debug log per verificare se viene chiamato
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('IPV_Settings::menu() chiamato - Menu aggiunto: ' . ($page ? 'SI' : 'NO'));
        }
        
        return $page;
    }
    
    public static function render_page(){
        if (!current_user_can('manage_options')) wp_die('Non autorizzato');
        
        echo '<div class="wrap">';
        echo '<h1>🎬 Impostazioni IPV Video Suite Pro</h1>';
        
        // Status check
        $opts = self::get();
        $has_youtube = !empty($opts['youtube_api_key']);
        $has_supadata = !empty($opts['supadata_key']);
        $has_openai = !empty($opts['openai_api_key']);
        
        echo '<div style="background:#fff;border:1px solid #ccc;padding:15px;margin:20px 0;border-radius:5px;">';
        echo '<h3>📊 Stato Configurazione</h3>';
        echo '<p>'.($has_youtube ? '✅' : '❌').' YouTube API</p>';
        echo '<p>'.($has_supadata ? '✅' : '❌').' SupaData API (Trascrizioni)</p>';
        echo '<p>'.($has_openai ? '✅' : '❌').' OpenAI API (Generazione Automatica)</p>';
        if(!$has_openai) echo '<p style="color:red;font-weight:bold;">⚠️ IMPORTANTE: Configura OpenAI API Key per abilitare la generazione automatica delle descrizioni!</p>';
        echo '</div>';
        
        echo '<form method="post" action="options.php">';
        settings_fields('ipv_settings_group');
        do_settings_sections('ipv_settings');
        submit_button();
        echo '</form>';
        echo '</div>';
    }
    
    public static function get(){
        $defaults = [
            'youtube_api_key' => '',
            'youtube_channel_handle' => '@ilpuntodivista',
            'only_horizontal' => '0',
            'per_page' => '5',
            'supadata_base' => 'https://api.supadata.ai/v1',
            'supadata_key' => '',
            'openai_api_key' => '',
            'openai_model' => 'gpt-4o-mini',
        ];
        $opt = get_option('ipv_settings', []);
        $defaults['supadata_transcript_path'] = '/transcript';
        $defaults['supadata_timeout'] = '30';
        $defaults['wall_thumb_target'] = isset($defaults['wall_thumb_target']) ? $defaults['wall_thumb_target'] : 'youtube';
        return wp_parse_args($opt, $defaults);
    }
    public static function register(){
        register_setting('ipv_settings_group', 'ipv_settings');
        add_settings_section('ipv_main', __('Impostazioni generali', 'ipv'), function(){ echo '<p>Configura sorgenti YouTube e SupaData.</p>'; }, 'ipv_settings');
        add_settings_field('youtube_api_key','YouTube API Key',[__CLASS__,'field_text'],'ipv_settings','ipv_main',['key'=>'youtube_api_key']);
        add_settings_field('youtube_channel_handle','Canale/Handle',[__CLASS__,'field_text'],'ipv_settings','ipv_main',['key'=>'youtube_channel_handle']);
        add_settings_field('only_horizontal','Solo orizzontali',[__CLASS__,'field_checkbox'],'ipv_settings','ipv_main',['key'=>'only_horizontal']);
        add_settings_field('per_page','Per page (wall)',[__CLASS__,'field_number'],'ipv_settings','ipv_main',['key'=>'per_page']);
        add_settings_field('supadata_base','SupaData Base URL',[__CLASS__,'field_text'],'ipv_settings','ipv_main',['key'=>'supadata_base']);
        add_settings_field('supadata_transcript_path','SupaData Transcript Path',[__CLASS__,'field_text'],'ipv_settings','ipv_main',['key'=>'supadata_transcript_path']);
        add_settings_field('supadata_timeout','SupaData Timeout (s)',[__CLASS__,'field_number'],'ipv_settings','ipv_main',['key'=>'supadata_timeout']);
        add_settings_field('supadata_key','SupaData API Key',[__CLASS__,'field_text'],'ipv_settings','ipv_main',['key'=>'supadata_key']);
        
        // OpenAI Section
        add_settings_section('ipv_openai', __('🤖 OpenAI (Generazione Automatica)', 'ipv'), function(){ echo '<p>Configura OpenAI per generare automaticamente le descrizioni dei video.</p>'; }, 'ipv_settings');
        add_settings_field('openai_api_key','OpenAI API Key',[__CLASS__,'field_text'],'ipv_settings','ipv_openai',['key'=>'openai_api_key']);
        add_settings_field('openai_model','Modello OpenAI',[__CLASS__,'field_select_model'],'ipv_settings','ipv_openai',['key'=>'openai_model']);
    }
    public static function field_text($args){ $o=self::get(); $k=esc_attr($args['key']); printf('<input type="text" class="regular-text" name="ipv_settings[%1$s]" value="%2$s" />',$k, esc_attr($o[$k])); }
    public static function field_number($args){ $o=self::get(); $k=esc_attr($args['key']); printf('<input type="number" class="small-text" name="ipv_settings[%1$s]" value="%2$s" />',$k, esc_attr($o[$k])); }
    public static function field_checkbox($args){ $o=self::get(); $k=esc_attr($args['key']); printf('<label><input type="checkbox" name="ipv_settings[%1$s]" value="1" %2$s/> Attivo</label>',$k, checked($o[$k],'1',false)); }
    public static function field_select_model($args){
        $o = self::get();
        $k = esc_attr($args['key']);
        $current = $o[$k];
        $models = [
            'gpt-4o-mini' => 'GPT-4o Mini (Veloce ed economico - Consigliato)',
            'gpt-4o' => 'GPT-4o (Migliore qualità)',
            'gpt-4-turbo' => 'GPT-4 Turbo',
            'gpt-3.5-turbo' => 'GPT-3.5 Turbo (Economico)',
        ];
        echo '<select name="ipv_settings['.$k.']" class="regular-text">';
        foreach($models as $value => $label){
            printf('<option value="%s" %s>%s</option>', esc_attr($value), selected($current, $value, false), esc_html($label));
        }
        echo '</select>';
    }
}
}