<?php
/**
 * IPV AJAX Handler
 * Gestisce tutte le richieste AJAX dal pannello admin
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('IPV_AJAX')) {
class IPV_AJAX {
    
    public static function init() {
        add_action('ipv_run_import', [__CLASS__, 'run_import_job'], 10, 1);
        // Import actions
        add_action('wp_ajax_ipv_start_import', [__CLASS__, 'start_import']);
        add_action('wp_ajax_ipv_check_import_progress', [__CLASS__, 'check_import_progress']);
        add_action('wp_ajax_ipv_sync_channel', [__CLASS__, 'sync_channel']);
        
        // API Testing
        add_action('wp_ajax_ipv_test_all_apis', [__CLASS__, 'test_all_apis']);
        add_action('wp_ajax_ipv_test_youtube_api', [__CLASS__, 'test_youtube_api']);
        add_action('wp_ajax_ipv_test_supadata_api', [__CLASS__, 'test_supadata_api']);
        add_action('wp_ajax_ipv_test_ai_connection', [__CLASS__, 'test_ai_connection']);
        
        // Settings
        add_action('wp_ajax_ipv_save_transcript_settings', [__CLASS__, 'save_transcript_settings']);
        add_action('wp_ajax_ipv_save_scheduler', [__CLASS__, 'save_scheduler']);
        add_action('wp_ajax_ipv_get_next_scheduled_sync', [__CLASS__, 'get_next_scheduled_sync']);
    }
    
    /**
     * Verify AJAX nonce
     */
    private static function verify_nonce() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ipv_ajax')) {
            wp_send_json_error(['message' => 'Security check failed']);
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }
    }
    
    /**
     * Start Import
     */
    public static function start_import() {
        self::verify_nonce();
        
        try {
            // Crea un job ID univoco
            $job_id = uniqid('import_', true);
            
            // Inizializza il job
            set_transient('ipv_import_job_' . $job_id, [
                'status' => 'starting',
                'progress' => 0,
                'total' => 0,
                'imported' => 0,
                'skipped' => 0,
                'errors' => [],
                'start_time' => time()
            ], HOUR_IN_SECONDS);
            
            // Avvia import in background
            wp_schedule_single_event(time(), 'ipv_run_import', [$job_id]);
            
            // Forza l'esecuzione del cron
            spawn_cron();
            
            wp_send_json_success([
                'job_id' => $job_id,
                'message' => 'Import started'
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }
    
    /**
     * Check Import Progress
     */
    public static function check_import_progress() {
        self::verify_nonce();
        
        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        if (empty($job_id)) {
            wp_send_json_error(['message' => 'Invalid job ID']);
        }
        
        $job_data = get_transient('ipv_import_job_' . $job_id);
        
        if (!$job_data) {
            wp_send_json_error(['message' => 'Job not found']);
        }
        
        $progress = 0;
        if ($job_data['total'] > 0) {
            $progress = round(($job_data['imported'] + $job_data['skipped']) / $job_data['total'] * 100);
        }
        
        $status = sprintf(
            'Imported %d/%d videos (%d skipped)',
            $job_data['imported'],
            $job_data['total'],
            $job_data['skipped']
        );
        
        if ($progress >= 100) {
            $duration = human_time_diff($job_data['start_time'], time());
        }
        
        wp_send_json_success([
            'progress' => $progress,
            'status' => $status,
            'imported_count' => $job_data['imported'],
            'skipped_count' => $job_data['skipped'],
            'total_count' => $job_data['total'],
            'duration' => $duration ?? 'In progress...',
            'errors' => $job_data['errors']
        ]);
    }
    
    /**
     * Sync Channel
     */
    
public static function sync_channel() {
        self::verify_nonce();
        try {
            $settings = IPV_Settings::get();
            $api_key = $settings['youtube_api_key'] ?? '';
            if (empty($api_key)) {
                wp_send_json_error(['message' => 'YouTube API key not configured']);
            }
            $channel = isset($_POST['channel']) ? sanitize_text_field($_POST['channel']) : '';
            if (empty($channel)) { $channel = $settings['youtube_channel_handle'] ?? ''; }
            if (empty($channel)) {
                wp_send_json_error(['message' => 'Missing channel handle or ID']);
            }
            $max = isset($_POST['max_results']) ? max(1, intval($_POST['max_results'])) : 50;

            // Resolve channel ID
            $channel_id = self::resolve_channel_id($channel, $api_key);
            if (!$channel_id) {
                wp_send_json_error(['message' => 'Unable to resolve channel ID from: ' . $channel]);
            }

            // Fetch latest video IDs from channel (no filters)
            $video_ids = self::fetch_channel_video_ids($channel_id, $api_key, $max);
            if (empty($video_ids)) {
                wp_send_json_error(['message' => 'No videos found for channel']);
            }

            // Fetch full details
            if (!class_exists('IPV_Bulk_Importer')) {
                require_once IPV_PLUGIN_DIR . 'includes/class-bulk-importer.php';
            }
            $videos = IPV_Bulk_Importer::fetch_videos_by_ids($video_ids, $api_key);

            // Import (skip duplicates handled inside)
            $result = IPV_Bulk_Importer::import_videos($videos, false);

            wp_send_json_success([
                'message' => 'Sync completed',
                'result'  => $result,
                'channel_id' => $channel_id,
                'total_found' => count($video_ids)
            ]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    /**
     * Cron job runner for import
     */
    public static function run_import_job($job_id) {
        $job_key = 'ipv_import_job_' . $job_id;
        $job_data = get_transient($job_key);
        if (!$job_data) return;
        $settings = IPV_Settings::get();
        $api_key = $settings['youtube_api_key'] ?? '';
        $channel = $settings['youtube_channel_handle'] ?? '';
        $max = 50;
        // Prepare
        try {
            $channel_id = self::resolve_channel_id($channel, $api_key);
            if (!$channel_id) throw new Exception('Unable to resolve channel from settings');
            $video_ids = self::fetch_channel_video_ids($channel_id, $api_key, $max);
            if (!class_exists('IPV_Bulk_Importer')) {
                require_once IPV_PLUGIN_DIR . 'includes/class-bulk-importer.php';
            }
            // Update total
            $job_data['total'] = count($video_ids);
            set_transient($job_key, $job_data, HOUR_IN_SECONDS);

            $videos = IPV_Bulk_Importer::fetch_videos_by_ids($video_ids, $api_key);
            $result = IPV_Bulk_Importer::import_videos($videos, false);

            $job_data['status'] = 'completed';
            $job_data['imported'] = $result['imported'] ?? 0;
            $job_data['skipped']  = $result['skipped'] ?? 0;
            $job_data['duration'] = human_time_diff($job_data['start_time'], time());
            $job_data['results']  = $result;
            set_transient($job_key, $job_data, HOUR_IN_SECONDS);
        } catch (Exception $e) {
            $job_data['status'] = 'failed';
            $job_data['errors'][] = $e->getMessage();
            set_transient($job_key, $job_data, HOUR_IN_SECONDS);
        }
    }

    // === Helpers ===
    private static function resolve_channel_id($input, $api_key) {
        $input = trim($input);
        if (preg_match('/^UC[0-9A-Za-z_-]{22}$/', $input)) {
            return $input;
        }
        // Try forHandle if starts with @
        if (strpos($input, '@') === 0) {
            $url = add_query_arg([
                'part' => 'id',
                'forHandle' => $input,
                'key' => $api_key
            ], 'https://www.googleapis.com/youtube/v3/channels');
            $resp = wp_remote_get($url, ['timeout' => 20]);
            if (!is_wp_error($resp)) {
                $body = json_decode(wp_remote_retrieve_body($resp), true);
                if (!empty($body['items'][0]['id'])) {
                    return $body['items[0][id]'] ?? $body['items'][0]['id'];
                }
            }
        }
        // Fallback: search channel
        $url = add_query_arg([
            'part' => 'snippet',
            'q'    => $input,
            'type' => 'channel',
            'maxResults' => 1,
            'key'  => $api_key
        ], 'https://www.googleapis.com/youtube/v3/search');
        $resp = wp_remote_get($url, ['timeout' => 20]);
        if (!is_wp_error($resp)) {
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($body['items'][0]['id']['channelId'])) {
                return $body['items'][0]['id']['channelId'];
            }
        }
        return false;
    }

    private static function fetch_channel_video_ids($channel_id, $api_key, $max = 50) {
        $ids = [];
        $pageToken = '';
        while (count($ids) < $max) {
            $batch = min(50, $max - count($ids));
            $url = add_query_arg([
                'part' => 'id',
                'channelId' => $channel_id,
                'maxResults' => $batch,
                'order' => 'date',
                'type' => 'video',
                'pageToken' => $pageToken,
                'key' => $api_key
            ], 'https://www.googleapis.com/youtube/v3/search');
            $resp = wp_remote_get($url, ['timeout' => 20]);
            if (is_wp_error($resp)) break;
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($body['items'])) {
                foreach ($body['items'] as $it) {
                    if (!empty($it['id']['videoId'])) {
                        $ids[] = $it['id']['videoId'];
                    }
                }
            }
            if (!empty($body['nextPageToken'])) {
                $pageToken = $body['nextPageToken'];
            } else {
                break;
            }
        }
        return array_values(array_unique($ids));
    }

    /**
     * Test All APIs
     */
    public static function test_all_apis() {
        self::verify_nonce();
        
        $results = [];
        $all_passed = true;
        
        // Test YouTube API
        $yt_test = self::test_youtube_api_internal();
        $results['youtube'] = $yt_test;
        if (!$yt_test['success']) $all_passed = false;
        
        // Test SupaData API
        $sd_test = self::test_supadata_api_internal();
        $results['supadata'] = $sd_test;
        if (!$sd_test['success']) $all_passed = false;
        
        if ($all_passed) {
            wp_send_json_success([
                'message' => 'All APIs are working correctly',
                'details' => $results
            ]);
        } else {
            wp_send_json_error([
                'message' => 'Some APIs failed',
                'details' => $results
            ]);
        }
    }
    
    /**
     * Test YouTube API
     */
    public static function test_youtube_api() {
        self::verify_nonce();
        
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        
        if (empty($api_key)) {
            wp_send_json_error(['message' => 'API key is required']);
        }
        
        $result = self::test_youtube_api_internal($api_key);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * Test YouTube API (internal)
     */
    private static function test_youtube_api_internal($api_key = null) {
        $settings = IPV_Settings::get();
        $api_key = $api_key ?? $settings['youtube_api_key'];
        
        if (empty($api_key)) {
            return [
                'success' => false,
                'message' => 'YouTube API key not configured'
            ];
        }
        
        // Test API con una chiamata semplice
        $test_url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&id=dQw4w9WgXcQ&key=' . $api_key;
        
        $response = wp_remote_get($test_url, [
            'timeout' => 10
        ]);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => 'Connection error: ' . $response->get_error_message()
            ];
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code === 200 && isset($body['items'])) {
            // Incrementa contatore API calls
            self::increment_api_calls('youtube');
            
            return [
                'success' => true,
                'message' => 'YouTube API is working correctly',
                'details' => [
                    'quota_used' => $body['pageInfo']['totalResults'] ?? 0,
                    'response_time' => wp_remote_retrieve_header($response, 'x-response-time') ?? 'N/A'
                ]
            ];
        } else {
            return [
                'success' => false,
                'message' => 'API error: ' . ($body['error']['message'] ?? 'Unknown error'),
                'details' => $body
            ];
        }
    }
    
    /**
     * Test SupaData API
     */
    public static function test_supadata_api() {
        self::verify_nonce();
        
        $base_url = sanitize_text_field($_POST['base_url'] ?? '');
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        
        if (empty($base_url) || empty($api_key)) {
            wp_send_json_error(['message' => 'Base URL and API key are required']);
        }
        
        $result = self::test_supadata_api_internal($base_url, $api_key);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * Test SupaData API (internal)
     */
    private static function test_supadata_api_internal($base_url = null, $api_key = null) {
        $settings = IPV_Settings::get();
        $base_url = $base_url ?? $settings['supadata_base'];
        $api_key = $api_key ?? $settings['supadata_key'];
        
        if (empty($base_url) || empty($api_key)) {
            return [
                'success' => false,
                'message' => 'SupaData credentials not configured'
            ];
        }
        
        // Test con un video YouTube conosciuto
        $test_url = rtrim($base_url, '/') . '/transcript?url=https://www.youtube.com/watch?v=dQw4w9WgXcQ';
        
        $response = wp_remote_get($test_url, [
            'headers' => [
                'x-api-key' => $api_key,
                'Accept' => 'application/json'
            ],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => 'Connection error: ' . $response->get_error_message()
            ];
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code === 200 || $code === 202) {
            // Incrementa contatore API calls
            self::increment_api_calls('supadata');
            
            return [
                'success' => true,
                'message' => 'SupaData API is working correctly',
                'details' => [
                    'status_code' => $code,
                    'has_transcript' => !empty($body['transcript'] ?? $body['text']),
                    'response_time' => wp_remote_retrieve_header($response, 'x-response-time') ?? 'N/A'
                ]
            ];
        } else {
            return [
                'success' => false,
                'message' => 'API error: ' . ($body['error'] ?? 'Unknown error'),
                'details' => $body
            ];
        }
    }
    
    /**
     * Test AI Connection (OpenAI/Claude)
     */
    public static function test_ai_connection() {
        self::verify_nonce();
        
        $provider = sanitize_text_field($_POST['provider'] ?? 'openai');
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $model = sanitize_text_field($_POST['model'] ?? '');
        
        if (empty($api_key)) {
            wp_send_json_error(['message' => 'API key is required']);
        }
        
        // Test con un prompt semplice
        $test_prompt = "Say 'Hello, World!' in Italian";
        
        $args = [
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json'
            ]
        ];
        
        if ($provider === 'openai') {
            $args['headers']['Authorization'] = 'Bearer ' . $api_key;
            $args['body'] = json_encode([
                'model' => $model ?: 'gpt-4o-mini',
                'messages' => [
                    ['role' => 'user', 'content' => $test_prompt]
                ],
                'max_tokens' => 50
            ]);
            
            $response = wp_remote_post('https://api.openai.com/v1/chat/completions', $args);
            
        } else { // anthropic (Claude)
            $args['headers']['x-api-key'] = $api_key;
            $args['headers']['anthropic-version'] = '2023-06-01';
            $args['body'] = json_encode([
                'model' => $model ?: 'claude-3-5-sonnet-20241022',
                'max_tokens' => 50,
                'messages' => [
                    ['role' => 'user', 'content' => $test_prompt]
                ]
            ]);
            
            $response = wp_remote_post('https://api.anthropic.com/v1/messages', $args);
        }
        
        if (is_wp_error($response)) {
            wp_send_json_error([
                'message' => 'Connection error: ' . $response->get_error_message()
            ]);
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code === 200) {
            // Estrai la risposta in base al provider
            $ai_response = '';
            if ($provider === 'openai') {
                $ai_response = $body['choices'][0]['message']['content'] ?? 'No response';
            } else {
                $ai_response = $body['content'][0]['text'] ?? 'No response';
            }
            
            wp_send_json_success([
                'message' => ucfirst($provider) . ' API is working correctly!',
                'details' => [
                    'provider' => $provider,
                    'model' => $model,
                    'test_response' => $ai_response
                ]
            ]);
        } else {
            wp_send_json_error([
                'message' => 'API error (HTTP ' . $code . '): ' . ($body['error']['message'] ?? 'Unknown error'),
                'details' => $body
            ]);
        }
    }
    
    /**
     * Save Transcript Settings
     */
    public static function save_transcript_settings() {
        self::verify_nonce();
        
        $settings_data = $_POST['settings'] ?? [];
        
        if (empty($settings_data)) {
            wp_send_json_error(['message' => 'No settings provided']);
        }
        
        // Salva il metodo di trascrizione
        $method = sanitize_text_field($settings_data['method'] ?? 'supadata');
        update_option('ipv_transcript_method', $method);
        
        // Aggiorna le impostazioni
        $current_settings = IPV_Settings::get();
        
        if (!empty($settings_data['ytapi_key'])) {
            $current_settings['youtube_api_key'] = sanitize_text_field($settings_data['ytapi_key']);
        }
        
        if (!empty($settings_data['supadata_base'])) {
            $current_settings['supadata_base'] = esc_url_raw($settings_data['supadata_base']);
        }
        
        if (!empty($settings_data['supadata_key'])) {
            $current_settings['supadata_key'] = sanitize_text_field($settings_data['supadata_key']);
        }
        
        if (!empty($settings_data['supadata_path'])) {
            $current_settings['supadata_transcript_path'] = sanitize_text_field($settings_data['supadata_path']);
        }
        
        if (isset($settings_data['supadata_timeout'])) {
            $current_settings['supadata_timeout'] = absint($settings_data['supadata_timeout']);
        }
        
        update_option('ipv_settings', $current_settings);
        
        // Salva impostazioni AI (OpenAI/Claude)
        if (isset($settings_data['ai_provider']) || isset($settings_data['ai_key']) || isset($settings_data['ai_model'])) {
            $ai_settings = get_option('ipv_openai_settings', []);
            
            // CRITICAL FIX: Ensure $ai_settings is always an array
            if (!is_array($ai_settings)) {
                $ai_settings = [];
            }
            
            if (isset($settings_data['ai_provider'])) {
                $ai_settings['provider'] = sanitize_text_field($settings_data['ai_provider']);
            }
            
            if (isset($settings_data['ai_key'])) {
                $ai_settings['api_key'] = sanitize_text_field($settings_data['ai_key']);
            }
            
            if (isset($settings_data['ai_model'])) {
                $ai_settings['model'] = sanitize_text_field($settings_data['ai_model']);
            }
            
            update_option('ipv_openai_settings', $ai_settings);
        }
        
        wp_send_json_success(['message' => 'Settings saved successfully']);
    }
    
    /**
     * Save Scheduler
     */
    public static function save_scheduler() {
        self::verify_nonce();
        
        $frequency = sanitize_text_field($_POST['frequency'] ?? 'disabled');
        
        // Rimuovi eventuali cron esistenti
        $timestamp = wp_next_scheduled('ipv_scheduled_import');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'ipv_scheduled_import');
        }
        
        // Salva la frequenza
        update_option('ipv_import_frequency', $frequency);
        
        // Se non disabled, schedula il nuovo cron
        if ($frequency !== 'disabled') {
            $next_run = wp_schedule_event(time(), $frequency, 'ipv_scheduled_import');
            
            if ($next_run === false) {
                wp_send_json_error(['message' => 'Failed to schedule import']);
            }
            
            $next_run_formatted = date('Y-m-d H:i:s', wp_next_scheduled('ipv_scheduled_import'));
            
            wp_send_json_success([
                'message' => 'Scheduler updated successfully',
                'next_run' => $next_run_formatted
            ]);
        } else {
            wp_send_json_success([
                'message' => 'Scheduler disabled',
                'next_run' => 'Not scheduled'
            ]);
        }
    }
    
    /**
     * Get Next Scheduled Sync
     */
    public static function get_next_scheduled_sync() {
        self::verify_nonce();
        
        $next_run = wp_next_scheduled('ipv_scheduled_import');
        
        if ($next_run) {
            $next_run_formatted = date('Y-m-d H:i:s', $next_run);
            $human_time = human_time_diff($next_run, current_time('timestamp'));
            
            wp_send_json_success([
                'next_run' => $next_run_formatted . ' (in ' . $human_time . ')'
            ]);
        } else {
            wp_send_json_success([
                'next_run' => 'Not scheduled'
            ]);
        }
    }
    
    /**
     * Increment API Calls Counter
     */
    private static function increment_api_calls($api_type) {
        // Today
        $today_key = 'ipv_api_calls_today';
        $today_count = get_transient($today_key) ?: 0;
        set_transient($today_key, $today_count + 1, DAY_IN_SECONDS);
        
        // Month
        $month_key = 'ipv_api_calls_month';
        $month_count = get_option($month_key, 0);
        update_option($month_key, $month_count + 1);
        
        // Total
        $total_key = 'ipv_api_calls_total';
        $total_count = get_option($total_key, 0);
        update_option($total_key, $total_count + 1);
        
        // Per API type
        $type_key = 'ipv_api_calls_' . $api_type;
        $type_count = get_option($type_key, 0);
        update_option($type_key, $type_count + 1);
    }
}
}
