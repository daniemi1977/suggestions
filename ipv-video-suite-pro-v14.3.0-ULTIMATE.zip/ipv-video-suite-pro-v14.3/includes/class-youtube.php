<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_YouTube')){
class IPV_YouTube {

    public static function init(){
        add_action('add_meta_boxes', array(__CLASS__,'add_metabox'), 11);
        add_action('admin_post_ipv_youtube_refresh', array(__CLASS__,'handle_refresh'));
    }

    protected static function api_key(){
        $o = get_option('ipv_settings', array());
        if (!empty($o['youtube_api_key'])) return $o['youtube_api_key'];
        foreach (array('ipv_youtube_api_key','youtube_api_key','google_api_key','ipv_google_api_key') as $k){
            $v = trim(get_option($k,''));
            if ($v) return $v;
        }
        return '';
    }

    public static function add_metabox(){
        add_meta_box('ipv_yt_details','YouTube Details (API)', array(__CLASS__,'render_box'), 'ipv_video', 'side', 'high');
    }

    public static function render_box($post){
        $yid = get_post_meta($post->ID, '_ipv_youtube_id', true);
        if (!$yid){
            $url = get_post_meta($post->ID, '_ipv_youtube_url', true);
            if ($url && preg_match('~v=([A-Za-z0-9_-]{11})~',$url,$m)) $yid = $m[1];
        }
        $api_key = self::api_key();
        $refresh_url = wp_nonce_url( admin_url('admin-post.php?action=ipv_youtube_refresh&post_id='.$post->ID), 'ipv_youtube_refresh' );

        echo '<p><small>API Key: '.($api_key ? 'OK' : '<span style="color:#c00">mancante</span>').'</small></p>';
        echo '<p><a class="button" href="'.esc_url($refresh_url).'">Aggiorna da API</a></p>';
        echo '<p><strong>Video ID:</strong> '.esc_html($yid ?: '—').'</p>';

        $fields = array(
            '_ipv_yt_title'        => 'Titolo',
            '_ipv_yt_channel'      => 'Canale',
            '_ipv_yt_published_at' => 'Pubblicato',
            '_ipv_yt_duration'     => 'Durata',
            '_ipv_yt_tags'         => 'Tag',
            '_ipv_yt_view_count'   => 'Views',
            '_ipv_yt_like_count'   => 'Likes',
        );
        echo '<table class="widefat striped"><tbody>';
        foreach($fields as $k=>$label){
            $val = get_post_meta($post->ID, $k, true);
            echo '<tr><td><strong>'.esc_html($label).'</strong></td><td>'.esc_html($val).'</td></tr>';
        }
        echo '</tbody></table>';
    }

    public static function handle_refresh(){
        if (!current_user_can('edit_posts')) wp_die('Not allowed');
        if (empty($_GET['post_id'])) wp_die('Missing post_id');
        check_admin_referer('ipv_youtube_refresh');

        $post_id = absint($_GET['post_id']);
        $api_key = self::api_key(); if (!$api_key){ wp_safe_redirect( get_edit_post_link($post_id,'') ); exit; }

        $yid = get_post_meta($post_id, '_ipv_youtube_id', true);
        if (!$yid){
            $url = get_post_meta($post_id, '_ipv_youtube_url', true);
            if ($url && preg_match('~v=([A-Za-z0-9_-]{11})~',$url,$m)) $yid = $m[1];
        }
        if (!$yid){ wp_safe_redirect( get_edit_post_link($post_id,'') ); exit; }

        $data = self::fetch_video($yid, $api_key);
        if ($data){
            update_post_meta($post_id,'_ipv_yt_title', $data['title']);
            update_post_meta($post_id,'_ipv_yt_description', $data['description']);
            update_post_meta($post_id,'_ipv_yt_channel', $data['channelTitle']);
            update_post_meta($post_id,'_ipv_yt_published_at', $data['publishedAt']);
            update_post_meta($post_id,'_ipv_yt_duration', $data['duration']);
            update_post_meta($post_id,'_ipv_yt_tags', implode(', ', $data['tags']));
            update_post_meta($post_id,'_ipv_yt_view_count', $data['viewCount']);
            update_post_meta($post_id,'_ipv_yt_like_count', $data['likeCount']);
            update_post_meta($post_id,'_ipv_yt_thumbnails', wp_json_encode($data['thumbnails']));
            update_post_meta($post_id,'_ipv_yt_raw', wp_json_encode($data['raw']));
        }
        wp_safe_redirect( get_edit_post_link($post_id,'') ); exit;
    }

    public static function fetch_video($video_id, $api_key){
        $parts = 'snippet,contentDetails,statistics';
        $url = add_query_arg(array( 'id'=>$video_id, 'part'=>$parts, 'key'=>$api_key ), 'https://www.googleapis.com/youtube/v3/videos');
        $r = wp_remote_get($url, array( 'timeout'=>30 ));
        if (is_wp_error($r)) return null;
        $code = wp_remote_retrieve_response_code($r);
        $body = json_decode( wp_remote_retrieve_body($r), true );
        if ($code !== 200 || empty($body['items'][0])) return null;
        $it = $body['items'][0];
        $sn = $it['snippet']; $cd = $it['contentDetails']; $st = isset($it['statistics']) ? $it['statistics'] : array();
        $duration = isset($cd['duration']) ? self::parse_duration($cd['duration']) : '';
        return array(
            'title'        => isset($sn['title']) ? $sn['title'] : '',
            'description'  => isset($sn['description']) ? $sn['description'] : '',
            'channelTitle' => isset($sn['channelTitle']) ? $sn['channelTitle'] : '',
            'publishedAt'  => isset($sn['publishedAt']) ? $sn['publishedAt'] : '',
            'tags'         => !empty($sn['tags']) ? $sn['tags'] : array(),
            'thumbnails'   => isset($sn['thumbnails']) ? $sn['thumbnails'] : array(),
            'duration'     => $duration,
            'viewCount'    => isset($st['viewCount']) ? $st['viewCount'] : '',
            'likeCount'    => isset($st['likeCount']) ? $st['likeCount'] : '',
            'raw'          => $it,
        );
    }

    protected static function parse_duration($iso){
        // PT#H#M#S -> H:MM:SS | MM:SS
        $h = $m = $s = 0;
        if (preg_match('/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/i', $iso, $mm)){
            $h = !empty($mm[1]) ? intval($mm[1]) : 0;
            $m = !empty($mm[2]) ? intval($mm[2]) : 0;
            $s = !empty($mm[3]) ? intval($mm[3]) : 0;
        }
        if ($h > 0) return sprintf('%02d:%02d:%02d', $h, $m, $s);
        return sprintf('%02d:%02d', $m, $s);
    }
}}
