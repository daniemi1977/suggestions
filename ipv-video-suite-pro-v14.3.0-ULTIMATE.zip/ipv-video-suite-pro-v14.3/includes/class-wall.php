<?php
/**
 * IPV Video Wall - v2.0 (Unified)
 *
 * This class handles the frontend display of videos via the [ipv_video_wall] shortcode.
 * It merges the functionalities of the previous class-wall.php and class-frontend-wall.php,
 * providing a single, robust solution with AJAX "load more" functionality.
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('IPV_Wall')) {
class IPV_Wall {
    
    public static function init() {
        // Main shortcode
        add_shortcode('ipv_video_wall', [__CLASS__, 'shortcode']);
        // Alias for backward compatibility
        add_shortcode('ipv_wall', [__CLASS__, 'shortcode']);
        
        // Enqueue assets and handle AJAX
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('wp_ajax_ipv_load_more_videos', [__CLASS__, 'ajax_load_more']);
        add_action('wp_ajax_nopriv_ipv_load_more_videos', [__CLASS__, 'ajax_load_more']);
    }
    
    /**
     * Enqueue frontend assets (CSS/JS) only when needed.
     */
    public static function enqueue_assets() {
        global $post;
        $should_load = is_front_page() || is_home() || is_post_type_archive('ipv_video') || (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'ipv_video_wall') || has_shortcode($post->post_content, 'ipv_wall')));

        if ($should_load) {
            wp_enqueue_style('ipv-wall-style', IPV_PLUGIN_URL . 'assets/wall.css', [], IPV_VSP_VER);
            wp_enqueue_script('ipv-wall-script', IPV_PLUGIN_URL . 'assets/wall.js', ['jquery'], IPV_VSP_VER, true);
            wp_localize_script('ipv-wall-script', 'IPV_WALL_DATA', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('ipv_ajax_nonce'), // ✅ UNIFIED NONCE
                'no_more_text' => __('No more videos', 'ipv'),
            ]);
        }
    }
    
    /**
     * Shortcode handler for [ipv_video_wall].
     * @param array $atts Shortcode attributes.
     * @return string The rendered HTML for the video wall.
     */
    public static function shortcode($atts) {
        $atts = shortcode_atts([
            'limit'       => 12,
            'columns'     => 3,
            'orderby'     => 'date',
            'order'       => 'DESC',
            'load_more'   => true,
            'target'      => 'cpt' // 'cpt' for permalink, 'youtube' for direct link
        ], $atts, 'ipv_video_wall');
        
        $query_args = [
            'post_type'      => 'ipv_video',
            'posts_per_page' => intval($atts['limit']),
            'post_status'    => 'publish',
            'orderby'        => sanitize_key($atts['orderby']),
            'order'          => ($atts['order'] === 'ASC') ? 'ASC' : 'DESC',
        ];
        
        $query = new WP_Query($query_args);
        
        ob_start();
        
        if ($query->have_posts()) {
            echo '<div class="ipv-wall-wrapper" data-atts="' . esc_attr(json_encode($atts)) . '">';
            echo '<div class="ipv-wall-grid" style="--ipv-columns:' . intval($atts['columns']) . ';">';
            
            while ($query->have_posts()) {
                $query->the_post();
                self::render_video_card(get_the_ID(), $atts);
            }
            
            echo '</div>';
            
            if ($atts['load_more'] && $query->max_num_pages > 1) {
                echo '<div class="ipv-wall-footer">';
                echo '<button class="ipv-load-more-btn" data-page="1" data-max-pages="' . $query->max_num_pages . '">';
                echo '<span class="ipv-btn-text">' . __('Load More Videos', 'ipv') . '</span>';
                echo '<span class="ipv-btn-loader" style="display: none;"><span class="spinner"></span></span>';
                echo '</button>';
                echo '</div>';
            }
            echo '</div>';
            wp_reset_postdata();
        } else {
            echo '<p class="ipv-no-videos">No videos available at the moment.</p>';
        }
        
        return ob_get_clean();
    }
    
    /**
     * AJAX handler for loading more videos.
     */
    public static function ajax_load_more() {
        check_ajax_referer('ipv_ajax_nonce', 'nonce'); // ✅ UNIFIED NONCE
        
        $page = intval($_POST['page'] ?? 1) + 1;
        $atts = json_decode(stripslashes($_POST['atts'] ?? '{}'), true);
        
        $query_args = [
            'post_type'      => 'ipv_video',
            'posts_per_page' => intval($atts['limit'] ?? 12),
            'post_status'    => 'publish',
            'orderby'        => sanitize_key($atts['orderby'] ?? 'date'),
            'order'          => ($atts['order'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC',
            'paged'          => $page,
        ];

        $query = new WP_Query($query_args);
        
        ob_start();
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                self::render_video_card(get_the_ID(), $atts);
            }
        }
        $html = ob_get_clean();
        
        wp_send_json_success([
            'html'      => $html,
            'has_more'  => $query->max_num_pages > $page
        ]);
    }

    /**
     * Renders the HTML for a single video card.
     * @param int $post_id
     * @param array $atts
     */
    protected static function render_video_card($post_id, $atts) {
        // ... (implementation of the HTML card rendering) ...
        $youtube_id = get_post_meta($post_id, '_ipv_youtube_id', true);
        $link = ($atts['target'] === 'youtube') ? "https://www.youtube.com/watch?v={$youtube_id}" : get_permalink($post_id);
        
        echo '<article class="ipv-video-card">';
        echo '<div class="ipv-video-thumbnail">';
        echo '<a href="' . esc_url($link) . '"' . ($atts['target'] === 'youtube' ? ' target="_blank"' : '') . '>';
        if (has_post_thumbnail($post_id)) {
            the_post_thumbnail('large');
        } else {
            echo '<img src="https://img.youtube.com/vi/' . esc_attr($youtube_id) . '/hqdefault.jpg" alt="' . esc_attr(get_the_title()) . '">';
        }
        echo '<div class="ipv-video-overlay"></div>';
        echo '</a>';
        echo '</div>';
        echo '<h3 class="ipv-video-title"><a href="' . esc_url($link) . '"' . ($atts['target'] === 'youtube' ? ' target="_blank"' : '') . '>' . get_the_title() . '</a></h3>';
        echo '</article>';
    }
}
}