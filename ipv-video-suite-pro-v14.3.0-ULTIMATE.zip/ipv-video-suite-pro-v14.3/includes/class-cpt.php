<?php
/**
 * IPV Custom Post Type
 *
 * Registers the 'ipv_video' CPT, metaboxes, and handles centralized
 * admin script enqueueing, including the unified AJAX nonce.
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('IPV_CPT')) {
class IPV_CPT {
    
    public static function init() {
        add_action('init', [__CLASS__, 'register_cpt']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_assets']);
        add_action('add_meta_boxes_ipv_video', [__CLASS__, 'add_meta_boxes']);
        add_action('save_post_ipv_video', [__CLASS__, 'save_meta'], 10, 2);
    }
    
    /**
     * Enqueue admin assets and localize the unified AJAX nonce.
     * @param string $hook The current admin page hook.
     */
    public static function enqueue_admin_assets($hook) {
        $is_ipv_page = ($hook === 'post.php' || $hook === 'post-new.php' || strpos($hook, 'ipv-') !== false);
        
        if ($is_ipv_page) {
            wp_enqueue_style('ipv-admin-style', IPV_PLUGIN_URL . 'assets/admin.css', [], IPV_VSP_VER);
            wp_enqueue_script('ipv-admin-script', IPV_PLUGIN_URL . 'assets/admin.js', ['jquery'], IPV_VSP_VER, true);
            
            // ✅ UNIFIED AJAX NONCE
            wp_localize_script('ipv-admin-script', 'IPV_AJAX_DATA', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('ipv_ajax_nonce')
            ]);
        }
    }

    /**
     * Register the Custom Post Type 'ipv_video'.
     */
    public static function register_cpt() {
        // ... (CPT registration labels and args) ...
        $labels = [
            'name' => __('IPV Videos', 'ipv'),
            // ... other labels
        ];
        $args = [
            'labels' => $labels,
            'public' => true,
            'show_in_menu' => false, // Subsumed under main menu
            'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
            'has_archive' => true,
            'rewrite' => ['slug' => 'video'],
        ];
        register_post_type('ipv_video', $args);
    }
    
    /**
     * Add metaboxes to the CPT edit screen.
     */
    public static function add_meta_boxes() {
        add_meta_box(
            'ipv_video_details_meta', 
            __('YouTube Details', 'ipv'), 
            [__CLASS__, 'render_details_metabox'], 
            'ipv_video', 
            'normal', 
            'high'
        );
    }

    /**
     * Render the metabox content.
     * @param WP_Post $post
     */
    public static function render_details_metabox($post) {
        wp_nonce_field('ipv_meta_save', 'ipv_meta_nonce');
        // ... (HTML for metabox fields) ...
    }
    
    /**
     * Save the metabox data.
     * @param int $post_id
     * @param WP_Post $post
     */
    public static function save_meta($post_id, $post) {
        if (!isset($_POST['ipv_meta_nonce']) || !wp_verify_nonce($_POST['ipv_meta_nonce'], 'ipv_meta_save')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        // ... (Logic to save meta fields) ...
    }
}
}