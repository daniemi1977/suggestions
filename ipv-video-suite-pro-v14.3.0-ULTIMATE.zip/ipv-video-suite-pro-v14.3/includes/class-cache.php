<?php

if (!defined('ABSPATH')) exit;

/**
 * Sistema di caching per ridurre chiamate API e migliorare performance
 */
class IPV_Cache {
    const FEED_CACHE_TIME = 3600; // 1 ora
    const STREAMS_CACHE_TIME = 7200; // 2 ore
    const TRANSCRIPT_CACHE_TIME = 86400; // 24 ore
    const API_TEST_CACHE_TIME = 300; // 5 minuti
    
    public static function init() {
        // Hook per pulizia cache programmata
        add_action('ipvcpt_clear_expired_cache', [__CLASS__, 'clear_expired']);
        
        if (!wp_next_scheduled('ipvcpt_clear_expired_cache')) {
            wp_schedule_event(time(), 'daily', 'ipvcpt_clear_expired_cache');
        }
    }
    
    /**
     * Get cached data
     */
    public static function get($key, $group = IPVCPT_CACHE_GROUP) {
        $transient_key = self::make_key($key, $group);
        return get_transient($transient_key);
    }
    
    /**
     * Set cache data
     */
    public static function set($key, $data, $expiration = 3600, $group = IPVCPT_CACHE_GROUP) {
        $transient_key = self::make_key($key, $group);
        return set_transient($transient_key, $data, $expiration);
    }
    
    /**
     * Delete cached data
     */
    public static function delete($key, $group = IPVCPT_CACHE_GROUP) {
        $transient_key = self::make_key($key, $group);
        return delete_transient($transient_key);
    }
    
    /**
     * Clear all cache for this plugin
     */
    public static function clear_all() {
        global $wpdb;
        
        $pattern = '_transient_' . IPVCPT_CACHE_GROUP . '%';
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
            $pattern,
            '_transient_timeout_' . IPVCPT_CACHE_GROUP . '%'
        ));
        
        IPV_Logger::info('Cache completamente svuotata');
        
        return true;
    }
    
    /**
     * Clear expired cache entries
     */
    public static function clear_expired() {
        global $wpdb;
        
        $time = time();
        $pattern = '_transient_timeout_' . IPVCPT_CACHE_GROUP . '%';
        
        $expired = $wpdb->get_col($wpdb->prepare(
            "SELECT option_name FROM $wpdb->options 
            WHERE option_name LIKE %s 
            AND option_value < %d",
            $pattern,
            $time
        ));
        
        $deleted = 0;
        foreach ($expired as $transient) {
            $key = str_replace('_transient_timeout_', '', $transient);
            if (delete_transient($key)) {
                $deleted++;
            }
        }
        
        if ($deleted > 0) {
            IPV_Logger::info("Rimossi $deleted elementi di cache scaduti");
        }
        
        return $deleted;
    }
    
    /**
     * Get cache statistics
     */
    public static function get_stats() {
        global $wpdb;
        
        $pattern = '_transient_' . IPVCPT_CACHE_GROUP . '%';
        
        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $wpdb->options WHERE option_name LIKE %s",
            $pattern
        ));
        
        $size = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(LENGTH(option_value)) FROM $wpdb->options WHERE option_name LIKE %s",
            $pattern
        ));
        
        return [
            'total_entries' => intval($total),
            'total_size' => intval($size),
            'size_formatted' => size_format($size)
        ];
    }
    
    /**
     * Make consistent cache key
     */
    protected static function make_key($key, $group) {
        return IPVCPT_CACHE_GROUP . '_' . $group . '_' . md5($key);
    }
    
    /**
     * Cache with callback pattern
     */
    public static function remember($key, $callback, $expiration = 3600, $group = IPVCPT_CACHE_GROUP) {
        $cached = self::get($key, $group);
        
        if ($cached !== false) {
            return $cached;
        }
        
        $data = call_user_func($callback);
        
        if ($data !== null && $data !== false) {
            self::set($key, $data, $expiration, $group);
        }
        
        return $data;
    }
}