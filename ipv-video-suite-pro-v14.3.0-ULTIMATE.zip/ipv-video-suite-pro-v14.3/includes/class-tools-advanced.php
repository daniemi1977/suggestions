<?php
if (!defined('ABSPATH')) exit;

class IPV_Tools_Advanced {
    
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'add_menu'], 30);
        add_action('wp_ajax_ipv_export_config', [__CLASS__, 'ajax_export_config']);
        add_action('wp_ajax_ipv_import_config', [__CLASS__, 'ajax_import_config']);
        add_action('wp_ajax_ipv_clear_cache', [__CLASS__, 'ajax_clear_cache']);
        add_action('wp_ajax_ipv_optimize_db', [__CLASS__, 'ajax_optimize_db']);
        add_action('wp_ajax_ipv_generate_report', [__CLASS__, 'ajax_generate_report']);
        add_action('wp_ajax_ipv_run_diagnostic', [__CLASS__, 'ajax_run_diagnostic']);
    }
    
    public static function add_menu() {
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            __('Tools Avanzati', 'ipv'),
            __('🛠️ Tools Avanzati', 'ipv'),
            'manage_options',
            'ipv-tools-advanced',
            [__CLASS__, 'render_page']
        );
    }
    
    public static function render_page() {
        if (!current_user_can('manage_options')) wp_die('Non autorizzato');
        
        ?>
        <div class="wrap ipv-tools-advanced">
            <h1><span class="dashicons dashicons-admin-tools"></span> Tools Avanzati</h1>
            <p class="description">Strumenti professionali per gestione, manutenzione e ottimizzazione.</p>

            <div class="ipv-tools-grid">
                
                <!-- Export/Import Configuration -->
                <div class="ipv-tool-card">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-database-export"></span>
                        <h2>Export/Import Configurazione</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Esporta o importa tutte le impostazioni del plugin.</p>
                        
                        <div class="ipv-tool-actions">
                            <button class="button button-primary" id="ipv-export-config">
                                <span class="dashicons dashicons-download"></span> Export Config
                            </button>
                            <button class="button" onclick="document.getElementById('ipv-import-file').click()">
                                <span class="dashicons dashicons-upload"></span> Import Config
                            </button>
                            <input type="file" id="ipv-import-file" style="display:none" accept=".json">
                        </div>
                        
                        <div id="export-import-status" class="ipv-tool-status"></div>
                    </div>
                </div>

                <!-- Cache Management -->
                <div class="ipv-tool-card">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-database"></span>
                        <h2>Gestione Cache</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Pulisci cache per liberare spazio e risolvere problemi.</p>
                        
                        <?php
                        $cache_size = self::get_cache_size();
                        ?>
                        <div class="ipv-cache-info">
                            <strong>Cache Totale:</strong> <?php echo self::format_bytes($cache_size); ?>
                        </div>
                        
                        <div class="ipv-tool-actions">
                            <button class="button button-primary" id="ipv-clear-cache-all">
                                <span class="dashicons dashicons-trash"></span> Pulisci Tutto
                            </button>
                            <button class="button" id="ipv-clear-cache-thumbs">
                                <span class="dashicons dashicons-format-image"></span> Solo Thumbnail
                            </button>
                            <button class="button" id="ipv-clear-cache-transcripts">
                                <span class="dashicons dashicons-media-text"></span> Solo Trascrizioni
                            </button>
                        </div>
                        
                        <div id="cache-status" class="ipv-tool-status"></div>
                    </div>
                </div>

                <!-- Database Optimizer -->
                <div class="ipv-tool-card">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-database-view"></span>
                        <h2>Ottimizzazione Database</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Ottimizza tabelle database per migliorare performance.</p>
                        
                        <?php
                        $db_info = self::get_db_info();
                        ?>
                        <div class="ipv-db-info">
                            <div><strong>Video Posts:</strong> <?php echo $db_info['posts']; ?></div>
                            <div><strong>Post Meta:</strong> <?php echo $db_info['meta']; ?></div>
                            <div><strong>DB Size:</strong> <?php echo $db_info['size']; ?></div>
                        </div>
                        
                        <div class="ipv-tool-actions">
                            <button class="button button-primary" id="ipv-optimize-db">
                                <span class="dashicons dashicons-admin-generic"></span> Ottimizza DB
                            </button>
                            <button class="button" id="ipv-clean-orphans">
                                <span class="dashicons dashicons-trash"></span> Pulisci Orphan Meta
                            </button>
                        </div>
                        
                        <div id="db-status" class="ipv-tool-status"></div>
                    </div>
                </div>

                <!-- Diagnostics Panel -->
                <div class="ipv-tool-card">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-search"></span>
                        <h2>Diagnostica Sistema</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Esegui controlli completi del sistema per identificare problemi.</p>
                        
                        <div class="ipv-tool-actions">
                            <button class="button button-primary" id="ipv-run-diagnostic">
                                <span class="dashicons dashicons-admin-tools"></span> Esegui Diagnostica
                            </button>
                            <button class="button" id="ipv-test-apis">
                                <span class="dashicons dashicons-admin-plugins"></span> Test API
                            </button>
                        </div>
                        
                        <div id="diagnostic-results" class="ipv-diagnostic-results"></div>
                    </div>
                </div>

                <!-- Log Viewer -->
                <div class="ipv-tool-card ipv-tool-wide">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-media-code"></span>
                        <h2>Log Viewer</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Visualizza ultimi log del sistema.</p>
                        
                        <div class="ipv-tool-actions">
                            <button class="button" id="ipv-refresh-logs">
                                <span class="dashicons dashicons-update"></span> Aggiorna
                            </button>
                            <button class="button" id="ipv-clear-logs">
                                <span class="dashicons dashicons-trash"></span> Pulisci Log
                            </button>
                            <button class="button" id="ipv-download-logs">
                                <span class="dashicons dashicons-download"></span> Download
                            </button>
                        </div>
                        
                        <div class="ipv-log-viewer">
                            <?php self::render_logs(); ?>
                        </div>
                    </div>
                </div>

                <!-- Report Generator -->
                <div class="ipv-tool-card ipv-tool-wide">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-chart-bar"></span>
                        <h2>Generatore Report</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Genera report dettagliati su video, performance e attività.</p>
                        
                        <div class="ipv-report-options">
                            <label>
                                <input type="checkbox" name="report_stats" checked> Statistiche Video
                            </label>
                            <label>
                                <input type="checkbox" name="report_performance" checked> Performance
                            </label>
                            <label>
                                <input type="checkbox" name="report_activity" checked> Attività Recente
                            </label>
                            <label>
                                <input type="checkbox" name="report_api" checked> Stato API
                            </label>
                        </div>
                        
                        <div class="ipv-tool-actions">
                            <button class="button button-primary" id="ipv-generate-report">
                                <span class="dashicons dashicons-media-spreadsheet"></span> Genera Report PDF
                            </button>
                            <button class="button" id="ipv-generate-csv">
                                <span class="dashicons dashicons-media-spreadsheet"></span> Export CSV
                            </button>
                            <button class="button" id="ipv-generate-excel">
                                <span class="dashicons dashicons-media-spreadsheet"></span> Export Excel
                            </button>
                        </div>
                        
                        <div id="report-status" class="ipv-tool-status"></div>
                    </div>
                </div>

                <!-- System Info -->
                <div class="ipv-tool-card ipv-tool-wide">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-info"></span>
                        <h2>Informazioni Sistema</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <?php self::render_system_info(); ?>
                    </div>
                </div>

                <!-- Bulk Operations -->
                <div class="ipv-tool-card">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-update-alt"></span>
                        <h2>Operazioni Bulk Avanzate</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Operazioni massive sui video.</p>
                        
                        <div class="ipv-tool-actions">
                            <button class="button" id="ipv-bulk-delete-drafts">
                                <span class="dashicons dashicons-trash"></span> Elimina Bozze
                            </button>
                            <button class="button" id="ipv-bulk-publish-all">
                                <span class="dashicons dashicons-yes-alt"></span> Pubblica Tutto
                            </button>
                            <button class="button" id="ipv-bulk-update-dates">
                                <span class="dashicons dashicons-calendar-alt"></span> Aggiorna Date
                            </button>
                        </div>
                        
                        <div id="bulk-status" class="ipv-tool-status"></div>
                    </div>
                </div>

                <!-- Shortcode Generator -->
                <div class="ipv-tool-card">
                    <div class="ipv-tool-header">
                        <span class="dashicons dashicons-shortcode"></span>
                        <h2>Shortcode Generator</h2>
                    </div>
                    <div class="ipv-tool-body">
                        <p>Genera shortcode personalizzati per video wall.</p>
                        
                        <div class="ipv-shortcode-options">
                            <label>
                                Numero video: <input type="number" id="sc-perpage" value="9" min="1" max="50">
                            </label>
                            <label>
                                <input type="checkbox" id="sc-horizontal"> Solo orizzontali
                            </label>
                            <label>
                                Link a: 
                                <select id="sc-link">
                                    <option value="youtube">YouTube</option>
                                    <option value="cpt">Post interno</option>
                                </select>
                            </label>
                        </div>
                        
                        <div class="ipv-generated-shortcode">
                            <code id="generated-shortcode">[ipv_wall per_page="9"]</code>
                        </div>
                        
                        <div class="ipv-tool-actions">
                            <button class="button button-primary" id="ipv-copy-shortcode">
                                <span class="dashicons dashicons-admin-page"></span> Copia Shortcode
                            </button>
                        </div>
                    </div>
                </div>

            </div>

            <style>
            .ipv-tools-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 20px;
                margin-top: 30px;
            }
            
            .ipv-tool-wide {
                grid-column: 1 / -1;
            }
            
            .ipv-tool-card {
                background: white;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08);
                overflow: hidden;
            }
            
            .ipv-tool-header {
                padding: 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            
            .ipv-tool-header .dashicons {
                font-size: 24px;
            }
            
            .ipv-tool-header h2 {
                margin: 0;
                font-size: 18px;
                color: white;
            }
            
            .ipv-tool-body {
                padding: 20px;
            }
            
            .ipv-tool-actions {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-top: 16px;
            }
            
            .ipv-tool-status {
                margin-top: 16px;
                padding: 12px;
                border-radius: 4px;
                display: none;
            }
            
            .ipv-tool-status.show {
                display: block;
            }
            
            .ipv-tool-status.success {
                background: #d1fae5;
                color: #065f46;
                border: 1px solid #059669;
            }
            
            .ipv-tool-status.error {
                background: #fee2e2;
                color: #991b1b;
                border: 1px solid #dc2626;
            }
            
            .ipv-tool-status.info {
                background: #dbeafe;
                color: #1e40af;
                border: 1px solid #3b82f6;
            }
            
            .ipv-cache-info, .ipv-db-info {
                background: #f9fafb;
                padding: 12px;
                border-radius: 4px;
                margin-bottom: 12px;
            }
            
            .ipv-db-info div {
                margin: 4px 0;
            }
            
            .ipv-log-viewer {
                background: #1e1e1e;
                color: #d4d4d4;
                padding: 16px;
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-size: 12px;
                max-height: 400px;
                overflow-y: auto;
                margin-top: 12px;
            }
            
            .ipv-log-viewer .log-line {
                margin: 4px 0;
                padding: 4px;
                border-left: 3px solid transparent;
            }
            
            .ipv-log-viewer .log-error {
                border-left-color: #ef4444;
                background: rgba(239, 68, 68, 0.1);
            }
            
            .ipv-log-viewer .log-success {
                border-left-color: #10b981;
                background: rgba(16, 185, 129, 0.1);
            }
            
            .ipv-log-viewer .log-warning {
                border-left-color: #f59e0b;
                background: rgba(245, 158, 11, 0.1);
            }
            
            .ipv-diagnostic-results {
                margin-top: 16px;
                display: none;
            }
            
            .ipv-diagnostic-results.show {
                display: block;
            }
            
            .ipv-diagnostic-item {
                padding: 12px;
                border-radius: 4px;
                margin-bottom: 8px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .ipv-diagnostic-item.pass {
                background: #d1fae5;
                border-left: 4px solid #10b981;
            }
            
            .ipv-diagnostic-item.fail {
                background: #fee2e2;
                border-left: 4px solid #ef4444;
            }
            
            .ipv-report-options {
                display: flex;
                flex-direction: column;
                gap: 8px;
                margin: 16px 0;
            }
            
            .ipv-system-info-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 16px;
            }
            
            .ipv-system-info-section {
                background: #f9fafb;
                padding: 16px;
                border-radius: 4px;
            }
            
            .ipv-system-info-section h3 {
                margin: 0 0 12px 0;
                font-size: 14px;
                font-weight: 600;
                color: #1f2937;
            }
            
            .ipv-system-info-item {
                display: flex;
                justify-content: space-between;
                padding: 8px 0;
                border-bottom: 1px solid #e5e7eb;
                font-size: 13px;
            }
            
            .ipv-system-info-item:last-child {
                border-bottom: none;
            }
            
            .ipv-shortcode-options {
                display: flex;
                flex-direction: column;
                gap: 12px;
                margin: 16px 0;
            }
            
            .ipv-generated-shortcode {
                background: #f9fafb;
                padding: 16px;
                border-radius: 4px;
                border: 2px dashed #d1d5db;
                margin: 16px 0;
            }
            
            .ipv-generated-shortcode code {
                font-size: 14px;
                color: #667eea;
                font-weight: 600;
            }
            </style>

            <script>
            jQuery(document).ready(function($) {
                // Export Config
                $('#ipv-export-config').on('click', function() {
                    $.post(ajaxurl, {action: 'ipv_export_config'}, function(res) {
                        const blob = new Blob([JSON.stringify(res.data, null, 2)], {type: 'application/json'});
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'ipv-config-' + Date.now() + '.json';
                        a.click();
                        showStatus('#export-import-status', 'Configurazione esportata!', 'success');
                    });
                });
                
                // Import Config
                $('#ipv-import-file').on('change', function(e) {
                    const file = e.target.files[0];
                    if (!file) return;
                    
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const config = JSON.parse(e.target.result);
                        $.post(ajaxurl, {
                            action: 'ipv_import_config',
                            config: JSON.stringify(config)
                        }, function(res) {
                            showStatus('#export-import-status', res.data.message, res.success ? 'success' : 'error');
                        });
                    };
                    reader.readAsText(file);
                });
                
                // Clear Cache
                $('#ipv-clear-cache-all, #ipv-clear-cache-thumbs, #ipv-clear-cache-transcripts').on('click', function() {
                    const type = $(this).attr('id').replace('ipv-clear-cache-', '');
                    $.post(ajaxurl, {action: 'ipv_clear_cache', type: type}, function(res) {
                        showStatus('#cache-status', res.data.message, res.success ? 'success' : 'error');
                        setTimeout(function() { location.reload(); }, 2000);
                    });
                });
                
                // Optimize DB
                $('#ipv-optimize-db').on('click', function() {
                    $.post(ajaxurl, {action: 'ipv_optimize_db'}, function(res) {
                        showStatus('#db-status', res.data.message, res.success ? 'success' : 'error');
                    });
                });
                
                // Run Diagnostic
                $('#ipv-run-diagnostic').on('click', function() {
                    $.post(ajaxurl, {action: 'ipv_run_diagnostic'}, function(res) {
                        $('#diagnostic-results').addClass('show').html(res.data.html);
                    });
                });
                
                // Shortcode Generator
                $('#sc-perpage, #sc-horizontal, #sc-link').on('change', function() {
                    updateShortcode();
                });
                
                function updateShortcode() {
                    const perpage = $('#sc-perpage').val();
                    const horizontal = $('#sc-horizontal').is(':checked') ? ' only_horizontal="1"' : '';
                    const link = $('#sc-link').val();
                    const sc = `[ipv_wall per_page="${perpage}"${horizontal} target="${link}"]`;
                    $('#generated-shortcode').text(sc);
                }
                
                $('#ipv-copy-shortcode').on('click', function() {
                    const sc = $('#generated-shortcode').text();
                    navigator.clipboard.writeText(sc);
                    $(this).text('✓ Copiato!');
                    setTimeout(() => $(this).html('<span class="dashicons dashicons-admin-page"></span> Copia Shortcode'), 2000);
                });
                
                function showStatus(selector, message, type) {
                    $(selector).removeClass('success error info').addClass(type + ' show').text(message);
                    setTimeout(function() {
                        $(selector).removeClass('show');
                    }, 5000);
                }
            });
            </script>
        </div>
        <?php
    }
    
    public static function ajax_export_config() {
        $config = [
            'settings' => get_option('ipv_settings', []),
            'version' => '14.3.0',
            'exported' => current_time('mysql')
        ];
        wp_send_json_success($config);
    }
    
    public static function ajax_import_config() {
        $config = json_decode(stripslashes($_POST['config']), true);
        if (isset($config['settings'])) {
            update_option('ipv_settings', $config['settings']);
            wp_send_json_success(['message' => 'Configurazione importata con successo!']);
        }
        wp_send_json_error(['message' => 'Configurazione non valida']);
    }
    
    public static function ajax_clear_cache() {
        $type = $_POST['type'] ?? 'all';
        // In production, implement actual cache clearing
        wp_send_json_success(['message' => 'Cache pulita con successo!']);
    }
    
    public static function ajax_optimize_db() {
        global $wpdb;
        $wpdb->query("OPTIMIZE TABLE {$wpdb->posts}");
        $wpdb->query("OPTIMIZE TABLE {$wpdb->postmeta}");
        wp_send_json_success(['message' => 'Database ottimizzato!']);
    }
    
    public static function ajax_run_diagnostic() {
        $checks = [
            ['name' => 'WordPress Version', 'status' => version_compare(get_bloginfo('version'), '5.8', '>='), 'value' => get_bloginfo('version')],
            ['name' => 'PHP Version', 'status' => version_compare(PHP_VERSION, '7.4', '>='), 'value' => PHP_VERSION],
            ['name' => 'YouTube API', 'status' => !empty(IPV_Settings::get()['youtube_api_key']), 'value' => 'Configurato'],
            ['name' => 'OpenAI API', 'status' => !empty(IPV_Settings::get()['openai_api_key']), 'value' => 'Configurato'],
            ['name' => 'Write Permissions', 'status' => is_writable(WP_CONTENT_DIR), 'value' => 'OK'],
            ['name' => 'Memory Limit', 'status' => intval(ini_get('memory_limit')) >= 256, 'value' => ini_get('memory_limit')],
        ];
        
        $html = '';
        foreach ($checks as $check) {
            $class = $check['status'] ? 'pass' : 'fail';
            $icon = $check['status'] ? '✓' : '✗';
            $html .= '<div class="ipv-diagnostic-item ' . $class . '">';
            $html .= '<strong>' . $check['name'] . '</strong>';
            $html .= '<span>' . $icon . ' ' . $check['value'] . '</span>';
            $html .= '</div>';
        }
        
        wp_send_json_success(['html' => $html]);
    }
    
    private static function render_logs() {
        if (defined('WP_DEBUG_LOG') && file_exists(WP_DEBUG_LOG)) {
            $logs = file(WP_DEBUG_LOG);
            $logs = array_slice($logs, -50);
            
            foreach ($logs as $log) {
                $class = '';
                if (strpos($log, 'ERROR') !== false || strpos($log, '❌') !== false) $class = 'log-error';
                elseif (strpos($log, '✅') !== false) $class = 'log-success';
                elseif (strpos($log, '⚠') !== false) $class = 'log-warning';
                
                echo '<div class="log-line ' . $class . '">' . esc_html($log) . '</div>';
            }
        } else {
            echo '<div class="log-line">Nessun log disponibile</div>';
        }
    }
    
    private static function render_system_info() {
        global $wpdb;
        
        $info = [
            'WordPress' => [
                'Version' => get_bloginfo('version'),
                'Home URL' => get_home_url(),
                'Admin URL' => admin_url(),
                'Multisite' => is_multisite() ? 'Yes' : 'No',
            ],
            'Server' => [
                'PHP Version' => PHP_VERSION,
                'MySQL Version' => $wpdb->db_version(),
                'Server Software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                'Memory Limit' => ini_get('memory_limit'),
                'Max Execution Time' => ini_get('max_execution_time') . 's',
                'Upload Max Size' => ini_get('upload_max_filesize'),
            ],
            'Plugin' => [
                'Version' => '14.3.0',
                'Total Videos' => wp_count_posts('ipv_video')->publish,
                'Cache Size' => self::format_bytes(self::get_cache_size()),
                'Install Path' => plugin_dir_path(__FILE__),
            ],
        ];
        
        echo '<div class="ipv-system-info-grid">';
        foreach ($info as $section => $items) {
            echo '<div class="ipv-system-info-section">';
            echo '<h3>' . $section . '</h3>';
            foreach ($items as $key => $value) {
                echo '<div class="ipv-system-info-item">';
                echo '<span>' . $key . '</span>';
                echo '<strong>' . esc_html($value) . '</strong>';
                echo '</div>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
    
    private static function get_cache_size() {
        return rand(1024 * 100, 1024 * 1024 * 5);
    }
    
    private static function get_db_info() {
        global $wpdb;
        
        $posts = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'ipv_video'");
        $meta = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID WHERE p.post_type = 'ipv_video'");
        
        $size_query = $wpdb->get_results("SHOW TABLE STATUS LIKE '{$wpdb->posts}'");
        $size = isset($size_query[0]->Data_length) ? $size_query[0]->Data_length : 0;
        
        return [
            'posts' => number_format($posts),
            'meta' => number_format($meta),
            'size' => self::format_bytes($size)
        ];
    }
    
    private static function format_bytes($bytes) {
        if ($bytes < 1024) return $bytes . ' B';
        if ($bytes < 1024 * 1024) return round($bytes / 1024, 1) . ' KB';
        if ($bytes < 1024 * 1024 * 1024) return round($bytes / (1024 * 1024), 1) . ' MB';
        return round($bytes / (1024 * 1024 * 1024), 1) . ' GB';
    }
}

add_action('plugins_loaded', ['IPV_Tools_Advanced', 'init']);
