<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_Bulk')){
class IPV_Bulk {
    public static function init(){
        add_action('admin_menu', array(__CLASS__,'menu'));
        add_action('admin_post_ipv_bulk_transcripts', array(__CLASS__,'handle_bulk'));
    }
    public static function menu(){
        add_submenu_page('edit.php?post_type=ipv_video', __('Trascrizioni (Bulk)','ipv'), __('Trascrizioni (Bulk)','ipv'), 'manage_options', 'ipv-bulk-transcripts', array(__CLASS__,'render_page'));
    }
    protected static function q_missing($limit=20){
        $args = array(
            'post_type'      => 'ipv_video',
            'post_status'    => 'any',
            'posts_per_page' => $limit,
            'meta_query'     => array(
                array('key'=>'_ipv_transcript','compare'=>'NOT EXISTS')
            ),
            'fields'         => 'ids'
        );
        return get_posts($args);
    }
    public static function render_page(){
        if(!current_user_can('manage_options')) wp_die('Not allowed');
        $limit = isset($_GET['limit']) ? max(1,intval($_GET['limit'])) : 10;
        $ids = self::q_missing($limit);
        $action = wp_nonce_url(admin_url('admin-post.php?action=ipv_bulk_transcripts&limit='.$limit),'ipv_bulk_transcripts');
        echo '<div class="wrap"><h1>Trascrizioni (Bulk)</h1>';
        echo '<p>Post senza trascrizione in questo batch ('.$limit.'): <strong>'.count($ids).'</strong></p>';
        echo '<p><a class="button button-primary" href="'.esc_url($action).'">Esegui questo batch</a></p>';
        if($ids){ echo '<ol>'; foreach($ids as $id){ echo '<li>#'.intval($id).' — '.esc_html(get_the_title($id)).'</li>'; } echo '</ol>'; } else { echo '<p>Tutti i post hanno già una trascrizione.</p>'; }
        echo '</div>';
    }
    public static function handle_bulk(){
        if(!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('ipv_bulk_transcripts');
        $limit = isset($_GET['limit']) ? max(1,intval($_GET['limit'])) : 10;
        $processed=0; $success=0; $failed=0;
        $ids = self::q_missing($limit);
        foreach($ids as $post_id){
            $processed++;
            $yid=get_post_meta($post_id,'_ipv_youtube_id',true);
            if(!$yid){ $url=get_post_meta($post_id,'_ipv_youtube_url',true); if($url&&preg_match('~v=([A-Za-z0-9_-]{11})~',$url,$m)) $yid=$m[1]; }
            if(!$yid){ $failed++; continue; }
            if(class_exists('IPV_SupaData')){
                $st=get_option('ipv_settings',array()); $lang=!empty($st['supadata_lang'])?$st['supadata_lang']:'it';
                $txt=IPV_SupaData::fetch_transcript($yid,$post_id,array('lang'=>$lang,'save'=>true));
                if($txt){ $success++; } else { $failed++; }
            } else { $failed++; }
        }
        $redirect = add_query_arg(array('page'=>'ipv-bulk-transcripts','processed'=>$processed,'success'=>$success,'failed'=>$failed,'limit'=>$limit), admin_url('edit.php?post_type=ipv_video'));
        wp_safe_redirect($redirect); exit;
    }
}}
