<?php
namespace IPVCPT;
if (!defined('ABSPATH')) exit;

/**
 * SupaData API Integration - SEPARATA E COMPLETA
 */
class SupaData {
    
    const API_ENDPOINT = 'https://api.supadata.ai/v1/transcript';
    
    protected $api_key;
    protected $api_client;
    
    public function __construct($api_key = null) {
        $this->api_key = $api_key ?: $this->get_api_key();
        $this->api_client = new API_Client();
    }
    
    /**
     * Get API key from settings
     */
    protected function get_api_key() {
        $opts = Settings::get();
        return $opts['supadata_api_key'] ?? '';
    }
    
    /**
     * Fetch transcript for YouTube video
     */
    public function fetch_transcript($video_id) {
        if (empty($this->api_key)) {
            Logger::error('SupaData API key not configured');
            return null;
        }
        
        // Check cache first
        $cache_key = 'transcript_' . $video_id;
        $cached = Cache::get($cache_key);
        
        if ($cached !== false) {
            Logger::info('Transcript loaded from cache', ['video_id' => $video_id]);
            return $cached;
        }
        
        // Build request
        $youtube_url = 'https://www.youtube.com/watch?v=' . $video_id;
        
        $query_params = [
            'url' => $youtube_url,
            'text' => 'true'
        ];
        
        $full_url = self::API_ENDPOINT . '?' . http_build_query($query_params);
        
        Logger::info('Fetching transcript from SupaData', [
            'video_id' => $video_id,
            'url' => $youtube_url
        ]);
        
        // Make request
        $response = $this->api_client->request($full_url, [
            'headers' => [
                'x-api-key' => $this->api_key,
                'Accept' => 'application/json'
            ],
            'timeout' => 45
        ]);
        
        if (!$response) {
            Logger::error('SupaData request failed', ['video_id' => $video_id]);
            return null;
        }
        
        // Parse response
        $data = json_decode($response['body'], true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            Logger::error('Invalid JSON from SupaData', [
                'video_id' => $video_id,
                'error' => json_last_error_msg()
            ]);
            return null;
        }
        
        $transcript = $this->parse_response($data, $video_id);
        
        // Cache successful result
        if ($transcript) {
            Cache::set($cache_key, $transcript, Cache::TRANSCRIPT_CACHE_TIME);
            Logger::success('Transcript cached', ['video_id' => $video_id]);
        }
        
        return $transcript;
    }
    
    /**
     * Parse API response
     */
    protected function parse_response($data, $video_id) {
        // Sync response with content
        if (isset($data['content']) && is_string($data['content'])) {
            Logger::success('Transcript fetched (sync)', [
                'video_id' => $video_id,
                'length' => strlen($data['content'])
            ]);
            return $data['content'];
        }
        
        // Async response with job ID
        if (isset($data['jobId'])) {
            Logger::info('Transcript requires async processing', [
                'video_id' => $video_id,
                'job_id' => $data['jobId']
            ]);
            
            // Could implement polling here if needed
            return null;
        }
        
        // Error response
        if (isset($data['error'])) {
            Logger::warning('SupaData API error', [
                'video_id' => $video_id,
                'error' => $data['error']
            ]);
            return null;
        }
        
        // Unexpected response
        Logger::warning('Unexpected SupaData response', [
            'video_id' => $video_id,
            'response' => json_encode($data)
        ]);
        
        return null;
    }
    
    /**
     * Test API connection
     */
    public function test_connection() {
        if (empty($this->api_key)) {
            return [
                'success' => false,
                'message' => 'API key mancante'
            ];
        }
        
        $test_url = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'; // Rick Astley test
        
        $query_params = [
            'url' => $test_url,
            'text' => 'true'
        ];
        
        $full_url = self::API_ENDPOINT . '?' . http_build_query($query_params);
        
        $response = $this->api_client->request($full_url, [
            'headers' => [
                'x-api-key' => $this->api_key,
                'Accept' => 'application/json'
            ],
            'timeout' => 15
        ]);
        
        if (!$response) {
            return [
                'success' => false,
                'message' => 'Connessione fallita o timeout'
            ];
        }
        
        $data = json_decode($response['body'], true);
        
        // Any valid response means API key works
        if (isset($data['content']) || isset($data['jobId']) || isset($data['error'])) {
            return [
                'success' => true,
                'message' => 'Connesso a SupaData v1! API key valida ✅',
                'details' => $data
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Risposta API non valida'
        ];
    }
    
    /**
     * Get transcript statistics
     */
    public function get_stats($transcript) {
        if (empty($transcript)) {
            return [
                'characters' => 0,
                'words' => 0,
                'lines' => 0
            ];
        }
        
        $lines = explode("\n", trim($transcript));
        $lines = array_filter($lines, function($line) {
            return !empty(trim($line));
        });
        
        return [
            'characters' => strlen($transcript),
            'words' => str_word_count($transcript),
            'lines' => count($lines)
        ];
    }
    
    /**
     * Check if transcript meets minimum requirements
     */
    public function meets_requirements($transcript, $min_lines = 10) {
        $stats = $this->get_stats($transcript);
        return $stats['lines'] >= $min_lines;
    }
    
    /**
     * Format transcript for display
     */
    public function format_for_display($transcript, $max_length = 500) {
        if (empty($transcript)) {
            return '';
        }
        
        if (strlen($transcript) <= $max_length) {
            return $transcript;
        }
        
        return substr($transcript, 0, $max_length) . '...';
    }
}