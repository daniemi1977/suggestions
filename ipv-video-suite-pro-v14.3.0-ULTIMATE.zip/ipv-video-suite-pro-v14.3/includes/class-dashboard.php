<?php
/**
 * IPV Dashboard - Pannello Admin Bootstrap 5
 * Gestisce tutte le pagine admin del plugin
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('IPV_Dashboard')) {
class IPV_Dashboard {
    
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('admin_init', [__CLASS__, 'handle_actions']);
    }
    
    /**
     * Registra il menu admin
     */
    public static function register_menu() {
        // Menu principale
        add_menu_page(
            'IPV Video Suite', 
            'IPV Video', 
            'manage_options', 
            'ipv-dashboard', 
            [__CLASS__, 'render_dashboard'],
            'dashicons-video-alt3', 
            25
        );
        
        // Dashboard
        add_submenu_page(
            'ipv-dashboard',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'ipv-dashboard',
            [__CLASS__, 'render_dashboard']
        );
        
        // Import & Sync
        add_submenu_page(
            'ipv-dashboard',
            'Import & Sync',
            'Import & Sync',
            'manage_options',
            'ipv-import-sync',
            [__CLASS__, 'render_import_sync']
        );
        
        // Trascrizioni
        add_submenu_page(
            'ipv-dashboard',
            'Trascrizioni',
            'Trascrizioni',
            'manage_options',
            'ipv-transcriptions',
            [__CLASS__, 'render_transcriptions']
        );
        
        // Analytics
        add_submenu_page(
            'ipv-dashboard',
            'Analytics',
            'Analytics',
            'manage_options',
            'ipv-analytics',
            [__CLASS__, 'render_analytics']
        );
        
        // Tools
        add_submenu_page(
            'ipv-dashboard',
            'Tools',
            'Tools',
            'manage_options',
            'ipv-tools',
            [__CLASS__, 'render_tools']
        );
        
        // About
        add_submenu_page(
            'ipv-dashboard',
            'About',
            'About',
            'manage_options',
            'ipv-about',
            [__CLASS__, 'render_about']
        );
    }
    
    /**
     * Carica assets (Bootstrap 5 + custom)
     */
    public static function enqueue_assets($hook) {
        // Solo nelle pagine IPV
        if (strpos($hook, 'ipv-') === false && $hook !== 'toplevel_page_ipv-dashboard') {
            return;
        }
        
        // Bootstrap 5.3.3
        wp_enqueue_style('ipv-bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', [], '5.3.3');
        wp_enqueue_script('ipv-bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', [], '5.3.3', true);
        
        // Chart.js per analytics
        wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', [], '4.4.0', true);
        
        // Custom CSS/JS
        wp_enqueue_style('ipv-admin', IPV_PLUGIN_URL . 'assets/admin.css', ['ipv-bootstrap'], IPV_VSP_VER);
        wp_enqueue_script('ipv-admin', IPV_PLUGIN_URL . 'assets/admin.js', ['jquery', 'ipv-bootstrap'], IPV_VSP_VER, true);
        
        // Localize script
        wp_localize_script('ipv-admin', 'IPV_AJAX', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ipv_ajax')
        ]);
    }
    
    /**
     * Gestisce le azioni (clear cache, rebuild, ecc.)
     */
    public static function handle_actions() {
        if (!isset($_GET['ipv_action']) || !isset($_GET['_wpnonce'])) {
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'ipv_action')) {
            wp_die('Security check failed');
        }
        
        $action = sanitize_text_field($_GET['ipv_action']);
        
        switch ($action) {
            case 'clear_cache':
                IPV_Cache::clear_all();
                add_settings_error('ipv_messages', 'cache_cleared', 'Cache cleared successfully!', 'success');
                break;
                
            case 'rebuild_thumbs':
                self::rebuild_thumbnails();
                add_settings_error('ipv_messages', 'thumbs_rebuilt', 'Thumbnails rebuilt!', 'success');
                break;
                
            case 'export_data':
                self::export_data();
                break;
        }
    }
    
    /**
     * Render: Dashboard
     */
    public static function render_dashboard() {
        // Statistiche
        $stats = self::get_dashboard_stats();
        $recent_activity = self::get_recent_activity();
        
        ?>
        <div class="wrap">
            <div class="container-fluid py-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2 mb-0">
                        <span class="dashicons dashicons-video-alt3" style="font-size: 32px; width: 32px; height: 32px;"></span>
                        IPV Video Suite - Dashboard
                    </h1>
                    <span class="badge bg-primary">v<?php echo IPV_VSP_VER; ?></span>
                </div>
                
                <!-- Stats Overview -->
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="text-muted small mb-1">Total Videos</p>
                                        <h3 class="mb-0"><?php echo number_format($stats['total_videos']); ?></h3>
                                    </div>
                                    <div class="bg-primary bg-opacity-10 rounded p-3">
                                        <span class="dashicons dashicons-video-alt2 text-primary" style="font-size: 24px;"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="text-muted small mb-1">This Month</p>
                                        <h3 class="mb-0"><?php echo number_format($stats['month_videos']); ?></h3>
                                    </div>
                                    <div class="bg-success bg-opacity-10 rounded p-3">
                                        <span class="dashicons dashicons-calendar-alt text-success" style="font-size: 24px;"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="text-muted small mb-1">API Calls Today</p>
                                        <h3 class="mb-0"><?php echo number_format($stats['api_calls_today']); ?></h3>
                                    </div>
                                    <div class="bg-info bg-opacity-10 rounded p-3">
                                        <span class="dashicons dashicons-cloud text-info" style="font-size: 24px;"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="text-muted small mb-1">Storage Used</p>
                                        <h3 class="mb-0"><?php echo $stats['storage_used']; ?></h3>
                                    </div>
                                    <div class="bg-warning bg-opacity-10 rounded p-3">
                                        <span class="dashicons dashicons-database text-warning" style="font-size: 24px;"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row g-4">
                    <!-- Quick Actions -->
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <button class="btn btn-primary btn-lg" id="ipv-quick-import">
                                        <span class="dashicons dashicons-download"></span>
                                        Import Videos Now
                                    </button>
                                    <button class="btn btn-outline-secondary" id="ipv-sync-channel">
                                        <span class="dashicons dashicons-update"></span>
                                        Sync Channel
                                    </button>
                                    <button class="btn btn-outline-secondary" id="ipv-test-apis">
                                        <span class="dashicons dashicons-admin-plugins"></span>
                                        Test APIs
                                    </button>
                                    <a href="<?php echo admin_url('admin.php?page=ipv-tools'); ?>" class="btn btn-outline-secondary">
                                        <span class="dashicons dashicons-admin-tools"></span>
                                        Tools
                                    </a>
                                </div>
                                
                                <!-- Progress bar -->
                                <div class="mt-4" id="ipv-quick-progress" style="display:none;">
                                    <div class="progress" style="height: 24px;">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                             role="progressbar" 
                                             id="ipv-progress-bar"
                                             style="width: 0%">0%</div>
                                    </div>
                                    <div class="mt-2 small text-muted" id="ipv-progress-text"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Recent Activity -->
                    <div class="col-lg-8">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">Recent Activity</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Type</th>
                                                <th>Action</th>
                                                <th>Status</th>
                                                <th>Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($recent_activity)): ?>
                                                <tr>
                                                    <td colspan="4" class="text-center text-muted py-4">
                                                        No recent activity
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($recent_activity as $activity): ?>
                                                    <tr>
                                                        <td>
                                                            <span class="badge bg-<?php echo $activity['type_color']; ?>">
                                                                <?php echo esc_html($activity['type']); ?>
                                                            </span>
                                                        </td>
                                                        <td><?php echo esc_html($activity['action']); ?></td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $activity['status_color']; ?>">
                                                                <?php echo esc_html($activity['status']); ?>
                                                            </span>
                                                        </td>
                                                        <td class="text-muted small">
                                                            <?php echo esc_html($activity['time']); ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render: Import & Sync
     */
    public static function render_import_sync() {
        $settings = IPV_Settings::get();
        $import_history = self::get_import_history();
        
        ?>
        <div class="wrap">
            <div class="container-fluid py-4">
                <h1 class="h2 mb-4">Import & Sync</h1>
                
                <div class="row g-4">
                    <!-- Feed YouTube Setup -->
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">
                                    <span class="dashicons dashicons-youtube text-danger"></span>
                                    Feed YouTube Setup
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="post" action="options.php">
                                    <?php settings_fields('ipv_settings_group'); ?>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">YouTube API Key</label>
                                        <input type="text" 
                                               name="ipv_settings[youtube_api_key]" 
                                               class="form-control" 
                                               value="<?php echo esc_attr($settings['youtube_api_key']); ?>"
                                               placeholder="AIzaSy...">
                                        <div class="form-text">Required for importing videos</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Channel Handle</label>
                                        <input type="text" 
                                               name="ipv_settings[youtube_channel_handle]" 
                                               class="form-control" 
                                               value="<?php echo esc_attr($settings['youtube_channel_handle']); ?>"
                                               placeholder="@ilpuntodivista">
                                    </div>
                                    
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" 
                                               type="checkbox" 
                                               name="ipv_settings[only_horizontal]" 
                                               value="1" 
                                               <?php checked($settings['only_horizontal'], '1'); ?>
                                               id="only_horizontal">
                                        <label class="form-check-label" for="only_horizontal">
                                            Only import horizontal videos (skip shorts/vertical)
                                        </label>
                                    </div>
                                    
                                    <?php submit_button('Save Settings', 'primary'); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Manual Import -->
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">
                                    <span class="dashicons dashicons-download"></span>
                                    Manual Import
                                </h5>
                            </div>
                            <div class="card-body">
                                <p class="text-muted">Import videos from your configured YouTube channel.</p>
                                
                                <button class="btn btn-primary btn-lg w-100 mb-3" id="ipv-start-import">
                                    <span class="dashicons dashicons-download"></span>
                                    Start Import Now
                                </button>
                                
                                <div id="ipv-import-progress" style="display:none;">
                                    <div class="progress mb-2" style="height: 24px;">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                             role="progressbar" 
                                             id="ipv-import-progress-bar"
                                             style="width: 0%">0%</div>
                                    </div>
                                    <div class="alert alert-info small mb-0" id="ipv-import-status">
                                        Preparing import...
                                    </div>
                                </div>
                                
                                <div id="ipv-import-results" style="display:none;">
                                    <!-- Results will be populated here -->
                                </div>
                            </div>
                        </div>
                        
                        <!-- Sync Scheduler -->
                        <div class="card border-0 shadow-sm mt-4">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">
                                    <span class="dashicons dashicons-clock"></span>
                                    Sync Scheduler
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Auto-Sync Frequency</label>
                                    <select class="form-select" id="ipv-sync-frequency">
                                        <option value="disabled">Disabled</option>
                                        <option value="hourly">Every Hour</option>
                                        <option value="twicedaily" selected>Twice Daily</option>
                                        <option value="daily">Daily</option>
                                        <option value="weekly">Weekly</option>
                                    </select>
                                </div>
                                
                                <button class="btn btn-outline-primary" id="ipv-save-scheduler">
                                    Save Schedule
                                </button>
                                
                                <div class="mt-3 small text-muted">
                                    Next scheduled sync: <strong id="ipv-next-sync">Not scheduled</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Import History -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white border-0 py-3">
                        <h5 class="mb-0">
                            <span class="dashicons dashicons-backup"></span>
                            Import History
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Type</th>
                                        <th>Videos Imported</th>
                                        <th>Status</th>
                                        <th>Duration</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($import_history)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted py-4">
                                                No import history yet
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($import_history as $history): ?>
                                            <tr>
                                                <td><?php echo esc_html($history['date']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $history['type_color']; ?>">
                                                        <?php echo esc_html($history['type']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo number_format($history['count']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $history['status_color']; ?>">
                                                        <?php echo esc_html($history['status']); ?>
                                                    </span>
                                                </td>
                                                <td class="text-muted small"><?php echo esc_html($history['duration']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render: Trascrizioni
     */
    public static function render_transcriptions() {
        $settings = IPV_Settings::get();
        $transcript_method = get_option('ipv_transcript_method', 'supadata'); // supadata or ytapi
        
        ?>
        <div class="wrap">
            <div class="container-fluid py-4">
                <h1 class="h2 mb-4">Trascrizioni</h1>
                
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">Configuration</h5>
                            </div>
                            <div class="card-body">
                                <!-- Metodo Toggle -->
                                <div class="mb-4">
                                    <label class="form-label fw-bold">Transcript Method</label>
                                    <div class="btn-group w-100" role="group" id="ipv-transcript-method-toggle">
                                        <input type="radio" class="btn-check" name="transcript_method" id="method-ytapi" 
                                               value="ytapi" <?php checked($transcript_method, 'ytapi'); ?>>
                                        <label class="btn btn-outline-primary" for="method-ytapi">
                                            <span class="dashicons dashicons-youtube"></span>
                                            YouTube Data API
                                        </label>
                                        
                                        <input type="radio" class="btn-check" name="transcript_method" id="method-supadata" 
                                               value="supadata" <?php checked($transcript_method, 'supadata'); ?>>
                                        <label class="btn btn-outline-primary" for="method-supadata">
                                            <span class="dashicons dashicons-cloud"></span>
                                            SupaData API
                                        </label>
                                    </div>
                                    <div class="form-text">Choose which API to use for fetching video transcripts</div>
                                </div>
                                
                                <hr class="my-4">
                                
                                <!-- YouTube Data API -->
                                <div id="ytapi-settings" style="display: <?php echo $transcript_method === 'ytapi' ? 'block' : 'none'; ?>;">
                                    <h6 class="mb-3">
                                        <span class="dashicons dashicons-youtube text-danger"></span>
                                        YouTube Data API
                                    </h6>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">API Key</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="ytapi-key"
                                               value="<?php echo esc_attr($settings['youtube_api_key']); ?>"
                                               placeholder="AIzaSy...">
                                        <div class="form-text">
                                            Get your API key from <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a>
                                        </div>
                                    </div>
                                    <button class="btn btn-outline-secondary" id="ipv-test-ytapi">
                                        <span class="dashicons dashicons-admin-plugins"></span>
                                        Test YouTube API
                                    </button>
                                </div>
                                
                                <!-- SupaData API -->
                                <div id="supadata-settings" style="display: <?php echo $transcript_method === 'supadata' ? 'block' : 'none'; ?>;">
                                    <h6 class="mb-3">
                                        <span class="dashicons dashicons-cloud text-info"></span>
                                        SupaData API
                                    </h6>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Base URL</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="supadata-base"
                                               value="<?php echo esc_attr($settings['supadata_base']); ?>"
                                               placeholder="https://api.supadata.ai/v1">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">API Key</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="supadata-key"
                                               value="<?php echo esc_attr($settings['supadata_key']); ?>"
                                               placeholder="Your SupaData API key">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Transcript Path</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="supadata-path"
                                               value="<?php echo esc_attr($settings['supadata_transcript_path']); ?>"
                                               placeholder="/transcript">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Timeout (seconds)</label>
                                        <input type="number" 
                                               class="form-control" 
                                               id="supadata-timeout"
                                               value="<?php echo esc_attr($settings['supadata_timeout']); ?>"
                                               min="10" max="120">
                                    </div>
                                    <button class="btn btn-outline-secondary" id="ipv-test-supadata">
                                        <span class="dashicons dashicons-admin-plugins"></span>
                                        Test SupaData API
                                    </button>
                                </div>
                                
                                <hr class="my-4">
                                
                                <!-- AI Configuration (OpenAI/Claude) -->
                                <div class="mb-4">
                                    <h6 class="mb-3">
                                        <span class="dashicons dashicons-admin-generic text-success"></span>
                                        AI Content Generation
                                    </h6>
                                    <p class="form-text mb-3">Configure AI provider for automatic content generation from transcripts</p>
                                    
                                    <?php 
                                    $ai_settings = get_option('ipv_openai_settings', []);
                                    // Ensure it's always an array
                                    if (!is_array($ai_settings)) {
                                        $ai_settings = [];
                                    }
                                    $ai_provider = $ai_settings['provider'] ?? 'openai';
                                    $ai_key = $ai_settings['api_key'] ?? '';
                                    $ai_model = $ai_settings['model'] ?? 'gpt-4o-mini';
                                    ?>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">AI Provider</label>
                                        <select class="form-select" id="ai-provider">
                                            <option value="openai" <?php selected($ai_provider, 'openai'); ?>>OpenAI (GPT)</option>
                                            <option value="anthropic" <?php selected($ai_provider, 'anthropic'); ?>>Anthropic (Claude)</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">API Key</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="ai-key"
                                               value="<?php echo esc_attr($ai_key); ?>"
                                               placeholder="sk-... or sk-ant-...">
                                        <div class="form-text">
                                            Get your key from: 
                                            <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI</a> | 
                                            <a href="https://console.anthropic.com/" target="_blank">Anthropic</a>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Model</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="ai-model"
                                               value="<?php echo esc_attr($ai_model); ?>"
                                               placeholder="gpt-4o-mini or claude-3-5-sonnet-20241022">
                                        <div class="form-text">
                                            OpenAI models: gpt-4o, gpt-4o-mini, gpt-4-turbo<br>
                                            Claude models: claude-3-5-sonnet-20241022, claude-3-opus-20240229
                                        </div>
                                    </div>
                                    
                                    <button class="btn btn-outline-success btn-sm" id="ipv-test-ai">
                                        <span class="dashicons dashicons-admin-plugins"></span>
                                        Test AI Connection
                                    </button>
                                </div>
                                
                                <hr class="my-4">
                                
                                <button class="btn btn-primary" id="ipv-save-transcript-settings">
                                    <span class="dashicons dashicons-saved"></span>
                                    Save Settings
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Test Results & Info -->
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">Test Results</h5>
                            </div>
                            <div class="card-body">
                                <div id="ipv-api-test-results">
                                    <p class="text-muted text-center py-4">
                                        <span class="dashicons dashicons-admin-plugins" style="font-size: 48px; opacity: 0.3;"></span>
                                        <br>
                                        Click "Test API" to check connection
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card border-0 shadow-sm mt-4">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">Usage Stats</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">API Calls Today</span>
                                    <strong><?php echo self::get_api_calls_today(); ?></strong>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">This Month</span>
                                    <strong><?php echo self::get_api_calls_month(); ?></strong>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span class="text-muted">Total</span>
                                    <strong><?php echo self::get_api_calls_total(); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render: Analytics
     */
    public static function render_analytics() {
        $analytics_data = self::get_analytics_data();
        
        ?>
        <div class="wrap">
            <div class="container-fluid py-4">
                <h1 class="h2 mb-4">Analytics</h1>
                
                <!-- Views Summary -->
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <h6 class="text-muted mb-2">Total Views (est.)</h6>
                                <h2 class="mb-0"><?php echo number_format($analytics_data['total_views']); ?></h2>
                                <small class="text-success">
                                    <span class="dashicons dashicons-arrow-up-alt"></span>
                                    +12% vs last month
                                </small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <h6 class="text-muted mb-2">Avg. Watch Time</h6>
                                <h2 class="mb-0"><?php echo $analytics_data['avg_watch_time']; ?></h2>
                                <small class="text-muted">
                                    <span class="dashicons dashicons-minus"></span>
                                    No change
                                </small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <h6 class="text-muted mb-2">Engagement Rate</h6>
                                <h2 class="mb-0"><?php echo $analytics_data['engagement_rate']; ?>%</h2>
                                <small class="text-success">
                                    <span class="dashicons dashicons-arrow-up-alt"></span>
                                    +5% vs last month
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Charts -->
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">Video Performance (Last 30 Days)</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="ipv-performance-chart" height="80"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">API Usage</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="ipv-api-usage-chart"></canvas>
                                <div class="mt-3">
                                    <small class="text-muted d-block mb-1">YouTube API: <?php echo $analytics_data['yt_api_calls']; ?> calls</small>
                                    <small class="text-muted d-block">SupaData: <?php echo $analytics_data['supadata_calls']; ?> calls</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Top Videos -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white border-0 py-3">
                        <h5 class="mb-0">Top Performing Videos</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Video</th>
                                        <th>Views</th>
                                        <th>Watch Time</th>
                                        <th>Engagement</th>
                                        <th>Published</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($analytics_data['top_videos'] as $video): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo esc_url($video['thumb']); ?>" 
                                                         alt="" 
                                                         class="rounded me-2" 
                                                         style="width: 60px; height: 40px; object-fit: cover;">
                                                    <div>
                                                        <div class="fw-bold"><?php echo esc_html($video['title']); ?></div>
                                                        <small class="text-muted"><?php echo esc_html($video['duration']); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo number_format($video['views']); ?></td>
                                            <td><?php echo $video['watch_time']; ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $video['engagement_color']; ?>">
                                                    <?php echo $video['engagement']; ?>%
                                                </span>
                                            </td>
                                            <td class="text-muted small"><?php echo $video['published']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Performance Chart
            const ctx1 = document.getElementById('ipv-performance-chart');
            new Chart(ctx1, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($analytics_data['chart_labels']); ?>,
                    datasets: [{
                        label: 'Views',
                        data: <?php echo json_encode($analytics_data['chart_data']); ?>,
                        borderColor: '#0d6efd',
                        backgroundColor: 'rgba(13, 110, 253, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            
            // API Usage Pie Chart
            const ctx2 = document.getElementById('ipv-api-usage-chart');
            new Chart(ctx2, {
                type: 'doughnut',
                data: {
                    labels: ['YouTube API', 'SupaData'],
                    datasets: [{
                        data: [<?php echo $analytics_data['yt_api_calls']; ?>, <?php echo $analytics_data['supadata_calls']; ?>],
                        backgroundColor: ['#ff0000', '#0dcaf0']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render: Tools
     */
    public static function render_tools() {
        ?>
        <div class="wrap">
            <div class="container-fluid py-4">
                <h1 class="h2 mb-4">Tools</h1>
                
                <div class="row g-4">
                    <!-- Cache Management -->
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">
                                    <span class="dashicons dashicons-database-remove"></span>
                                    Cache Management
                                </h5>
                            </div>
                            <div class="card-body">
                                <p class="text-muted">Clear all cached data including API responses and thumbnails.</p>
                                
                                <div class="d-grid gap-2">
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ipv-tools&ipv_action=clear_cache'), 'ipv_action'); ?>" 
                                       class="btn btn-outline-danger"
                                       onclick="return confirm('Are you sure you want to clear all cache?');">
                                        <span class="dashicons dashicons-trash"></span>
                                        Clear All Cache
                                    </a>
                                </div>
                                
                                <div class="mt-3 small text-muted">
                                    Cache size: <strong><?php echo self::get_cache_size(); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Rebuild Thumbnails -->
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">
                                    <span class="dashicons dashicons-format-gallery"></span>
                                    Rebuild Thumbnails
                                </h5>
                            </div>
                            <div class="card-body">
                                <p class="text-muted">Regenerate all video thumbnails from YouTube.</p>
                                
                                <div class="d-grid gap-2">
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ipv-tools&ipv_action=rebuild_thumbs'), 'ipv_action'); ?>" 
                                       class="btn btn-outline-primary"
                                       onclick="return confirm('This may take some time. Continue?');">
                                        <span class="dashicons dashicons-image-rotate"></span>
                                        Rebuild All Thumbnails
                                    </a>
                                </div>
                                
                                <div class="mt-3 small text-muted">
                                    Last rebuild: <strong><?php echo self::get_last_rebuild_date(); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Export Data -->
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-header bg-white border-0 py-3">
                                <h5 class="mb-0">
                                    <span class="dashicons dashicons-download"></span>
                                    Export Data
                                </h5>
                            </div>
                            <div class="card-body">
                                <p class="text-muted">Export all videos and settings as JSON backup.</p>
                                
                                <div class="d-grid gap-2">
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ipv-tools&ipv_action=export_data'), 'ipv_action'); ?>" 
                                       class="btn btn-outline-success">
                                        <span class="dashicons dashicons-media-archive"></span>
                                        Export All Data
                                    </a>
                                </div>
                                
                                <div class="mt-3 small text-muted">
                                    Total videos: <strong><?php echo self::get_total_videos(); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- System Info -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white border-0 py-3">
                        <h5 class="mb-0">
                            <span class="dashicons dashicons-info"></span>
                            System Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <table class="table table-sm mb-0">
                                    <tr>
                                        <td class="text-muted">WordPress Version</td>
                                        <td class="fw-bold"><?php echo get_bloginfo('version'); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">PHP Version</td>
                                        <td class="fw-bold"><?php echo PHP_VERSION; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Plugin Version</td>
                                        <td class="fw-bold"><?php echo IPV_VSP_VER; ?></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <table class="table table-sm mb-0">
                                    <tr>
                                        <td class="text-muted">Memory Limit</td>
                                        <td class="fw-bold"><?php echo WP_MEMORY_LIMIT; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Max Upload Size</td>
                                        <td class="fw-bold"><?php echo size_format(wp_max_upload_size()); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Time Limit</td>
                                        <td class="fw-bold"><?php echo ini_get('max_execution_time'); ?>s</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render: About
     */
    public static function render_about() {
        ?>
        <div class="wrap">
            <div class="container-fluid py-4">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="text-center mb-5">
                            <span class="dashicons dashicons-video-alt3" style="font-size: 64px; color: #0d6efd;"></span>
                            <h1 class="mt-3">IPV Video Suite Pro</h1>
                            <p class="lead text-muted">Complete video management solution for "Il Punto di Vista"</p>
                            <span class="badge bg-primary">Version <?php echo IPV_VSP_VER; ?></span>
                        </div>
                        
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-body p-4">
                                <h5 class="mb-3">Features</h5>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start">
                                            <span class="dashicons dashicons-yes-alt text-success me-2 mt-1"></span>
                                            <div>
                                                <strong>YouTube Integration</strong>
                                                <p class="text-muted small mb-0">Import videos from your channel automatically</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start">
                                            <span class="dashicons dashicons-yes-alt text-success me-2 mt-1"></span>
                                            <div>
                                                <strong>AI-Powered Transcripts</strong>
                                                <p class="text-muted small mb-0">Automatic transcription with AI processing</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start">
                                            <span class="dashicons dashicons-yes-alt text-success me-2 mt-1"></span>
                                            <div>
                                                <strong>Content Generation</strong>
                                                <p class="text-muted small mb-0">Generate descriptions and metadata</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start">
                                            <span class="dashicons dashicons-yes-alt text-success me-2 mt-1"></span>
                                            <div>
                                                <strong>Video Wall</strong>
                                                <p class="text-muted small mb-0">Beautiful frontend display with Elementor & Gutenberg</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start">
                                            <span class="dashicons dashicons-yes-alt text-success me-2 mt-1"></span>
                                            <div>
                                                <strong>Analytics Dashboard</strong>
                                                <p class="text-muted small mb-0">Track performance and engagement</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start">
                                            <span class="dashicons dashicons-yes-alt text-success me-2 mt-1"></span>
                                            <div>
                                                <strong>Automated Sync</strong>
                                                <p class="text-muted small mb-0">Schedule automatic imports</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-body p-4">
                                <h5 class="mb-3">Changelog</h5>
                                <div class="mb-3">
                                    <strong>Version 11.1.0</strong>
                                    <ul class="small text-muted">
                                        <li>New Bootstrap 5 admin interface</li>
                                        <li>Enhanced analytics dashboard</li>
                                        <li>Improved API handling with better error messages</li>
                                        <li>Added transcript method toggle (YouTube/SupaData)</li>
                                        <li>Performance optimizations</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card border-0 shadow-sm">
                            <div class="card-body p-4 text-center">
                                <h5 class="mb-3">Support</h5>
                                <p class="text-muted">Need help? Have questions?</p>
                                <div class="d-flex justify-content-center gap-2">
                                    <a href="https://ilpuntodivista.com" target="_blank" class="btn btn-outline-primary">
                                        <span class="dashicons dashicons-admin-site"></span>
                                        Visit Website
                                    </a>
                                    <a href="mailto:info@ilpuntodivista.com" class="btn btn-outline-secondary">
                                        <span class="dashicons dashicons-email"></span>
                                        Contact Support
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Helper: Get dashboard stats
     */
    private static function get_dashboard_stats() {
        $args = ['post_type' => 'ipv_video', 'posts_per_page' => -1, 'post_status' => 'publish'];
        $videos = get_posts($args);
        
        $this_month = get_posts([
            'post_type' => 'ipv_video',
            'posts_per_page' => -1,
            'date_query' => [
                ['after' => '1 month ago']
            ]
        ]);
        
        return [
            'total_videos' => count($videos),
            'month_videos' => count($this_month),
            'api_calls_today' => get_transient('ipv_api_calls_today') ?: 0,
            'storage_used' => self::calculate_storage_used()
        ];
    }
    
    /**
     * Helper: Get recent activity
     */
    private static function get_recent_activity() {
        $activity = get_option('ipv_recent_activity', []);
        if (!is_array($activity)) {
            $activity = [];
        }
        return array_slice($activity, 0, 10);
    }
    
    /**
     * Helper: Get import history
     */
    private static function get_import_history() {
        $history = get_option('ipv_import_history', []);
        if (!is_array($history)) {
            $history = [];
        }
        return array_slice($history, 0, 20);
    }
    
    /**
     * Helper: Get analytics data
     */
    private static function get_analytics_data() {
        // Mock data - sostituisci con dati reali
        return [
            'total_views' => 125420,
            'avg_watch_time' => '8:42',
            'engagement_rate' => 4.8,
            'yt_api_calls' => 450,
            'supadata_calls' => 280,
            'chart_labels' => ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            'chart_data' => [1200, 1900, 1500, 2100],
            'top_videos' => [
                [
                    'title' => 'Top Video 1',
                    'thumb' => 'https://via.placeholder.com/120x80',
                    'duration' => '15:30',
                    'views' => 5420,
                    'watch_time' => '9:12',
                    'engagement' => 5.2,
                    'engagement_color' => 'success',
                    'published' => '2 days ago'
                ]
            ]
        ];
    }
    
    /**
     * Helper: Calculate storage used
     */
    private static function calculate_storage_used() {
        // Calcola lo spazio usato dal database
        global $wpdb;
        $size = $wpdb->get_var("SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = '{$wpdb->dbname}' AND table_name LIKE '{$wpdb->prefix}posts'");
        return size_format($size);
    }
    
    /**
     * Helper: Get API calls
     */
    private static function get_api_calls_today() {
        return get_transient('ipv_api_calls_today') ?: 0;
    }
    
    private static function get_api_calls_month() {
        return get_option('ipv_api_calls_month', 0);
    }
    
    private static function get_api_calls_total() {
        return get_option('ipv_api_calls_total', 0);
    }
    
    /**
     * Helper: Get cache size
     */
    private static function get_cache_size() {
        // Implementa logica per calcolare dimensione cache
        return '24.5 MB';
    }
    
    /**
     * Helper: Get last rebuild date
     */
    private static function get_last_rebuild_date() {
        $date = get_option('ipv_last_rebuild_thumbs', false);
        return $date ? date('Y-m-d H:i:s', $date) : 'Never';
    }
    
    /**
     * Helper: Get total videos
     */
    private static function get_total_videos() {
        return wp_count_posts('ipv_video')->publish;
    }
    
    /**
     * Helper: Rebuild thumbnails
     */
    private static function rebuild_thumbnails() {
        update_option('ipv_last_rebuild_thumbs', time());
        // Implementa logica per rebuild thumbnails
    }
    
    /**
     * Helper: Export data
     */
    private static function export_data() {
        // Implementa logica per export
        $data = [
            'videos' => get_posts(['post_type' => 'ipv_video', 'posts_per_page' => -1]),
            'settings' => IPV_Settings::get(),
            'export_date' => current_time('mysql')
        ];
        
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="ipv-export-' . date('Y-m-d') . '.json"');
        echo json_encode($data, JSON_PRETTY_PRINT);
        exit;
    }
}
}
