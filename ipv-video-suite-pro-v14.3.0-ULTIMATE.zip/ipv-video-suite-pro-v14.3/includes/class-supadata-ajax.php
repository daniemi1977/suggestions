<?php
/**
 * IPV SupaData AJAX Handlers
 * 
 * Gestisce tutte le richieste AJAX per la dashboard SupaData
 */

if (!defined('ABSPATH')) exit;

class IPV_SupaData_AJAX {

    public static function init() {
        // Test connessione
        add_action('wp_ajax_ipv_test_supadata_connection', [__CLASS__, 'test_connection']);
        
        // Valida URL
        add_action('wp_ajax_ipv_validate_supadata_url', [__CLASS__, 'validate_url']);
        
        // Fetch transcript
        add_action('wp_ajax_ipv_fetch_supadata_transcript', [__CLASS__, 'fetch_transcript']);
        
        // Stima crediti
        add_action('wp_ajax_ipv_estimate_supadata_credits', [__CLASS__, 'estimate_credits']);
        
        // Get config
        add_action('wp_ajax_ipv_get_supadata_config', [__CLASS__, 'get_config']);
    }

    /**
     * AJAX: Test connessione SupaData
     */
    public static function test_connection() {
        check_ajax_referer('ipv_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        try {
            $result = IPV_SupaData::test_connection();
            wp_send_json_success($result);
        } catch (Exception $e) {
            wp_send_json_error('Errore: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Valida URL
     */
    public static function validate_url() {
        check_ajax_referer('ipv_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        $url = isset($_POST['url']) ? sanitize_text_field($_POST['url']) : '';

        if (empty($url)) {
            wp_send_json_error('URL mancante');
        }

        try {
            $result = IPV_SupaData::validate_url($url);
            wp_send_json_success($result);
        } catch (Exception $e) {
            wp_send_json_error('Errore: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Fetch transcript
     */
    public static function fetch_transcript() {
        check_ajax_referer('ipv_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        $video_id = isset($_POST['video_id']) ? sanitize_text_field($_POST['video_id']) : '';
        $mode = isset($_POST['mode']) ? sanitize_text_field($_POST['mode']) : 'auto';
        $lang = isset($_POST['lang']) ? sanitize_text_field($_POST['lang']) : '';

        if (empty($video_id)) {
            wp_send_json_error('Video ID/URL mancante');
        }

        // Valida mode
        if (!in_array($mode, ['auto', 'native', 'generate'])) {
            $mode = 'auto';
        }

        // Prepara opzioni
        $options = [
            'mode' => $mode,
            'text' => true
        ];

        if (!empty($lang)) {
            $options['lang'] = $lang;
        }

        IPV_Logger::log("SupaData AJAX: Fetching transcript for {$video_id} (mode: {$mode})", 'info');

        try {
            // Se $video_id è un URL completo, estraiamo l'ID YouTube
            $youtube_id = $video_id;
            
            if (filter_var($video_id, FILTER_VALIDATE_URL)) {
                // Estrai l'ID YouTube dall'URL se possibile
                if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/', $video_id, $matches)) {
                    $youtube_id = $matches[1];
                }
            }
            
            IPV_Logger::log("SupaData AJAX: Fetching transcript for YouTube ID: {$youtube_id}", 'info');
            
            // Fetch transcript usando il nuovo parametro
            $result = IPV_SupaData::fetch_transcript($youtube_id, null, $options);
            
            if ($result) {
                wp_send_json_success($result);
            } else {
                wp_send_json_error('Transcript non trovato. Controlla i log per dettagli.');
            }
        } catch (Exception $e) {
            IPV_Logger::log('SupaData AJAX error: ' . $e->getMessage(), 'error');
            wp_send_json_error('Errore: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Stima crediti
     */
    public static function estimate_credits() {
        check_ajax_referer('ipv_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        $mode = isset($_POST['mode']) ? sanitize_text_field($_POST['mode']) : 'auto';
        $duration = isset($_POST['duration']) ? intval($_POST['duration']) : 10;

        // Valida mode
        if (!in_array($mode, ['auto', 'native', 'generate'])) {
            $mode = 'auto';
        }

        try {
            $credits = IPV_SupaData::estimate_credits($mode, $duration);
            
            // Genera spiegazione
            $explanation = '';
            switch ($mode) {
                case 'native':
                    $explanation = 'Native transcript costa sempre 1 credito, indipendentemente dalla durata';
                    break;
                case 'generate':
                    $explanation = "Generated transcript costa 2 crediti per minuto: {$duration} min × 2 = {$credits} crediti";
                    break;
                case 'auto':
                    $explanation = "Mode auto: se trova native transcript = 1 credito, altrimenti genera = " . ($duration * 2) . " crediti";
                    break;
            }

            wp_send_json_success([
                'credits' => $credits,
                'explanation' => $explanation,
                'mode' => $mode,
                'duration' => $duration
            ]);
        } catch (Exception $e) {
            wp_send_json_error('Errore: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Get configurazione corrente
     */
    public static function get_config() {
        check_ajax_referer('ipv_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        $settings = IPV_Settings::get();

        $config = [
            'base_url' => $settings['supadata_base'] ?? 'https://api.supadata.ai/v1',
            'api_key' => $settings['supadata_key'] ?? '',
            'mode' => $settings['supadata_mode'] ?? 'auto',
            'lang' => $settings['supadata_lang'] ?? '',
            'timeout' => $settings['supadata_timeout'] ?? 30
        ];

        wp_send_json_success($config);
    }
}

// Inizializza AJAX handlers
IPV_SupaData_AJAX::init();
