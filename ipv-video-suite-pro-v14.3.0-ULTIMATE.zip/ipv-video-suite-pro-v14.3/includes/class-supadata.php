<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_SupaData')){
class IPV_SupaData {

    const BASE_URL = 'https://api.supadata.ai/v1';

    public static function init(){}

    protected static function settings(){
        $s = array(
            'supadata_key'  => '',
            'supadata_base' => self::BASE_URL,
            'supadata_lang' => 'it',
        );
        $o = get_option('ipv_settings', array());
        if (is_array($o)){
            if (!empty($o['supadata_key']))  $s['supadata_key']  = $o['supadata_key'];
            if (!empty($o['supadata_base'])) $s['supadata_base'] = rtrim($o['supadata_base'],'/');
            if (!empty($o['supadata_lang'])) $s['supadata_lang'] = $o['supadata_lang'];
        }
        return $s;
    }

    protected static function headers(){
        $s = self::settings();
        return array(
            'x-api-key'    => $s['supadata_key'],
            'Accept'       => 'application/json',
            'Content-Type' => 'application/json',
        );
    }

    public static function fetch_transcript($youtube_id_or_url, $post_id = 0, $opts = array()){
        $s = self::settings();
        if (empty($s['supadata_key'])) return '';

        $lang = !empty($opts['lang']) ? $opts['lang'] : (!empty($s['supadata_lang']) ? $s['supadata_lang'] : 'it');
        $save = array_key_exists('save',$opts) ? (bool)$opts['save'] : true;
        $base = rtrim($s['supadata_base'] ?: self::BASE_URL, '/');

        $vid  = self::video_id($youtube_id_or_url);
        $url  = self::video_url($youtube_id_or_url);

        // 1) Endpoint YouTube dedicato
        $u1 = add_query_arg(array(
            'videoId' => $vid,
            'lang'    => $lang,
            'text'    => 'true',
        ), $base.'/youtube/transcript');

        $txt = self::try_get_text($u1);
        if ($txt === '__POLL__') $txt = self::poll_job(self::$last_job_id, $base, 8, 900);
        if ($txt) return self::maybe_save($post_id, $txt, $save);

        // 2) Endpoint generico con URL
        $u2 = add_query_arg(array(
            'url'  => $url,
            'lang' => $lang,
            'text' => 'true',
        ), $base.'/transcript');

        $txt = self::try_get_text($u2);
        if ($txt === '__POLL__') $txt = self::poll_job(self::$last_job_id, $base, 8, 900);
        if ($txt) return self::maybe_save($post_id, $txt, $save);

        // 3) Fallback: YouTube TimedText
        $txt = self::fetch_timedtext($vid, array($lang,'it','en','auto'));
        return self::maybe_save($post_id, $txt, $save);
    }

    protected static $last_job_id = '';

    protected static function try_get_text($endpoint){
        $r = wp_remote_get($endpoint, array('timeout'=>60, 'headers'=>self::headers()));
        if (is_wp_error($r)) return '';
        $code = wp_remote_retrieve_response_code($r);
        $body = wp_remote_retrieve_body($r);

        if ($code === 202) {
            $json = json_decode($body, true);
            if (!empty($json['jobId'])) { self::$last_job_id = $json['jobId']; return '__POLL__'; }
            return '';
        }
        if ($code !== 200 || empty($body)) return '';

        $json = json_decode($body, true);
        if (is_array($json) && !empty($json['content'])) {
            if (is_string($json['content'])) return trim($json['content']);
            if (is_array($json['content'])) {
                $parts = array();
                foreach($json['content'] as $seg){
                    if (is_string($seg)) $parts[] = $seg;
                    elseif (is_array($seg) && !empty($seg['text'])) $parts[] = $seg['text'];
                }
                return trim(implode(' ', $parts));
            }
        }
        if (!is_array($json) && is_string($body)) {
            $s = trim($body);
            if ($s !== '' && strpos($s,'<') === false) return $s;
        }
        return '';
    }

    protected static function poll_job($job_id, $base, $tries = 8, $delay_ms = 900){
        if (!$job_id) return '';
        $url = rtrim($base,'/').'/transcript/'.rawurlencode($job_id);
        for ($i=0; $i<$tries; $i++){
            $r = wp_remote_get($url, array('timeout'=>30, 'headers'=>self::headers()));
            if (is_wp_error($r)) return '';
            $code = wp_remote_retrieve_response_code($r);
            $body = json_decode(wp_remote_retrieve_body($r), true);
            if ($code === 200 && !empty($body['status'])){
                if ($body['status'] === 'completed' && !empty($body['result']['content'])){
                    $res = $body['result'];
                    if (is_string($res['content'])) return trim($res['content']);
                    if (is_array($res['content'])) {
                        $parts = array();
                        foreach($res['content'] as $seg){
                            if (is_string($seg)) $parts[]=$seg;
                            elseif(is_array($seg) && !empty($seg['text'])) $parts[]=$seg['text'];
                        }
                        return trim(implode(' ', $parts));
                    }
                    return '';
                }
                if ($body['status'] === 'failed') return '';
            }
            usleep($delay_ms * 1000);
        }
        return '';
    }

    protected static function maybe_save($post_id, $txt, $save){
        $txt = trim((string)$txt);
        if ($txt==='') return '';
        if ($post_id && $save) update_post_meta($post_id, '_ipv_transcript', $txt);
        return $txt;
    }

    protected static function video_id($x){
        if (preg_match('~^[A-Za-z0-9_-]{11}$~', $x)) return $x;
        if (preg_match('~v=([A-Za-z0-9_-]{11})~', $x, $m)) return $m[1];
        if (preg_match('~youtu\.be/([A-Za-z0-9_-]{11})~', $x, $m)) return $m[1];
        return $x;
    }
    protected static function video_url($x){
        if (preg_match('~^[A-Za-z0-9_-]{11}$~', $x)) return 'https://www.youtube.com/watch?v='.$x;
        return $x;
    }

    protected static function fetch_timedtext($video_id, $langs = array('it','en','auto')){
        if (!$video_id) return '';
        foreach($langs as $lang){
            $url = 'https://www.youtube.com/api/timedtext?fmt=srv1&v='.rawurlencode($video_id);
            $url .= ($lang==='auto') ? '&lang=en&kind=asr' : '&lang='.rawurlencode($lang);
            $r = wp_remote_get($url, array('timeout'=>20));
            if (is_wp_error($r)) continue;
            $b = wp_remote_retrieve_body($r);
            if (!$b || strpos($b,'<transcript')===false) continue;
            $parts = array();
            if (preg_match_all('/<text[^>]*>(.*?)<\/text>/is', $b, $m)){
                foreach($m[1] as $chunk){
                    $chunk = html_entity_decode($chunk, ENT_QUOTES | ENT_XML1, 'UTF-8');
                    $chunk = preg_replace('/\s+/', ' ', $chunk);
                    $chunk = trim($chunk);
                    if ($chunk!=='') $parts[]=$chunk;
                }
            }
            if ($parts) return trim(implode(' ', $parts));
        }
        return '';
    }
}}
