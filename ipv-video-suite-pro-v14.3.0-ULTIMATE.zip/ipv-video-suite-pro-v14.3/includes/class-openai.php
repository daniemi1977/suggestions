<?php

if (!defined('ABSPATH')) exit;

/**
 * Classe OpenAI con parsing avanzato e gestione strutturata
 */
class IPV_OpenAI {
    
    /**
     * Genera contenuti via OpenAI
     */
    public static function generate($prompt, $transcript, $model, $api_key) {
        if (empty($api_key) || empty($model) || empty($prompt) || empty($transcript)) {
            IPV_Logger::error('OpenAI generation: missing parameters');
            return null;
        }
        
        // Limita lunghezza trascrizione per evitare token limit
        $max_chars = 30000; // ~7500 tokens
        if (strlen($transcript) > $max_chars) {
            $transcript = substr($transcript, 0, $max_chars) . "\n\n[...trascrizione troncata...]";
            IPV_Logger::warning('Transcript truncated to fit token limit');
        }
        
        $endpoint = 'https://api.openai.com/v1/chat/completions';
        
        $messages = [
            [
                'role' => 'system',
                'content' => 'Sei un assistente esperto che analizza trascrizioni video e restituisce contenuti strutturati in formato markdown con sezioni ben definite.'
            ],
            [
                'role' => 'user',
                'content' => $prompt . "\n\n## TRASCRIZIONE VIDEO:\n\n" . $transcript
            ]
        ];
        
        $body = [
            'model'       => $model,
            'messages'    => $messages,
            'temperature' => 0.7,
            'max_tokens'  => 4000
        ];
        
        $args = [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json'
            ],
            'timeout' => 120,
            'body'    => wp_json_encode($body)
        ];
        
        IPV_Logger::info('Requesting OpenAI generation', [
            'model' => $model,
            'transcript_length' => strlen($transcript)
        ]);
        
        $api_client = new API_Client();
        $result = $api_client->request($endpoint, array_merge($args, ['method' => 'POST']));
        
        if (!$result) {
            IPV_Logger::error('OpenAI request failed');
            return null;
        }
        
        $json = json_decode($result['body'], true);
        
        if (!isset($json['choices'][0]['message']['content'])) {
            IPV_Logger::error('OpenAI response invalid', ['response' => substr($result['body'], 0, 500)]);
            return null;
        }
        
        $content = $json['choices'][0]['message']['content'];
        
        // Log usage
        if (isset($json['usage'])) {
            IPV_Logger::info('OpenAI tokens used', $json['usage']);
        }
        
        IPV_Logger::success('OpenAI content generated', ['length' => strlen($content)]);
        
        return $content;
    }
    
    /**
     * Parse sezioni dal contenuto generato
     */
    public static function parse_sections($text) {
        $sections = [];
        
        // Mappa sezioni -> meta keys
        $section_map = [
            'Titolo episodio'       => 'ipv_title_opt',
            'Titolo'                => 'ipv_title_opt',
            'Descrizione'           => 'ipv_summary',
            'Riassunto'             => 'ipv_summary',
            'Sponsor'               => 'ipv_sponsor',
            'Minutaggio'            => 'ipv_minutaggio',
            'Timeline'              => 'ipv_minutaggio',
            'Argomenti trattati'    => 'ipv_topics',
            'Argomenti'             => 'ipv_topics',
            'Temi'                  => 'ipv_topics',
            'Ospiti'                => 'ipv_guests',
            'Ospite'                => 'ipv_guests',
            'Persone menzionate'    => 'ipv_people',
            'Persone'               => 'ipv_people',
            'Regia'                 => 'ipv_director',
            'Eventi'                => 'ipv_events',
            'Evento'                => 'ipv_events',
            'Donazioni'             => 'ipv_donations',
            'Abbonati al canale'    => 'ipv_subscribe',
            'Abbonamento'           => 'ipv_subscribe',
            'Social'                => 'ipv_social',
            'Social media'          => 'ipv_social',
            'Contatti'              => 'ipv_contacts',
            'Contatto'              => 'ipv_contacts',
            'Temi del canale'       => 'ipv_channel_themes',
            'Hashtag'               => 'ipv_hashtags',
            'Tag'                   => 'ipv_hashtags'
        ];
        
        // Split by markdown headers
        $pattern = '/^#{1,3}\s+(.+?)$/m';
        preg_match_all($pattern, $text, $matches, PREG_OFFSET_CAPTURE);
        
        if (!empty($matches[1])) {
            for ($i = 0; $i < count($matches[1]); $i++) {
                $header = trim($matches[1][$i][0]);
                $start = $matches[0][$i][1] + strlen($matches[0][$i][0]);
                
                // Trova dove finisce questa sezione
                $end = isset($matches[0][$i + 1]) 
                    ? $matches[0][$i + 1][1] 
                    : strlen($text);
                
                $content = trim(substr($text, $start, $end - $start));
                
                // Pulisci header da emoji e caratteri speciali
                $clean_header = preg_replace('/[^\w\s]/u', '', $header);
                $clean_header = trim($clean_header);
                
                // Trova meta key corrispondente
                foreach ($section_map as $label => $meta_key) {
                    if (stripos($clean_header, $label) !== false || 
                        stripos($header, $label) !== false) {
                        
                        // Se già esiste, concatena
                        if (isset($sections[$meta_key])) {
                            $sections[$meta_key] .= "\n\n" . $content;
                        } else {
                            $sections[$meta_key] = $content;
                        }
                        break;
                    }
                }
            }
        }
        
        // Fallback: cerca pattern più semplici se markdown parsing fallisce
        if (empty($sections)) {
            foreach ($section_map as $label => $meta_key) {
                $patterns = [
                    '/(?:^|\n)[\*#]*\s*' . preg_quote($label, '/') . '\s*[:]*[\*#]*\s*\n+(.+?)(?=\n\n|\n[\*#]|$)/is',
                    '/(?:^|\n)' . preg_quote($label, '/') . '\s*:\s*(.+?)(?=\n\n|\n[A-Z]|$)/is'
                ];
                
                foreach ($patterns as $pattern) {
                    if (preg_match($pattern, $text, $m)) {
                        $sections[$meta_key] = trim($m[1]);
                        break;
                    }
                }
            }
        }
        
        IPV_Logger::info('Parsed ' . count($sections) . ' sections from OpenAI content');
        
        return $sections;
    }
    
    /**
     * Test connessione OpenAI
     */
    public static function test_connection($api_key) {
        if (empty($api_key)) {
            return [
                'success' => false,
                'message' => 'API key mancante'
            ];
        }
        
        $api_client = new API_Client();
        
        $result = $api_client->request('https://api.openai.com/v1/models', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key
            ],
            'timeout' => 15
        ]);
        
        if (!$result) {
            return [
                'success' => false,
                'message' => 'Connessione fallita o API key non valida'
            ];
        }
        
        $json = json_decode($result['body'], true);
        
        if (isset($json['data']) && is_array($json['data'])) {
            $model_count = count($json['data']);
            return [
                'success' => true,
                'message' => "Connesso! $model_count modelli disponibili"
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Risposta API non valida'
        ];
    }
    
    /**
     * Estrae minutaggio strutturato
     */
    public static function parse_timeline($text) {
        $timeline = [];
        
        // Pattern per timestamp: 00:00, 0:00, 1:23:45
        $pattern = '/(\d{1,2}:?\d{2}(?::\d{2})?)\s*[-–—]\s*(.+?)(?=\n|$)/';
        
        if (preg_match_all($pattern, $text, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $timeline[] = [
                    'time' => trim($match[1]),
                    'description' => trim($match[2])
                ];
            }
        }
        
        return $timeline;
    }
    
    /**
     * Estrae hashtags
     */
    public static function extract_hashtags($text) {
        preg_match_all('/#(\w+)/u', $text, $matches);
        return array_unique($matches[1] ?? []);
    }
    
    /**
     * Genera prompt template di default
     */
    public static function get_default_prompt() {
        return <<<PROMPT
Analizza questa trascrizione video e crea contenuti strutturati seguendo ESATTAMENTE questo formato markdown:

# Titolo episodio
[Titolo accattivante e descrittivo del video]

# Descrizione
[Descrizione completa di 2-3 paragrafi che riassume i contenuti principali]

# Argomenti trattati
- [Argomento 1]
- [Argomento 2]
- [...]

# Minutaggio
00:00 - Introduzione
05:30 - [Argomento principale]
[...]

# Ospiti
[Nome e breve descrizione degli ospiti, se presenti]

# Persone menzionate
[Persone citate durante il video]

# Sponsor
[Eventuali sponsor menzionati]

# Eventi
[Eventi discussi o promossi]

# Hashtag
#hashtag1 #hashtag2 #hashtag3

Assicurati di:
- Usare markdown corretto (# per headers)
- Includere TUTTE le sezioni anche se alcune sono vuote (scrivi "Nessuno" o "Non applicabile")
- Essere preciso e dettagliato
- Mantenere il tono professionale
PROMPT;
    }
}