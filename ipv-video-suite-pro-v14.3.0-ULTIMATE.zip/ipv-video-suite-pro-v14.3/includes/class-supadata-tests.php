<?php
/**
 * IPV SupaData - Test Suite
 * 
 * Test completo dell'integrazione SupaData
 * 
 * Uso: wp-cli o dashboard admin
 */

if (!defined('ABSPATH')) exit;

class IPV_SupaData_Tests {

    /**
     * Test 1: Connessione API
     */
    public static function test_connection() {
        echo "\n=== TEST 1: Connessione SupaData API ===\n";
        
        $result = IPV_SupaData::test_connection();
        
        echo "✓ Risultato: " . ($result['success'] ? 'SUCCESS' : 'FAILED') . "\n";
        echo "✓ Messaggio: " . $result['message'] . "\n";
        echo "✓ HTTP Code: " . $result['code'] . "\n";
        
        return $result['success'];
    }

    /**
     * Test 2: Validazione URL
     */
    public static function test_url_validation() {
        echo "\n=== TEST 2: Validazione URL ===\n";
        
        $test_urls = [
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ' => 'YouTube',
            'https://youtu.be/dQw4w9WgXcQ' => 'YouTube short',
            'https://www.tiktok.com/@user/video/123456' => 'TikTok',
            'https://www.instagram.com/reel/ABC123/' => 'Instagram',
            'https://x.com/user/status/123456' => 'X (Twitter)',
            'https://example.com/video.mp4' => 'File MP4',
            'https://example.com/audio.mp3' => 'File MP3',
            'https://invalid-url' => 'URL non valido'
        ];

        $passed = 0;
        $total = count($test_urls);

        foreach ($test_urls as $url => $description) {
            $result = IPV_SupaData::validate_url($url);
            $status = $result['valid'] ? '✓ PASS' : '✗ FAIL';
            
            echo "{$status} - {$description}: {$result['message']}\n";
            
            if ($result['valid']) {
                $passed++;
            }
        }

        echo "\nRisultato: {$passed}/{$total} test superati\n";
        
        return $passed > 0;
    }

    /**
     * Test 3: Fetch transcript YouTube (mode=native)
     */
    public static function test_youtube_native() {
        echo "\n=== TEST 3: YouTube Transcript (Native) ===\n";
        
        // Video YouTube pubblico con sottotitoli
        $video_id = 'jNQXAC9IVRw'; // "Me at the zoo" - primo video YouTube
        
        echo "✓ Video ID: {$video_id}\n";
        echo "✓ Mode: native (solo sottotitoli esistenti)\n";
        echo "✓ Fetching...\n";
        
        $result = IPV_SupaData::fetch_transcript($video_id, null, [
            'mode' => 'native',
            'lang' => 'en',
            'text' => true
        ]);

        if ($result) {
            echo "✓ SUCCESS!\n";
            echo "✓ Lingua: " . $result['lang'] . "\n";
            echo "✓ Lingue disponibili: " . implode(', ', $result['availableLangs']) . "\n";
            echo "✓ Lunghezza transcript: " . strlen($result['content']) . " caratteri\n";
            echo "✓ Preview: " . substr($result['content'], 0, 200) . "...\n";
            return true;
        } else {
            echo "✗ FAILED: Transcript non recuperato\n";
            return false;
        }
    }

    /**
     * Test 4: Fetch transcript con timestamp chunks
     */
    public static function test_transcript_chunks() {
        echo "\n=== TEST 4: Transcript con Timestamp ===\n";
        
        $video_id = 'jNQXAC9IVRw';
        
        echo "✓ Video ID: {$video_id}\n";
        echo "✓ text=false (richiede chunks con timestamp)\n";
        echo "✓ Fetching...\n";
        
        $result = IPV_SupaData::fetch_transcript($video_id, null, [
            'mode' => 'native',
            'text' => false, // Richiedi chunks con timestamp
            'chunkSize' => 100
        ]);

        if ($result) {
            echo "✓ SUCCESS!\n";
            echo "✓ Content type: " . (is_string($result['content']) ? 'string' : 'array') . "\n";
            echo "✓ Preview: " . substr($result['content'], 0, 200) . "...\n";
            return true;
        } else {
            echo "✗ FAILED\n";
            return false;
        }
    }

    /**
     * Test 5: Gestione errori
     */
    public static function test_error_handling() {
        echo "\n=== TEST 5: Gestione Errori ===\n";
        
        // Test con video inesistente
        $result = IPV_SupaData::fetch_transcript('INVALID_VIDEO_ID_12345', null, [
            'mode' => 'native'
        ]);

        if ($result === null) {
            echo "✓ SUCCESS: Errore gestito correttamente (null returned)\n";
            return true;
        } else {
            echo "✗ FAILED: Dovrebbe restituire null per video inesistente\n";
            return false;
        }
    }

    /**
     * Test 6: Stima crediti
     */
    public static function test_credit_estimation() {
        echo "\n=== TEST 6: Stima Crediti ===\n";
        
        $tests = [
            ['mode' => 'native', 'duration' => null, 'expected' => 1],
            ['mode' => 'generate', 'duration' => 5, 'expected' => 10],
            ['mode' => 'generate', 'duration' => 10, 'expected' => 20],
        ];

        $passed = 0;
        foreach ($tests as $test) {
            $credits = IPV_SupaData::estimate_credits($test['mode'], $test['duration']);
            $match = ($credits === $test['expected']);
            $status = $match ? '✓ PASS' : '✗ FAIL';
            
            echo "{$status} - Mode: {$test['mode']}, Duration: {$test['duration']}min => {$credits} crediti\n";
            
            if ($match) $passed++;
        }

        echo "\nRisultato: {$passed}/" . count($tests) . " test superati\n";
        return $passed === count($tests);
    }

    /**
     * Esegui tutti i test
     */
    public static function run_all() {
        echo "\n";
        echo "╔════════════════════════════════════════════╗\n";
        echo "║  IPV SUPADATA - TEST SUITE               ║\n";
        echo "╚════════════════════════════════════════════╝\n";

        $results = [];
        
        $results[] = ['name' => 'Test Connessione', 'passed' => self::test_connection()];
        $results[] = ['name' => 'Test Validazione URL', 'passed' => self::test_url_validation()];
        $results[] = ['name' => 'Test YouTube Native', 'passed' => self::test_youtube_native()];
        $results[] = ['name' => 'Test Transcript Chunks', 'passed' => self::test_transcript_chunks()];
        $results[] = ['name' => 'Test Error Handling', 'passed' => self::test_error_handling()];
        $results[] = ['name' => 'Test Credit Estimation', 'passed' => self::test_credit_estimation()];

        // Sommario
        echo "\n";
        echo "╔════════════════════════════════════════════╗\n";
        echo "║  SOMMARIO TEST                           ║\n";
        echo "╚════════════════════════════════════════════╝\n";

        $total = count($results);
        $passed = 0;

        foreach ($results as $result) {
            $status = $result['passed'] ? '✓ PASS' : '✗ FAIL';
            echo "{$status} - {$result['name']}\n";
            if ($result['passed']) $passed++;
        }

        $percentage = round(($passed / $total) * 100);
        echo "\n";
        echo "Risultato finale: {$passed}/{$total} test superati ({$percentage}%)\n";
        echo "\n";

        if ($passed === $total) {
            echo "🎉 TUTTI I TEST SUPERATI! SupaData è pronto!\n";
        } else {
            echo "⚠️  Alcuni test falliti. Controlla la configurazione.\n";
        }
    }
}

// Auto-run se chiamato da CLI
if (defined('WP_CLI') && WP_CLI) {
    IPV_SupaData_Tests::run_all();
}
