<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_Importer')){
class IPV_Importer {
    public static function init(){
        add_action('admin_menu', array(__CLASS__,'menu'));
        add_action('admin_post_ipv_import_one', array(__CLASS__,'handle_import_one'));
    }
    public static function menu(){
        add_submenu_page('edit.php?post_type=ipv_video', __('Import & Sync','ipv'), __('Import & Sync','ipv'), 'edit_posts', 'ipv-import', array(__CLASS__,'render'));
    }
    public static function render(){
        if(!current_user_can('edit_posts')) wp_die('Not allowed');
        $action = wp_nonce_url(admin_url('admin-post.php?action=ipv_import_one'),'ipv_import_one');
        echo '<div class="wrap"><h1>Import & Sync</h1>';
        echo '<form method="post" action="'.esc_url($action).'">';
        echo '<p><label>YouTube URL o ID:</label><br/><input type="text" name="youtube" class="regular-text" required></p>';
        echo '<p><button class="button button-primary">Importa</button></p>';
        echo '</form></div>';
    }
    protected static function parse_id($x){
        if(preg_match('~^[A-Za-z0-9_-]{11}$~',$x)) return $x;
        if(preg_match('~v=([A-Za-z0-9_-]{11})~',$x,$m)) return $m[1];
        if(preg_match('~youtu\.be/([A-Za-z0-9_-]{11})~',$x,$m)) return $m[1];
        return '';
    }
    public static function handle_import_one(){
        if(!current_user_can('edit_posts')) wp_die('Not allowed'); check_admin_referer('ipv_import_one');
        $x = isset($_POST['youtube']) ? trim($_POST['youtube']) : ''; $id = self::parse_id($x);
        if(!$id) wp_die('ID YouTube non valido');
        $post_id = wp_insert_post(array('post_type'=>'ipv_video','post_status'=>'publish','post_title'=>$id));
        if(is_wp_error($post_id)) wp_die('Errore creazione post');
        update_post_meta($post_id,'_ipv_youtube_id',$id);
        update_post_meta($post_id,'_ipv_youtube_url','https://www.youtube.com/watch?v='.$id);
        if(class_exists('IPV_Tools')) IPV_Tools::download_youtube_thumbnail($id,$post_id);
        if(class_exists('IPV_YouTube')){
            $o=get_option('ipv_settings',array());
            if(!empty($o['youtube_api_key'])){
                $data = IPV_YouTube::fetch_video($id, $o['youtube_api_key']);
                if($data){
                    update_post_meta($post_id,'_ipv_yt_title', $data['title']);
                    update_post_meta($post_id,'_ipv_yt_description', $data['description']);
                    update_post_meta($post_id,'_ipv_yt_channel', $data['channelTitle']);
                    update_post_meta($post_id,'_ipv_yt_published_at', $data['publishedAt']);
                    update_post_meta($post_id,'_ipv_yt_duration', $data['duration']);
                    update_post_meta($post_id,'_ipv_yt_tags', implode(', ', $data['tags']));
                    update_post_meta($post_id,'_ipv_yt_view_count', $data['viewCount']);
                    update_post_meta($post_id,'_ipv_yt_like_count', $data['likeCount']);
                    update_post_meta($post_id,'_ipv_yt_thumbnails', wp_json_encode($data['thumbnails']));
                    update_post_meta($post_id,'_ipv_yt_raw', wp_json_encode($data['raw']));
                }
            }
        }
        if(class_exists('IPV_Fields')) IPV_Fields::generate_for_post($post_id);
        wp_safe_redirect(get_edit_post_link($post_id,'')); exit;
    }
}}
