<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_REST')) {
class IPV_REST {
    public static function init(){
        add_action('rest_api_init', [__CLASS__,'routes']);
    }
    public static function routes(){
        register_rest_route('ipv/v1','/generate-txt', [
            'methods'=>'POST',
            'callback'=>[__CLASS__,'generate_txt'],
            'permission_callback'=>function(){ return current_user_can('edit_posts'); }
        ]);
        register_rest_route('ipv/v1','/structured', [
            'methods'=>'POST',
            'callback'=>[__CLASS__,'structured'],
            'permission_callback'=>function(){ return current_user_can('edit_posts'); }
        ]);
    }
    public static function generate_txt($req){
        $post_id=intval($req->get_param('post_id')); $sponsor=sanitize_text_field($req->get_param('sponsor') ?: '');
        $t=get_post_meta($post_id,'_ipv_transcript',true); if(!$t) return new WP_Error('no_transcript','Transcript mancante', ['status'=>400]);
        $title=get_the_title($post_id); $o=IPV_OpenAI::get(); $prompt=IPV_OpenAI::build_prompt($title,$t,$sponsor);
        $txt=IPV_OpenAI::call_ai($o['provider'],$o['api_key'],$o['model'],$prompt); if(!$txt) return new WP_Error('ai_fail','AI non disponibile', ['status'=>500]);
        $url=IPV_OpenAI::save_txt($post_id,$txt); if(!$url) return new WP_Error('save_fail','Salvataggio fallito', ['status'=>500]);
        update_post_meta($post_id,'_ipv_txt_url',$url); return ['url'=>$url];
    }
    public static function structured($req){
        $post_id=intval($req->get_param('post_id')); $t=get_post_meta($post_id,'_ipv_transcript',true); if(!$t) return new WP_Error('no_transcript','Transcript mancante', ['status'=>400]);
        $title=get_the_title($post_id); $json=IPV_OpenAI::generate_structured_from_transcript($title,$t); $data=json_decode($json,true);
        if(!is_array($data)) return new WP_Error('json','JSON non valido', ['status'=>500]);
        $map=['optimized_title','summary','topics','timeline','guests','mentions','events','hashtags'];
        foreach($map as $k){ if(isset($data[$k])) update_post_meta($post_id,'_ipv_'.$k, is_string($data[$k])?wp_kses_post($data[$k]):$data[$k]); }
        return $data;
    }
}
}