<?php

if (!defined('ABSPATH')) exit;

/**
 * Personalizzazione colonne admin per CPT ipv_video
 */
class IPV_Admin_Columns {
    
    public static function init() {
        add_filter('manage_' . IPVCPT_CPT . '_posts_columns', [__CLASS__, 'columns']);
        add_action('manage_' . IPVCPT_CPT . '_posts_custom_column', [__CLASS__, 'render'], 10, 2);
        add_filter('manage_edit-' . IPVCPT_CPT . '_sortable_columns', [__CLASS__, 'sortable_columns']);
        add_action('admin_head', [__CLASS__, 'css']);
    }
    
    /**
     * Definisce colonne custom
     */
    public static function columns($columns) {
        $new_columns = [];
        
        foreach ($columns as $key => $value) {
            // Aggiungi checkbox
            if ($key === 'cb') {
                $new_columns[$key] = $value;
            }
            
            // Aggiungi thumbnail dopo checkbox
            if ($key === 'cb') {
                $new_columns['ipv_thumb'] = '🖼️ Thumb';
            }
            
            // Titolo
            if ($key === 'title') {
                $new_columns[$key] = '📹 Video';
            }
            
            // Dopo il titolo, aggiungi colonne custom
            if ($key === 'title') {
                $new_columns['ipv_video_id'] = 'ID Video';
                $new_columns['ipv_streams_status'] = '🎬 Streams';
                $new_columns['ipv_transcript_info'] = '📝 Trascrizione';
                $new_columns['ipv_ai_status'] = '🤖 AI';
            }
            
            // Mantieni data
            if ($key === 'date') {
                $new_columns[$key] = '📅 ' . $value;
            }
        }
        
        return $new_columns;
    }
    
    /**
     * Rende il contenuto delle colonne custom
     */
    public static function render($column, $post_id) {
        switch ($column) {
            case 'ipv_thumb':
                if (has_post_thumbnail($post_id)) {
                    echo '<div class="ipv-thumb-wrapper">';
                    echo get_the_post_thumbnail($post_id, [100, 56], ['class' => 'ipv-thumb-img']);
                    echo '</div>';
                } else {
                    $thumb_url = get_post_meta($post_id, 'ipv_thumb_url', true);
                    if ($thumb_url) {
                        echo '<div class="ipv-thumb-wrapper">';
                        echo '<img src="' . esc_url($thumb_url) . '" alt="" class="ipv-thumb-img" />';
                        echo '</div>';
                    } else {
                        echo '<span style="color:#999;">—</span>';
                    }
                }
                break;
            
            case 'ipv_video_id':
                $video_id = get_post_meta($post_id, 'ipv_video_id', true);
                if ($video_id) {
                    $url = 'https://www.youtube.com/watch?v=' . $video_id;
                    echo '<code class="ipv-video-id">' . esc_html($video_id) . '</code>';
                    echo '<div class="row-actions">';
                    echo '<span><a href="' . esc_url($url) . '" target="_blank" rel="noopener">🔗 YouTube</a></span>';
                    echo '</div>';
                } else {
                    echo '<span style="color:#999;">—</span>';
                }
                break;
            
            case 'ipv_streams_status':
                $is_stream = get_post_meta($post_id, 'ipv_is_stream', true);
                $source = get_post_meta($post_id, 'ipv_source', true);
                
                if ($is_stream === '1') {
                    echo '<span class="ipv-badge ipv-badge-success" title="Video da Streams">✓ Streams</span>';
                    if ($source) {
                        echo '<div class="ipv-source">' . esc_html($source) . '</div>';
                    }
                } else {
                    echo '<span class="ipv-badge ipv-badge-gray">—</span>';
                }
                break;
            
            case 'ipv_transcript_info':
                $transcript = get_post_meta($post_id, 'ipv_transcript', true);
                $lines = intval(get_post_meta($post_id, 'ipv_transcript_lines', true));
                
                if (!empty($transcript)) {
                    echo '<span class="ipv-badge ipv-badge-info">' . number_format($lines) . ' righe</span>';
                    
                    $chars = strlen($transcript);
                    echo '<div class="ipv-meta-info">';
                    echo number_format($chars) . ' caratteri';
                    echo '</div>';
                } else {
                    echo '<span class="ipv-badge ipv-badge-warning">Mancante</span>';
                }
                break;
            
            case 'ipv_ai_status':
                $ai_payload = get_post_meta($post_id, 'ipv_openai_payload', true);
                $video_id = get_post_meta($post_id, 'ipv_video_id', true);
                
                if (!empty($ai_payload)) {
                    echo '<span class="ipv-badge ipv-badge-success" title="Contenuti AI generati">✓ Generato</span>';
                    
                    // Check JSON file
                    if ($video_id) {
                        $upload = wp_upload_dir();
                        $json_file = trailingslashit($upload['basedir']) . 'ipv-video-json/' . $video_id . '.json';
                        
                        if (file_exists($json_file)) {
                            $json_url = trailingslashit($upload['baseurl']) . 'ipv-video-json/' . $video_id . '.json';
                            echo '<div class="row-actions">';
                            echo '<span><a href="' . esc_url($json_url) . '" target="_blank">📄 JSON</a></span>';
                            echo '</div>';
                        }
                    }
                } else {
                    echo '<span class="ipv-badge ipv-badge-gray">Non generato</span>';
                }
                break;
        }
    }
    
    /**
     * Colonne sortable
     */
    public static function sortable_columns($columns) {
        $columns['ipv_transcript_info'] = 'ipv_transcript_lines';
        return $columns;
    }
    
    /**
     * CSS per colonne custom
     */
    public static function css() {
        global $current_screen;
        
        if (!$current_screen || $current_screen->post_type !== IPVCPT_CPT) {
            return;
        }
        
        ?>
        <style>
        /* Larghezza colonne */
        .column-ipv_thumb { width: 120px; }
        .column-ipv_video_id { width: 140px; }
        .column-ipv_streams_status { width: 120px; }
        .column-ipv_transcript_info { width: 140px; }
        .column-ipv_ai_status { width: 130px; }
        
        /* Thumbnail */
        .ipv-thumb-wrapper {
            width: 100px;
            height: 56px;
            overflow: hidden;
            border-radius: 4px;
            border: 1px solid #ddd;
            background: #f5f5f5;
        }
        
        .ipv-thumb-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        
        /* Video ID */
        .ipv-video-id {
            background: #f0f0f1;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 11px;
            color: #2c3338;
            font-family: 'Courier New', monospace;
        }
        
        /* Badges */
        .ipv-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            line-height: 1;
            white-space: nowrap;
        }
        
        .ipv-badge-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .ipv-badge-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        
        .ipv-badge-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        
        .ipv-badge-gray {
            background: #e9ecef;
            color: #6c757d;
            border: 1px solid #dee2e6;
        }
        
        /* Meta info */
        .ipv-source,
        .ipv-meta-info {
            font-size: 11px;
            color: #666;
            margin-top: 4px;
            line-height: 1.3;
        }
        
        /* Row actions */
        .type-ipv_video .row-actions {
            color: #999;
        }
        
        .type-ipv_video .row-actions a {
            text-decoration: none;
        }
        
        /* Hover effect sul titolo */
        .type-ipv_video .row-title {
            font-weight: 600;
            font-size: 14px;
        }
        
        /* Responsive */
        @media screen and (max-width: 782px) {
            .column-ipv_thumb,
            .column-ipv_video_id,
            .column-ipv_streams_status {
                display: none !important;
            }
        }
        
        /* Quick edit link style */
        .type-ipv_video .row-actions span.inline,
        .type-ipv_video .row-actions span.trash {
            display: inline-block;
            margin: 0 2px;
        }
        </style>
        <?php
    }
}