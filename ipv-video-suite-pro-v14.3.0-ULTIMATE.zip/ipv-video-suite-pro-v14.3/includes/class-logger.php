<?php
/**
 * Logger Class
 * Gestisce il logging delle operazioni
 */

if (!defined('ABSPATH')) exit;

class IPV_Logger {
    
    private static $log_file;
    private static $max_log_size = 5242880; // 5MB
    
    /**
     * Initialize logger
     */
    public static function init() {
        $upload = wp_upload_dir();
        $log_dir = trailingslashit($upload['basedir']) . 'ipv-video-logs/';
        
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }
        
        self::$log_file = $log_dir . 'ipv-log-' . date('Y-m-d') . '.log';
        
        // Proteggi la directory
        $htaccess = $log_dir . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, 'Deny from all');
        }
    }
    
    /**
     * Log a message
     */
    public static function log($message, $level = 'info', $context = []) {
        if (!self::$log_file) {
            self::init();
        }
        
        // Ruota il log se troppo grande
        if (file_exists(self::$log_file) && filesize(self::$log_file) > self::$max_log_size) {
            self::rotate_log();
        }
        
        $timestamp = current_time('mysql');
        $user = wp_get_current_user();
        $user_info = $user->ID ? $user->user_login : 'system';
        
        $context_str = !empty($context) ? json_encode($context, JSON_UNESCAPED_UNICODE) : '';
        
        $log_entry = sprintf(
            "[%s] [%s] [%s] %s %s\n",
            $timestamp,
            strtoupper($level),
            $user_info,
            $message,
            $context_str
        );
        
        file_put_contents(self::$log_file, $log_entry, FILE_APPEND);
        
        // Salva anche nel database per query veloci
        self::save_to_db($message, $level, $context);
    }
    
    /**
     * Save log to database
     */
    private static function save_to_db($message, $level, $context) {
        global $wpdb;
        $table = $wpdb->prefix . 'ipv_logs';
        
        $wpdb->insert(
            $table,
            [
                'timestamp' => current_time('mysql'),
                'level' => $level,
                'message' => $message,
                'context' => json_encode($context, JSON_UNESCAPED_UNICODE),
                'user_id' => get_current_user_id()
            ],
            ['%s', '%s', '%s', '%s', '%d']
        );
    }
    
    /**
     * Get logs from database
     */
    public static function get_logs($args = []) {
        global $wpdb;
        $table = $wpdb->prefix . 'ipv_logs';
        
        $defaults = [
            'limit' => 50,
            'offset' => 0,
            'level' => '',
            'start_date' => '',
            'end_date' => ''
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $where = ['1=1'];
        
        if (!empty($args['level'])) {
            $where[] = $wpdb->prepare('level = %s', $args['level']);
        }
        
        if (!empty($args['start_date'])) {
            $where[] = $wpdb->prepare('timestamp >= %s', $args['start_date']);
        }
        
        if (!empty($args['end_date'])) {
            $where[] = $wpdb->prepare('timestamp <= %s', $args['end_date']);
        }
        
        $where_clause = implode(' AND ', $where);
        
        $query = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY timestamp DESC LIMIT %d OFFSET %d";
        
        return $wpdb->get_results(
            $wpdb->prepare($query, $args['limit'], $args['offset']),
            ARRAY_A
        );
    }
    
    /**
     * Clear old logs
     */
    public static function clear_old_logs($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'ipv_logs';
        
        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        $deleted = $wpdb->query(
            $wpdb->prepare("DELETE FROM {$table} WHERE timestamp < %s", $date)
        );
        
        self::log("Eliminati {$deleted} log vecchi di più di {$days} giorni", 'info');
        
        return $deleted;
    }
    
    /**
     * Rotate log file
     */
    private static function rotate_log() {
        $archive = str_replace('.log', '-' . time() . '.log', self::$log_file);
        rename(self::$log_file, $archive);
        
        // Comprimi il log archiviato
        if (function_exists('gzencode')) {
            $content = file_get_contents($archive);
            file_put_contents($archive . '.gz', gzencode($content, 9));
            unlink($archive);
        }
    }
    
    /**
     * Shorthand methods
     */
    public static function info($message, $context = []) {
        self::log($message, 'info', $context);
    }
    
    public static function warning($message, $context = []) {
        self::log($message, 'warning', $context);
    }
    
    public static function error($message, $context = []) {
        self::log($message, 'error', $context);
    }
    
    public static function success($message, $context = []) {
        self::log($message, 'success', $context);
    }
    
    /**
     * Create logs table
     */
    public static function create_table() {
        global $wpdb;
        $table = $wpdb->prefix . 'ipv_logs';
        $charset = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            timestamp datetime NOT NULL,
            level varchar(20) NOT NULL,
            message text NOT NULL,
            context longtext,
            user_id bigint(20),
            PRIMARY KEY (id),
            KEY timestamp (timestamp),
            KEY level (level),
            KEY user_id (user_id)
        ) {$charset};";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}