<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('IPV_Elementor_Widget')) {
class IPV_Elementor_Widget {
    public static function init(){
        add_action('elementor/widgets/register', [__CLASS__,'register_widget']);
    }
    public static function register_widget($widgets_manager){
        if (!class_exists('\Elementor\Widget_Base')) return;
        require_once __DIR__.'/widget-ipv-wall.php';
        $widgets_manager->register( new \IPV_Elementor_Wall_Widget() );
    }
}
}
