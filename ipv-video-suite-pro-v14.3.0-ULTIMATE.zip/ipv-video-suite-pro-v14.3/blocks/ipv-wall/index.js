( function( wp ) {
  const { registerBlockType } = wp.blocks;
  const { InspectorControls } = wp.blockEditor || wp.editor;
  const { PanelBody, ToggleControl, RangeControl } = wp.components;
  registerBlockType('ipv/wall', {
    edit: (props) => {
      const { attributes, setAttributes } = props;
      return [
        wp.element.createElement(InspectorControls, {},
          wp.element.createElement(PanelBody, { title: 'Impostazioni' },
            wp.element.createElement(RangeControl, {
              label: 'Per page', min:1, max:24, value: attributes.perPage,
              onChange: (v)=>setAttributes({perPage:v})
            }),
            wp.element.createElement(ToggleControl, {
              label: 'Solo orizzontali', checked: attributes.onlyHorizontal,
              onChange: (v)=>setAttributes({onlyHorizontal:v})
            })
          )
        ),
        wp.element.createElement('p', {}, 'IPV Wall – anteprima.')
      ];
    }
  });
} )( window.wp );
