<?php
$per = isset($attributes['perPage']) ? intval($attributes['perPage']) : 5;
$only = !empty($attributes['onlyHorizontal']) ? '1' : '0';
echo do_shortcode('[ipv_wall per_page="'.$per.'" only_horizontal="'.$only.'"]');
