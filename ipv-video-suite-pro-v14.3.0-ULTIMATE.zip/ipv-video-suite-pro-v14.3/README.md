# IPV Video Suite Pro v12.0.0

**Complete video management solution for "Il Punto di Vista"**

## 🎯 Features

### 🎛️ Modern Bootstrap 5 Admin Panel
- **Dashboard** - Stats overview, quick actions, and recent activity
- **Import & Sync** - YouTube feed setup, manual import, sync scheduler, and import history
- **Trascrizioni** - Toggle between YouTube Data API and SupaData, with API testing
- **Analytics** - Views summary, video performance charts, and API usage tracking
- **Tools** - Cache management, thumbnail rebuilding, and data export
- **About** - Plugin information and changelog

### 📹 Video Management
- Custom Post Type for videos
- YouTube channel integration
- Automatic video import from streams
- Metadata extraction (title, description, duration, views, etc.)
- Horizontal/vertical video filtering

### 🎙️ Transcription Systems
- **YouTube Data API** - Native YouTube transcription
- **SupaData API** - Advanced AI-powered transcription
- Toggle between methods with simple UI
- Real-time API testing

### 🤖 AI Content Generation
- OpenAI GPT-4 integration
- Automatic content generation from transcripts
- Custom prompt support
- SEO-optimized descriptions
- Hashtag generation
- Structured text output

### 📊 Analytics & Insights
- Video performance tracking
- API usage monitoring
- Views and engagement metrics
- Interactive Chart.js charts

### 🎨 Frontend Display
- Beautiful video wall with grid layout
- Gutenberg block support
- Elementor widget integration
- Shortcode support: `[ipv-wall]`
- Responsive design
- YouTube embed integration

### ⚙️ Advanced Features
- Scheduled auto-import (hourly, twice daily, daily, weekly)
- AJAX-powered admin interface
- Cache system for API calls
- Comprehensive logging
- WordPress REST API endpoints
- Multi-language ready (i18n)

## 📋 Requirements

- WordPress 6.0+
- PHP 7.4+
- MySQL 5.7+
- cURL extension
- JSON extension

## 🚀 Installation

1. Download `ipv-video-suite-pro-v12.0.0.zip`
2. Go to WordPress Admin → Plugins → Add New
3. Click "Upload Plugin"
4. Choose the ZIP file
5. Click "Install Now"
6. Activate the plugin

## ⚙️ Configuration

### Step 1: Configure APIs

1. Go to **IPV Video → Trascrizioni**
2. Choose your transcript method:
   - **YouTube Data API**: Enter your Google API key
   - **SupaData API**: Enter base URL and API key
3. Click "Test API" to verify connection
4. Save settings

### Step 2: Setup YouTube Import

1. Go to **IPV Video → Import & Sync**
2. Enter your YouTube API key (if not done in Step 1)
3. Enter your channel handle (e.g., `@ilpuntodivista`)
4. Choose import preferences
5. Save settings

### Step 3: Import Videos

1. Go to **IPV Video → Import & Sync**
2. Click "Start Import Now"
3. Monitor progress in real-time
4. View import results

### Step 4: Schedule Auto-Import (Optional)

1. Go to **IPV Video → Import & Sync**
2. In "Sync Scheduler", choose frequency
3. Click "Save Schedule"
4. Check next scheduled sync time

## 📖 Usage

### Display Video Wall

**Shortcode:**
```
[ipv-wall per_page="9"]
```

**Gutenberg Block:**
1. Add new block
2. Search for "IPV Wall"
3. Configure settings
4. Publish

**Elementor Widget:**
1. Search for "IPV Wall" widget
2. Drag to page
3. Configure settings
4. Publish

### Manage Videos

1. Go to **IPV Video** (main menu)
2. View all imported videos
3. Edit video details
4. Regenerate AI content
5. View/edit transcripts

## 🎨 Customization

### Custom CSS
Add custom styles to `wp-content/uploads/ipv-custom.css`

### Custom Templates
Copy templates from plugin to your theme:
```
your-theme/ipv-video-suite-pro/templates/
```

### Hooks & Filters

**Filters:**
- `ipv_video_query_args` - Modify video query
- `ipv_wall_template` - Custom wall template
- `ipv_import_video_data` - Modify imported data
- `ipv_ai_prompt` - Customize AI prompt

**Actions:**
- `ipv_before_import` - Before import starts
- `ipv_after_import` - After import completes
- `ipv_video_imported` - When single video imported

## 🔧 Troubleshooting

### Videos not importing?
1. Check API keys in Trascrizioni settings
2. Test APIs to verify connection
3. Check WordPress debug.log
4. Verify channel handle is correct

### Transcripts not working?
1. Verify SupaData API credentials
2. Test API connection
3. Check if video has captions enabled
4. Try switching to YouTube Data API

### Scheduled import not working?
1. Check WordPress cron is working
2. Verify import frequency is not "disabled"
3. Check server timezone settings

## 📚 API Endpoints

**REST API Base:** `/wp-json/ipv/v1/`

- `GET /videos` - List all videos
- `GET /videos/{id}` - Get single video
- `POST /import` - Trigger import
- `GET /stats` - Get statistics

## 🔐 Security

- Nonce verification on all AJAX requests
- Capability checks (`manage_options`)
- Input sanitization and validation
- SQL injection prevention
- XSS protection

## 🌐 Languages

Currently available in:
- English (en_US)
- Italian (it_IT) - Ready for translation

To translate:
1. Use POT file in `/languages/ipv.pot`
2. Create MO/PO files with Poedit
3. Save to `/wp-content/languages/plugins/`

## 📝 Changelog

### Version 12.0.0 (2025-10-15)
- ✨ Complete redesign with Bootstrap 5
- ✨ New modern admin dashboard
- ✨ Enhanced Import & Sync page
- ✨ Dedicated Transcriptions page with API toggle
- ✨ Advanced Analytics dashboard with charts
- ✨ New Tools page with cache management
- ✨ Improved AJAX handling
- ✨ Better error handling and logging
- ✨ Real-time import progress tracking
- ✨ API usage monitoring
- 🐛 Fixed numerous bugs from previous versions
- 🔧 Performance optimizations
- 📚 Comprehensive documentation

### Version 11.1.0
- Previous stable release

## 👨‍💻 Developer Info

**Author:** Il Punto di Vista  
**Website:** https://ilpuntodivista.com  
**Support:** info@ilpuntodivista.com

## 📄 License

GPL v2 or later - https://www.gnu.org/licenses/gpl-2.0.html

## 🙏 Credits

- Bootstrap 5 - https://getbootstrap.com
- Chart.js - https://www.chartjs.org
- OpenAI GPT-4 - https://openai.com
- SupaData - https://supadata.ai

---

**Made with ❤️ for Il Punto di Vista**
