# 🚀 IPV Video Suite Pro v13.2.0 - INSTALLAZIONE RAPIDA

## ✅ NOVITÀ v13.2.0 - FIX CRITICO

**PROBLEMA RISOLTO:** La generazione automatica con OpenAI ora funziona! 

Mancavano i campi per configurare OpenAI nelle impostazioni. Ora sono stati aggiunti e il plugin funziona correttamente.

---

## 📦 INSTALLAZIONE

### Metodo 1: Upload ZIP (Consigliato)
1. WordPress Admin → Plugin → Aggiungi nuovo
2. Carica plugin → Scegli file
3. Seleziona `ipv-video-suite-pro-v13.2-FUNZIONANTE.zip`
4. Installa → Attiva

### Metodo 2: FTP
1. Estrai il file ZIP
2. Carica la cartella `ipv-video-suite-pro` via FTP in `/wp-content/plugins/`
3. WordPress Admin → Plugin → Attiva "IPV Video Suite Pro"

---

## ⚙️ CONFIGURAZIONE INIZIALE (5 MINUTI)

### 1️⃣ Configura le API Keys

Vai in: **WordPress Admin → IPV Video → ⚙️ Impostazioni**

#### YouTube API (Opzionale)
- **Dove ottenerla:** https://console.cloud.google.com/apis/credentials
- **Serve per:** Import automatici da canale YouTube

#### SupaData API (Necessaria)
- **Dove ottenerla:** https://supadata.ai
- **Serve per:** Scaricare trascrizioni dei video

#### OpenAI API (Necessaria) ⭐ NUOVO!
- **Dove ottenerla:** https://platform.openai.com/api-keys
- **Serve per:** Generazione automatica descrizioni
- **Modello consigliato:** GPT-4o Mini (veloce ed economico)

### 2️⃣ Verifica Stato Configurazione

La dashboard mostrerà:
- ✅ YouTube API (verde se configurata)
- ✅ SupaData API (verde se configurata)
- ✅ OpenAI API (verde se configurata)

Se vedi ❌ rossi, significa che mancano ancora alcune API keys.

---

## 🎬 PRIMO IMPORT

### Importa un Video di Test
1. **IPV Video → Import & Sync**
2. Incolla un URL YouTube (es: `https://www.youtube.com/watch?v=dQw4w9WgXcQ`)
3. Clicca "Importa"
4. ✅ Il plugin:
   - Scarica thumbnail
   - Recupera info da YouTube
   - Scarica trascrizione da SupaData
   - Genera descrizione con OpenAI
   - Popola tutti i campi automaticamente!

---

## 📊 COSA VIENE GENERATO AUTOMATICAMENTE

Quando importi un video con tutto configurato correttamente, il plugin genera:

- ✅ **Titolo ottimizzato** (max 100 caratteri per YouTube)
- ✅ **Descrizione SEO** (max 1200 caratteri)
- ✅ **Sponsor** (con fallback a Biovital)
- ✅ **Minutaggio** (00:00 – Intro, 05:23 – Topic, etc.)
- ✅ **Argomenti trattati** (lista)
- ✅ **Ospiti** (se presenti)
- ✅ **Persone menzionate** (se presenti)
- ✅ **Hashtag** (max 30, pertinenti)
- ✅ **Link utili** (se presenti nel video)
- ✅ **Eventi** (se menzionati)

Tutto questo **SENZA intervento manuale**! 🎉

---

## 🐛 TROUBLESHOOTING

### Problema: I campi rimangono vuoti dopo l'import

**Causa:** API keys non configurate o non valide

**Soluzione:**
1. Vai in **IPV Video → ⚙️ Impostazioni**
2. Verifica che tutte le API keys siano inserite
3. Controlla che le API keys siano valide (prova su rispettivi siti)
4. Verifica di avere crediti su OpenAI (platform.openai.com)

### Problema: Voglio vedere log dettagliati

**Soluzione:**
1. Attiva WordPress debug in `wp-config.php`:
   ```php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   define('WP_DEBUG_DISPLAY', false);
   ```
2. Controlla `wp-content/debug.log`
3. Cerca messaggi tipo:
   - `🚀 IPV: Inizio generate_for_post`
   - `❌ IPV: Errore...`
   - `✅ IPV: Trascrizione scaricata`
   - `🤖 IPV: Chiamo OpenAI`

### Problema: OpenAI restituisce errore

**Possibili cause:**
- ❌ API key non valida → Verifica su platform.openai.com
- ❌ Crediti esauriti → Ricarica su platform.openai.com
- ❌ Rate limit raggiunto → Aspetta qualche minuto
- ❌ Modello non disponibile → Usa GPT-4o Mini

---

## 💰 COSTI STIMATI

### Con GPT-4o Mini (Consigliato)
- **Per video:** ~€0.002 (0.2 centesimi)
- **100 video:** ~€0.20
- **1000 video:** ~€2.00

### Con GPT-4o
- **Per video:** ~€0.03 (3 centesimi)
- **100 video:** ~€3.00
- **1000 video:** ~€30.00

**Risparmio rispetto al lavoro manuale:**
- Tempo: da 15 min → 0 min per video
- Costo: da €15 → €0.002 per video
- **ROI: 99.98%** 🎉

---

## 📝 FUNZIONALITÀ PRINCIPALI

### Import
- ✅ Import singolo da URL/ID YouTube
- ✅ Bulk import da lista IDs
- ✅ Import automatico da canale
- ✅ Sincronizzazione automatica

### Trascrizioni
- ✅ Download automatico da SupaData
- ✅ Multi-lingua (default: italiano)
- ✅ Visualizzazione trascrizione nel post editor
- ✅ Ricarica manuale se necessario

### AI Generation
- ✅ Generazione automatica all'import
- ✅ Rigenera manualmente con pulsante "Genera dai Transcript (AI)"
- ✅ Fallback intelligenti per campi mancanti
- ✅ Logging dettagliato per debug

### Tools
- ✅ Rigenera thumbnail da YouTube
- ✅ Ricarica trascrizione da SupaData
- ✅ Rigenera testi con AI
- ✅ Svuota dati AI (reset)
- ✅ Esporta descrizione in formato .txt

### Video Wall
- ✅ Layout moderno e responsive
- ✅ Filtri per categoria
- ✅ Paginazione
- ✅ Thumbnails ottimizzate

---

## 🔧 REQUISITI TECNICI

- **WordPress:** 5.8 o superiore
- **PHP:** 7.4 o superiore
- **API Keys:** OpenAI, SupaData (obbligatorie), YouTube (opzionale)
- **Internet:** Connessione stabile per chiamate API

---

## 📞 SUPPORTO

Se hai problemi:
1. Controlla il debug.log
2. Verifica le API keys
3. Verifica i crediti OpenAI
4. Leggi il CHANGELOG-v13.2.md per dettagli tecnici

---

## 🎉 BUON LAVORO!

Questo plugin ti farà risparmiare **ORE** di lavoro manuale. Divertiti! 🚀

---

**Versione:** 13.2.0  
**Data:** 19 Ottobre 2025  
**Status:** ✅ PRODUCTION READY
