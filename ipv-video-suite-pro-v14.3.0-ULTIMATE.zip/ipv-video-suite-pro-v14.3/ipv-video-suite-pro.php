<?php
require_once plugin_dir_path(__FILE__) . 'includes/admin-menu-fix.php';

/**
 * Plugin Name: IPV Video Suite Pro - Ultimate Edition
 * Plugin URI: https://ilpuntodivistachannel.com
 * Description: Ultimate video management suite combining best features from Pro and Ultimate - Complete YouTube integration, SupaData AI, OpenAI, Analytics, Advanced Cache & Logging
 * Version: 14.3.0
 * Author: IPV Team
 * Author URI: https://ilpuntodivistachannel.com
 * Text Domain: ipv
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * 
 * Ultimate Edition v13.0.0 - Best of Both Worlds:
 * 
 * 🎉 NEW v13.0.0 - ULTIMATE EDITION:
 * From Pro v12.2.3 (Core Foundation):
 * - ✅ SupaData authentication fixed (x-api-key)
 * - ✅ YouTube Data API v3 full integration
 * - ✅ Bulk import from IDs, URLs, Channel
 * - ✅ Regenerate thumbnails & transcripts
 * - ✅ Video Wall modern layout
 * - ✅ Manual & Auto import
 * 
 * From Ultimate v4.0.0 (Advanced Features):
 * - ✅ Advanced Logger system with detailed logs
 * - ✅ Intelligent Cache system
 * - ✅ Video Analytics tracking
 * - ✅ Custom Admin Columns
 * - ✅ OpenAI integration (working perfectly)
 * - ✅ Enhanced Frontend Wall
 * - ✅ Advanced Dashboard
 * 
 * Result: Best plugin ever! 🚀
 * - ✅ YouTube works perfectly
 * - ✅ SupaData works perfectly
 * - ✅ OpenAI works perfectly
 * - ✅ Analytics + Logger + Cache
 * - ✅ All import methods working
 * - ✅ Professional admin interface
 * 
 * CRITICAL BUGFIX v12.2.3:
 * - ✅ Fixed SupaData 401/403 authentication error
 * - ✅ Restored correct API header: 'x-api-key' (was incorrectly changed to 'Authorization: Bearer')
 * - ✅ Now works with official SupaData API format
 * - ✅ Test connection now successful
 * 
 * NEW v12.2.2:
 * - ✅ Bulk Tools menu semplificato (Import + Rigenera)
 * - ✅ Import massivo da lista video IDs (1 per riga)
 * - ✅ Rigenera thumbnail per tutti i video
 * - ✅ Rigenera trascrizioni SupaData
 * - ✅ Filtri: tutti i video / solo mancanti
 * - ✅ Log dettagliato operazioni
 * - ✅ UI minimalista e veloce
 * 
 * BUGFIX v12.2.1 (REVERTED in v12.2.3):
 * - ⚠️ INCORRECTLY Changed API header from 'x-api-key' to 'Authorization: Bearer'
 * - ⚠️ This caused 401/403 errors - Fixed in v12.2.3
 * 
 * NEW FEATURES v12.2.0:
 * - ✅ Bulk Import massivo da canale YouTube
 * - ✅ Bulk Import da lista video IDs
 * - ✅ Bulk Import da lista URLs
 * - ✅ Filtri per tipo (tutti, normali, shorts, live)
 * - ✅ Auto-fetch trascrizioni SupaData durante bulk import
 * - ✅ Script JavaScript per estrazione IDs automatica
 * - ✅ Video Wall layout moderno e responsive
 * - ✅ Bottone "Carica più video" con loading
 * - ✅ Thumbnail con overlay YouTube play button
 * - ✅ Badge tipo video (short/live)
 * - ✅ Durata video, visualizzazioni, data
 * - ✅ Link diretti a YouTube o CPT (configurabile)
 * - ✅ Griglia responsive (3/2/1 colonne)
 * - ✅ Dark mode support
 * 
 * CRITICAL BUGFIX v12.1.2:
 * - Fixed Fatal Error "Cannot access offset of type string on string"
 * - Added is_array() checks in save_transcript_settings()
 * - Fixed array type validation in class-ajax.php line 463
 * - Added safety checks in class-dashboard.php for ai_settings, activity, history
 * - Prevents crashes when WordPress options return wrong types
 * 
 * BUGFIXES v12.1.1:
 * - Fixed SupaData API endpoints (YouTube-specific vs Universal)
 * - Improved error handling with detailed messages
 * - Added platform-based endpoint selection
 * - Enhanced connection test with better diagnostics
 * - Fixed HTTP 404 handling
 * - Added comprehensive diagnostic documentation
 * 
 * FEATURES v12.1.0:
 * - All original v12 features (56 files, 655KB)
 * - Enhanced SupaData transcript integration
 * - Fixed get_video_url() method
 * - Complete settings UI
 * - Auto-fetch transcripts
 * - Post meta storage
 * - Batch operations
 * - Better error handling
 * - Comprehensive documentation (9 files)
 * - Gutenberg blocks
 * - Legacy compatibility
 * - Elementor widgets (optional)
 */

if (!defined('ABSPATH')) exit;

// ========================================
// PLUGIN CONSTANTS
// ========================================
define('IPV_VSP_VER', '13.0.0');
define('IPV_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('IPV_PLUGIN_URL', plugin_dir_url(__FILE__));
define('IPV_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('IPV_PLUGIN_FILE', __FILE__);

// Ultimate Edition compatibility constants
define('IPVCPT_VERSION', '13.0.0');
define('IPVCPT_PATH', plugin_dir_path(__FILE__));
define('IPVCPT_URL', plugin_dir_url(__FILE__));
define('IPVCPT_CPT', 'ipv_video');
define('IPVCPT_CACHE_GROUP', 'ipvcpt');
define('IPVCPT_LOG_TABLE', 'ipvcpt_logs');

// ========================================
// AUTOLOAD CLASSES
// ========================================

// Core classes
require_once IPV_PLUGIN_DIR . 'includes/class-settings.php';
require_once IPV_PLUGIN_DIR . 'includes/class-logger.php';
require_once IPV_PLUGIN_DIR . 'includes/class-cache.php';
require_once IPV_PLUGIN_DIR . 'includes/class-cpt.php';
require_once IPV_PLUGIN_DIR . 'includes/class-dashboard.php';
require_once IPV_PLUGIN_DIR . 'includes/class-ajax.php';
require_once IPV_PLUGIN_DIR . 'includes/class-rest.php';
require_once IPV_PLUGIN_DIR . 'includes/class-importer.php';
require_once IPV_PLUGIN_DIR . 'includes/class-bulk-importer.php';
require_once IPV_PLUGIN_DIR . 'includes/class-wall.php';
require_once IPV_PLUGIN_DIR . 'includes/class-admin-columns.php';
require_once IPV_PLUGIN_DIR . 'includes/class-analytics.php';
require_once IPV_PLUGIN_DIR . 'includes/class-frontend-wall.php';

// Integration classes
require_once IPV_PLUGIN_DIR . 'includes/class-supadata.php';
require_once IPV_PLUGIN_DIR . 'includes/class-supadata-ajax.php';
require_once IPV_PLUGIN_DIR . 'includes/class-openai.php';

// Ultimate Edition v14.3 - Professional Tools
require_once IPV_PLUGIN_DIR . 'includes/class-dashboard-ultimate.php';
require_once IPV_PLUGIN_DIR . 'includes/class-tools-advanced.php';

// Widget classes - DISABLED to avoid Fatal Errors
// NOTE: To use Elementor widgets, install Elementor plugin first
// then uncomment these lines
/*
if (did_action('elementor/loaded')) {
    require_once IPV_PLUGIN_DIR . 'includes/widget-ipv-wall.php';
    require_once IPV_PLUGIN_DIR . 'includes/class-elementor-widget.php';
}
*/

// ========================================
// PLUGIN INITIALIZATION
// ========================================

class IPV_Video_Suite_Pro {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Init hooks
        add_action('plugins_loaded', [$this, 'init']);
        add_action('init', [$this, 'load_textdomain']);
        
        // Activation/Deactivation
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
    }
    
    public function init() {
        // Initialize core classes
        IPV_Settings::init();
        IPV_Logger::init();
        IPV_Cache::init(); // Cache has init() method
        IPV_CPT::init();
        IPV_Dashboard::init();
        IPV_Ajax::init();
        IPV_REST::init();
        if ( class_exists('IPV_Importer') && method_exists('IPV_Importer','init') ) { IPV_Importer::init(); }
        IPV_Bulk_Importer::init();
        IPV_Wall::init();
        IPV_Admin_Columns::init();
        IPV_Frontend_Wall::init();
        // IPV_Analytics::init(); // REMOVED: Analytics non ha metodo init() - usa solo metodi statici
        
        // Initialize integrations
        if ( ! class_exists('IPV_SupaData') ) { require_once plugin_dir_path(__FILE__) . 'includes/class-supadata.php'; }
require_once plugin_dir_path(__FILE__) . 'includes/class-fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-youtube.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-tools.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-bulk.php';
if ( class_exists('IPV_SupaData') && method_exists('IPV_SupaData','init') ) { if ( class_exists('IPV_SupaData') && method_exists('IPV_SupaData','init') ) { IPV_SupaData::init(); } }
        IPV_SupaData_Ajax::init();
        // IPV_OpenAI::init(); // REMOVED: OpenAI non ha metodo init() - usa solo metodi statici
        
        // Initialize widgets - DISABILITATO: IPV_Wall_Widget non esiste
        // TODO: Crea la classe IPV_Wall_Widget se necessario
        /*
        add_action('widgets_init', function() {
            register_widget('IPV_Wall_Widget');
        });
        */
        
        // Initialize Elementor widgets - DISABILITATO per evitare Fatal Error
        // NOTA: Decommenta solo dopo aver installato Elementor
        /*
        if (did_action('elementor/loaded')) {
            add_action('elementor/widgets/register', function($widgets_manager) {
                if (class_exists('IPV_Elementor_Widget')) {
                    $widgets_manager->register(new IPV_Elementor_Widget());
                }
            });
        }
        */
        
        // Initialize blocks
        add_action('init', [$this, 'register_blocks']);
    }
    
    public function load_textdomain() {
        load_plugin_textdomain(
            'ipv',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }
    
    public function register_blocks() {
        // Register IPV Wall block
        if (file_exists(IPV_PLUGIN_DIR . 'blocks/ipv-wall/block.json')) {
            register_block_type(IPV_PLUGIN_DIR . 'blocks/ipv-wall');
        }
    }
    
    public function activate() {
        // Create custom post type
        IPV_CPT::init();
        flush_rewrite_rules();
        
        // Create logs table
        IPV_Logger::create_table();
        
        // Initialize logger
        IPV_Logger::init();
        
        // Create default settings
        if (!get_option('ipv_settings')) {
            $defaults = [
                'youtube_api_key' => '',
                'supadata_key' => '',
                'supadata_base' => 'https://api.supadata.ai/v1',
                'supadata_mode' => 'auto',
                'supadata_lang' => 'en',
                'supadata_timeout' => 60,
                'openai_key' => '',
                'cache_enabled' => true,
                'cache_duration' => 3600,
            ];
            update_option('ipv_settings', $defaults);
        }
        
        // Log activation
        IPV_Logger::log('IPV Video Suite Pro activated', 'info');
    }
    
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Log deactivation
        IPV_Logger::log('IPV Video Suite Pro deactivated', 'info');
    }
}

// ========================================
// INITIALIZE PLUGIN
// ========================================

function ipv_video_suite_pro() {
    return IPV_Video_Suite_Pro::get_instance();
}

// Start the plugin
ipv_video_suite_pro();

add_action('plugins_loaded', function(){ if (class_exists('IPV_Fields')) IPV_Fields::init(); }, 12);

add_action('plugins_loaded', function(){ if (class_exists('IPV_YouTube')) IPV_YouTube::init(); }, 13);
add_action('plugins_loaded', function(){ if (class_exists('IPV_Tools')) IPV_Tools::init(); }, 14);
add_action('plugins_loaded', function(){ if (class_exists('IPV_Bulk')) IPV_Bulk::init(); }, 15);
