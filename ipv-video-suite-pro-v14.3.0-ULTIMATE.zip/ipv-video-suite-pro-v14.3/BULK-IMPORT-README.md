# IPV Video Suite Pro v12.2.0 - BULK IMPORT & MODERN VIDEO WALL

🚀 **Nuove funzionalità aggiunte nella versione 12.2.0**

---

## ✨ NOVITÀ PRINCIPALI

### 1. 📥 **BULK IMPORT MASSIVO**

Sistema completo per importare centinaia di video in pochi click!

#### 🎯 3 Metodi di Importazione

**A) Da Canale YouTube**
- Importa TUTTI i video di un canale
- Usa Channel ID o Handle (@nomeutente)
- Filtro per tipo: tutti / normali / shorts / live
- Max 500 video per importazione

**B) Da Lista Video IDs**
- Incolla una lista di video IDs YouTube
- Supporta newline, virgole, spazi
- Perfetto per liste personalizzate

**C) Da Lista URLs**
- Incolla URLs complete YouTube
- Supporta youtube.com/watch?v= e youtu.be/
- Estrae automaticamente i video IDs

#### ⚙️ Opzioni Avanzate

- ✅ **Auto-fetch trascrizioni SupaData** durante l'importazione
- ✅ **Filtra per tipo video** (shorts, normali, live)
- ✅ **Skip automatico** dei video già esistenti
- ✅ **Progress tracking** in tempo reale
- ✅ **Log dettagliato** di ogni importazione
- ✅ **Auto-download thumbnail** da YouTube

---

### 2. 🎨 **VIDEO WALL MODERNO**

Nuovo layout professionale con design YouTube-style!

#### 🌟 Caratteristiche

- ✅ **Griglia responsive** (3/2/1 colonne)
- ✅ **Card moderne** con effetti hover
- ✅ **Thumbnail 16:9** con overlay YouTube
- ✅ **Play button animato** al hover
- ✅ **Badge tipo video** (Short / Live)
- ✅ **Durata video** in overlay
- ✅ **Visualizzazioni e data** pubblicazione
- ✅ **Bottone "Carica più video"** con loading
- ✅ **Dark mode support** automatico
- ✅ **Link configurabili** (YouTube o CPT)

---

## 📖 GUIDA UTILIZZO

### BULK IMPORT: Importa da Canale

1. Vai su **IPV Video → 📥 Bulk Import**
2. Tab "Da Canale"
3. Inserisci Channel ID o Handle (es: `@ilpuntodivista`)
4. Scegli numero max video (1-500)
5. Opzionale: filtra per tipo (tutti/normali/shorts/live)
6. Opzionale: abilita auto-fetch trascrizioni
7. Click **"Avvia Importazione"**

**Tempo di importazione:**
- ~1-2 secondi per video
- 100 video = ~2-3 minuti
- Include download thumbnail automatico

---

### BULK IMPORT: Importa da Lista IDs

1. Vai su **IPV Video → 📥 Bulk Import**
2. Tab "Da Video IDs"
3. Incolla i video IDs nel campo (uno per riga, o separati da virgole)
4. Click **"Importa Video IDs"**

**Esempio formato IDs:**
```
dQw4w9WgXcQ
J7p4bzqLvCw
kJQP7kiw5Fk
```

---

### BULK IMPORT: Importa da Lista URLs

1. Vai su **IPV Video → 📥 Bulk Import**
2. Tab "Da URLs"
3. Incolla le URLs complete (una per riga)
4. Click **"Importa URLs"**

**Esempio formato URLs:**
```
https://www.youtube.com/watch?v=dQw4w9WgXcQ
https://youtu.be/J7p4bzqLvCw
https://www.youtube.com/watch?v=kJQP7kiw5Fk
```

---

### 🤖 SCRIPT JAVASCRIPT: Estrazione Automatica IDs

Vuoi estrarre TUTTI i video IDs da un canale YouTube in 1 minuto?

**Procedura:**

1. Vai su `youtube.com/@tuocanale/videos`
2. Apri Console browser (F12 → tab Console)
3. Incolla questo script:

```javascript
(async function() {
  let ids = new Set();
  let lastHeight = 0;
  
  while (true) {
    // Scroll fino in fondo
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 2000));
    
    // Estrai video IDs
    document.querySelectorAll('a[href*="/watch?v="]').forEach(a => {
      let match = a.href.match(/watch\?v=([a-zA-Z0-9_-]{11})/);
      if (match) ids.add(match[1]);
    });
    
    // Stop se non scrollabile
    if (document.body.scrollHeight === lastHeight) break;
    lastHeight = document.body.scrollHeight;
    
    console.log(`Trovati ${ids.size} video...`);
  }
  
  // Copia negli appunti
  let result = Array.from(ids).join('\n');
  navigator.clipboard.writeText(result);
  console.log(`✅ ${ids.size} video IDs copiati negli appunti!`);
})();
```

4. Aspetta 1-2 minuti (scrollerà automaticamente)
5. Gli IDs vengono copiati automaticamente negli appunti!
6. Vai su **IPV Video → Bulk Import → Da Video IDs**
7. Incolla e importa!

---

### VIDEO WALL: Shortcode

Usa il nuovo shortcode `[ipv_wall]` con tutti i parametri disponibili:

```php
[ipv_wall 
    per_page="12" 
    columns="3" 
    only_horizontal="1"
    show_title="1"
    show_duration="1"
    show_date="0"
    target="youtube"
    category=""
]
```

#### 📋 Parametri Disponibili

| Parametro | Valori | Default | Descrizione |
|-----------|--------|---------|-------------|
| `per_page` | 1-100 | 12 | Video per pagina |
| `columns` | 1-6 | 3 | Numero colonne griglia |
| `only_horizontal` | 0/1 | 1 | Solo video orizzontali |
| `show_title` | 0/1 | 1 | Mostra titolo video |
| `show_duration` | 0/1 | 1 | Mostra durata |
| `show_date` | 0/1 | 0 | Mostra data pubblicazione |
| `target` | youtube/cpt | youtube | Link a YouTube o CPT |
| `category` | slug | - | Filtra per categoria |

#### 📝 Esempi Shortcode

**Video wall base (3 colonne):**
```php
[ipv_wall]
```

**Video wall 4 colonne, 20 video per pagina:**
```php
[ipv_wall columns="4" per_page="20"]
```

**Video wall con tutti i video (anche shorts):**
```php
[ipv_wall only_horizontal="0"]
```

**Video wall con link ai CPT invece di YouTube:**
```php
[ipv_wall target="cpt"]
```

**Video wall con data e visualizzazioni:**
```php
[ipv_wall show_date="1"]
```

**Video wall filtrato per categoria:**
```php
[ipv_wall category="tutorial"]
```

---

## 🛠️ FILE MODIFICATI/AGGIUNTI

### ✅ Nuovi File

```
includes/class-bulk-importer.php       → Classe bulk import completa
admin/bulk-import-page.php             → Pagina admin bulk import
assets/bulk-import.css                 → Stili pagina bulk import
assets/bulk-import.js                  → JavaScript bulk import
```

### ✅ File Aggiornati

```
includes/class-wall.php                → Nuovo layout moderno
assets/wall.css                        → Nuovi stili video wall
assets/wall.js                         → Nuovo JavaScript load more
ipv-video-suite-pro.php                → Inizializzazione bulk importer
```

---

## 🎯 FUNZIONALITÀ CHIAVE

### Bulk Importer

✅ Import massivo da canale (fino a 500 video)
✅ Import da lista IDs / URLs
✅ Filtro per tipo (tutti/normali/shorts/live)
✅ Auto-fetch trascrizioni SupaData
✅ Skip automatico duplicati
✅ Progress tracking in tempo reale
✅ Log dettagliato importazioni
✅ Auto-download thumbnail HD

### Video Wall

✅ Layout moderno responsive
✅ Griglia 3/2/1 colonne (auto-responsive)
✅ Card con effetti hover professionali
✅ Thumbnail 16:9 con overlay YouTube
✅ Play button animato
✅ Badge tipo video (Short/Live)
✅ Durata in overlay
✅ Visualizzazioni e data
✅ Bottone "Carica più video" dinamico
✅ Loading state elegante
✅ Dark mode automatico
✅ Link configurabili (YouTube/CPT)

---

## 🚀 WORKFLOW COMPLETO

### Setup Iniziale

1. **Configura API Keys**
   - YouTube Data API v3 (OBBLIGATORIA)
   - SupaData API (opzionale, per trascrizioni)
   
2. **Bulk Import**
   - Importa tutto il canale in blocco
   - Oppure usa script JS per estrazione IDs selettivi
   
3. **Gestione Post-Import**
   - Filtra shorts/live dalla lista video
   - Usa bulk actions per modifiche massive
   
4. **Visualizzazione Frontend**
   - Usa shortcode `[ipv_wall]` nel tuo sito
   - Personalizza layout e opzioni

---

## ⚠️ REQUISITI

- **YouTube Data API v3** - OBBLIGATORIA per bulk import
- **PHP 7.4+**
- **WordPress 5.8+**
- **SupaData API** (opzionale, per trascrizioni automatiche)

---

## 🆘 SUPPORTO & FAQ

### Come ottengo YouTube Data API v3?

1. Vai su [Google Cloud Console](https://console.cloud.google.com)
2. Crea progetto → Abilita YouTube Data API v3
3. Crea credenziali → API Key
4. Inseriscila in IPV Video → Settings

### Quanti video posso importare?

Tecnicamente illimitati! Consigliamo batch di 50-100 alla volta per evitare timeout PHP.

### I video vengono duplicati?

No! Il sistema salta automaticamente i video già esistenti (verifica per YouTube ID).

### Posso filtrare gli shorts?

Sì! Usa il filtro "Solo video normali" durante l'import, oppure filtrali dopo nella lista video.

### Il video wall supporta paginazione?

Sì! Il bottone "Carica più video" carica dinamicamente nuovi video senza refresh della pagina.

### Posso personalizzare lo stile del video wall?

Sì! Modifica `/assets/wall.css` oppure sovrascrivi gli stili dal tuo tema.

---

## 📊 CHANGELOG v12.2.0

```
[ADDED] Bulk Import massivo da canale YouTube
[ADDED] Bulk Import da lista video IDs
[ADDED] Bulk Import da lista URLs
[ADDED] Filtri per tipo video (tutti/normali/shorts/live)
[ADDED] Auto-fetch trascrizioni durante bulk import
[ADDED] Script JavaScript per estrazione IDs
[ADDED] Nuovo video wall layout moderno
[ADDED] Bottone "Carica più video" dinamico
[ADDED] Thumbnail con overlay YouTube play button
[ADDED] Badge tipo video (Short/Live)
[ADDED] Durata video in overlay
[ADDED] Visualizzazioni e data pubblicazione
[ADDED] Link configurabili (YouTube/CPT)
[ADDED] Griglia responsive (3/2/1 colonne)
[ADDED] Dark mode support
[IMPROVED] Performance AJAX load more
[IMPROVED] Gestione errori bulk import
[IMPROVED] UI/UX pagina admin
```

---

## 👨‍💻 CREDITS

Sviluppato da **IPV Team**
Plugin: IPV Video Suite Pro
Versione: 12.2.0
Website: https://ilpuntodivistachannel.com

---

## 📄 LICENZA

GPL v2 or later
https://www.gnu.org/licenses/gpl-2.0.html

---

🎉 **Buon utilizzo del tuo nuovo sistema di bulk import!**
