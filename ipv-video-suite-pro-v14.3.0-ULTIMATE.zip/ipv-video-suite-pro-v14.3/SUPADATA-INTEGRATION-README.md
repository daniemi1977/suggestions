# IPV Video Suite Pro - SupaData Integration v2.0

## 🎉 Cosa è stato ottimizzato

Integrazione **completa e production-ready** con **SupaData API v1** secondo la documentazione ufficiale.

---

## ✨ Nuove Features

### 1. **Classe IPV_SupaData Ottimizzata**
📁 `includes/class-supadata.php`

**Implementazioni:**
- ✅ Supporto **tutte le piattaforme**: YouTube, TikTok, Instagram, X (Twitter), File URL
- ✅ Tre modalità: `auto`, `native`, `generate`
- ✅ Gestione **sincrona (HTTP 200)** e **asincrona (HTTP 202)**
- ✅ Polling intelligente con **backoff esponenziale**
- ✅ Multi-lingua con **gestione fallback**
- ✅ Validazione URL automatica
- ✅ Stati job: `queued` → `active` → `completed`/`failed`
- ✅ Logging dettagliato
- ✅ Gestione errori completa
- ✅ Stima crediti

**API Methods:**
```php
// Test connessione
IPV_SupaData::test_connection()

// Valida URL
IPV_SupaData::validate_url($url)

// Fetch transcript
IPV_SupaData::fetch_transcript($video_id, $options)

// Stima crediti
IPV_SupaData::estimate_credits($mode, $duration)
```

---

### 2. **Test Suite Completa**
📁 `includes/class-supadata-tests.php`

**6 Test automatici:**
1. ✓ Test Connessione API
2. ✓ Validazione URL (8 casi)
3. ✓ YouTube Transcript (mode=native)
4. ✓ Transcript con timestamp chunks
5. ✓ Gestione errori
6. ✓ Stima crediti

**Esegui tests:**
```bash
wp eval-file includes/class-supadata-tests.php
```

---

### 3. **Dashboard Admin Interattiva**
📁 `admin/dashboard-supadata-section.php`

**Features UI:**
- 🎨 Design Bootstrap 5 moderno
- ⚡ Test connessione real-time
- 🔍 Validazione URL interattiva
- 📥 Fetch transcript con preview
- 💰 Calcolatore crediti
- 📊 Info piattaforme supportate
- 📚 Link documentazione

---

### 4. **AJAX Handlers**
📁 `includes/class-supadata-ajax.php`

**5 Endpoints AJAX:**
- `ipv_test_supadata_connection` - Test API
- `ipv_validate_supadata_url` - Valida URL
- `ipv_fetch_supadata_transcript` - Fetch transcript
- `ipv_estimate_supadata_credits` - Stima crediti
- `ipv_get_supadata_config` - Get configurazione

---

### 5. **Documentazione Completa**
📁 `SUPADATA-DOCS.md`

**Contenuto:**
- 📖 Quick Start Guide
- 🔑 API Reference completo
- 💡 Best Practices
- 🎯 Quando usare auto/native/generate
- 🌍 Lingue supportate
- 🐛 Troubleshooting
- ✅ Esempi pratici

---

## 🔧 Miglioramenti Tecnici

### Rispetto alla versione precedente:

| Feature | Prima | Ora |
|---------|-------|-----|
| **Piattaforme supportate** | Solo YouTube | YouTube, TikTok, Instagram, X, File |
| **Validazione URL** | ❌ Assente | ✅ Automatica |
| **Gestione job asincroni** | Polling base | Backoff esponenziale |
| **Stati job loggati** | ❌ No | ✅ Tutti gli stati |
| **Multi-lingua** | Basic | Fallback automatici |
| **Error handling** | Generico | Dettagliato con codici |
| **Test suite** | ❌ Assente | ✅ 6 test automatici |
| **Dashboard UI** | ❌ Assente | ✅ Completa |
| **Stima crediti** | ❌ Assente | ✅ Automatica |

---

## 📋 File Modificati/Aggiunti

### Nuovi File:
```
includes/
├── class-supadata.php (OTTIMIZZATO v2.0)
├── class-supadata-tests.php (NUOVO)
└── class-supadata-ajax.php (NUOVO)

admin/
└── dashboard-supadata-section.php (NUOVO)

SUPADATA-DOCS.md (NUOVO)
```

### File da Integrare:
1. **Plugin Main File** - Include AJAX handlers:
   ```php
   require_once IPV_PLUGIN_DIR . 'includes/class-supadata-ajax.php';
   ```

2. **Dashboard File** - Include sezione SupaData:
   ```php
   require_once IPV_PLUGIN_DIR . 'admin/dashboard-supadata-section.php';
   ```

---

## 🚀 Setup & Configurazione

### 1. Installa i file

Copia i nuovi file nella directory del plugin.

### 2. Configura API Key

Vai su **Dashboard → SupaData** e:
1. Inserisci la tua API key da https://dash.supadata.ai
2. Clicca "Test Connessione API"
3. Verifica che lo status sia "✓ Connessione riuscita!"

### 3. Test Funzionalità

Nella dashboard SupaData:
1. **Valida un URL** - testa YouTube/TikTok/etc
2. **Fetch un transcript** - prova con video ID: `jNQXAC9IVRw`
3. **Stima crediti** - calcola costi per mode/durata

### 4. Integra nel Plugin

```php
// Esempio: Fetch transcript da post
$post_id = 123;
$video_id = get_post_meta($post_id, '_ipv_youtube_id', true);

$transcript = IPV_SupaData::fetch_transcript($video_id, [
    'mode' => 'auto',
    'lang' => 'it'
]);

if ($transcript) {
    // Salva transcript
    update_post_meta($post_id, '_ipv_transcript', $transcript['content']);
    update_post_meta($post_id, '_ipv_transcript_lang', $transcript['lang']);
}
```

---

## 💰 Pricing & Ottimizzazione

### Mode Selection Strategy:

**Use `mode=native` quando:**
- ✅ Elabori molti video (batch)
- ✅ Budget limitato
- ✅ Sai che i video hanno sottotitoli
- 💰 **Costo:** 1 credito/video

**Use `mode=auto` quando:**
- ✅ Non sai se video ha sottotitoli
- ✅ Vuoi massima affidabilità
- ✅ Costo non è critico
- 💰 **Costo:** 1-20+ crediti (varia)

**Use `mode=generate` quando:**
- ✅ Sottotitoli assenti o di bassa qualità
- ✅ Vuoi transcript nella lingua parlata
- ✅ Budget disponibile
- 💰 **Costo:** 2 crediti/minuto

### Esempio Batch Processing:

```php
// Ottimizzato per costi bassi
$videos = get_posts(['post_type' => 'ipv_video', 'posts_per_page' => -1]);

foreach ($videos as $video) {
    $transcript = IPV_SupaData::fetch_transcript($video->ID, [
        'mode' => 'native' // Solo 1 credito
    ]);
    
    if ($transcript) {
        update_post_meta($video->ID, '_transcript', $transcript['content']);
    }
    
    sleep(1); // Rate limit prevention
}
```

---

## 🐛 Troubleshooting

### "API key non valida"
- ✅ Verifica key su https://dash.supadata.ai/organizations/api-key
- ✅ Controlla che sia copiata correttamente (no spazi)

### "Timeout durante polling"
- ✅ Aumenta timeout: `Settings → supadata_timeout → 120`
- ✅ Video molto lunghi richiedono più tempo

### "Video non trovato"
- ✅ Verifica che l'URL sia pubblico
- ✅ Usa validatore URL nella dashboard
- ✅ Controlla formato: YouTube, TikTok, Instagram, X, o File

### Rate Limit (429)
- ✅ Aggiungi `sleep(1)` tra richieste batch
- ✅ Riduci numero richieste simultanee

---

## 📊 Monitoring & Logs

Tutti gli eventi sono loggati in `IPV_Logger`:

```php
// Visualizza logs
$logs = IPV_Logger::get_logs();
foreach ($logs as $log) {
    echo "[{$log['level']}] {$log['message']}\n";
}
```

**Log Levels:**
- `debug` - Dettagli tecnici (polling, endpoints)
- `info` - Operazioni normali (job ricevuti, completati)
- `warn` - Warning non critici (formato non riconosciuto)
- `error` - Errori (connessione fallita, API error)

---

## 🎯 Best Practices

### 1. Cache Transcript
```php
// Verifica cache prima di fetchare
$cached = get_post_meta($post_id, '_transcript', true);
if ($cached) {
    return $cached;
}

// Fetch solo se cache vuota
$transcript = IPV_SupaData::fetch_transcript($video_id);
if ($transcript) {
    update_post_meta($post_id, '_transcript', $transcript['content']);
}
```

### 2. Gestione Lingue Multiple
```php
$preferred_langs = ['it', 'en', 'es'];

foreach ($preferred_langs as $lang) {
    $result = IPV_SupaData::fetch_transcript($video_id, [
        'lang' => $lang,
        'mode' => 'native'
    ]);
    
    if ($result) {
        break; // Trovato!
    }
}
```

### 3. Rate Limiting
```php
foreach ($video_ids as $id) {
    $result = IPV_SupaData::fetch_transcript($id);
    sleep(1); // Pausa 1 secondo tra richieste
}
```

---

## ✅ Checklist Integrazione

- [ ] Copiato tutti i nuovi file
- [ ] Incluso `class-supadata-ajax.php` nel plugin main
- [ ] Incluso `dashboard-supadata-section.php` nella dashboard
- [ ] Configurato API key nelle settings
- [ ] Testato connessione nella dashboard
- [ ] Validato almeno 1 URL
- [ ] Fetchato almeno 1 transcript
- [ ] Verificato logs

---

## 📚 Risorse

- **API Docs:** https://docs.supadata.ai/api-reference/transcript
- **Dashboard:** https://dash.supadata.ai
- **Pricing:** https://supadata.ai/pricing
- **Support:** support@supadata.ai
- **Plugin Docs:** `SUPADATA-DOCS.md`

---

## 🎉 Pronto per la Produzione!

L'integrazione SupaData è **completa, testata e production-ready!**

**Tutte le features della documentazione ufficiale implementate:**
- ✅ Sync & Async responses (HTTP 200/202)
- ✅ Job polling con stati
- ✅ Tutte le piattaforme supportate
- ✅ Mode: auto, native, generate
- ✅ Multi-lingua
- ✅ Error handling
- ✅ Validation
- ✅ Credit estimation
- ✅ Test suite

**Happy coding!** 🚀
