/**
 * Frontend Video Wall JavaScript
 */

(function($) {
    'use strict';
    
    const VideoWall = {
        
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
            this.lazyLoadImages();
        },
        
        /**
         * Bind events
         */
        bindEvents: function() {
            // Load More button
            $('.ipvcpt-load-more-btn').on('click', this.loadMore.bind(this));
            
            // Video card hover effects
            $('.ipvcpt-video-card').on('mouseenter', this.cardHoverIn);
            $('.ipvcpt-video-card').on('mouseleave', this.cardHoverOut);
        },
        
        /**
         * Load More Videos
         */
        loadMore: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const page = parseInt($btn.data('page'));
            const maxPages = parseInt($btn.data('max-pages'));
            const atts = $btn.data('atts');
            const $wall = $('.ipvcpt-video-wall');
            
            $btn.prop('disabled', true).html('<span class="ipvcpt-spinner"></span> Caricamento...');
            
            $.ajax({
                url: ipvcptWall.ajax_url,
                type: 'POST',
                data: {
                    action: 'ipvcpt_load_more_videos',
                    nonce: ipvcptWall.nonce,
                    page: page,
                    atts: JSON.stringify(atts)
                },
                success: function(response) {
                    if (response.success) {
                        // Append new videos
                        const $newVideos = $(response.data.html);
                        $wall.append($newVideos);
                        
                        // Lazy load new images
                        VideoWall.lazyLoadImages();
                        
                        // Update button state
                        if (response.data.has_more) {
                            $btn.data('page', response.data.page);
                            $btn.prop('disabled', false).html('Carica altri video');
                        } else {
                            $btn.fadeOut();
                        }
                        
                        // Bind hover events to new cards
                        $newVideos.on('mouseenter', VideoWall.cardHoverIn);
                        $newVideos.on('mouseleave', VideoWall.cardHoverOut);
                        
                        // Smooth scroll animation
                        $newVideos.css('opacity', '0').animate({ opacity: 1 }, 600);
                    }
                },
                error: function() {
                    alert('Errore nel caricamento dei video');
                    $btn.prop('disabled', false).html('Carica altri video');
                }
            });
        },
        
        /**
         * Lazy Load Images
         */
        lazyLoadImages: function() {
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver(function(entries, observer) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            const $thumb = $(entry.target);
                            const bgImage = $thumb.css('background-image');
                            
                            if (bgImage && bgImage !== 'none') {
                                $thumb.addClass('loaded');
                                observer.unobserve(entry.target);
                            }
                        }
                    });
                });
                
                $('.ipvcpt-video-thumb').each(function() {
                    imageObserver.observe(this);
                });
            }
        },
        
        /**
         * Card Hover In
         */
        cardHoverIn: function() {
            $(this).find('.ipvcpt-video-play').css({
                transform: 'scale(1.1)',
                opacity: '1'
            });
            
            $(this).find('.ipvcpt-video-overlay').css({
                opacity: '0.8'
            });
        },
        
        /**
         * Card Hover Out
         */
        cardHoverOut: function() {
            $(this).find('.ipvcpt-video-play').css({
                transform: 'scale(1)',
                opacity: '0.9'
            });
            
            $(this).find('.ipvcpt-video-overlay').css({
                opacity: '0.5'
            });
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        VideoWall.init();
    });
    
})(jQuery);