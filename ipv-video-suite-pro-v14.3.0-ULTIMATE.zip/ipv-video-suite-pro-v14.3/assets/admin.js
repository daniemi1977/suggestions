/**
 * IPV Video Suite Pro - Admin JavaScript
 * Gestisce tutte le interazioni AJAX e UI
 */

(function($) {
    'use strict';
    
    const IPV_Admin = {
        
        /**
         * Inizializzazione
         */
        init: function() {
            this.bindEvents();
            this.initTooltips();
            this.checkScheduledSync();
        },
        
        /**
         * Bind eventi
         */
        bindEvents: function() {
            // Dashboard - Quick Import
            $('#ipv-quick-import, #ipv-start-import').on('click', this.startImport.bind(this));
            $('#ipv-sync-channel').on('click', this.syncChannel.bind(this));
            $('#ipv-test-apis').on('click', this.testAPIs.bind(this));
            
            // Transcriptions - Method Toggle
            $('input[name="transcript_method"]').on('change', this.toggleTranscriptMethod.bind(this));
            $('#ipv-test-ytapi').on('click', this.testYouTubeAPI.bind(this));
            $('#ipv-test-supadata').on('click', this.testSupaDataAPI.bind(this));
            $('#ipv-test-ai').on('click', this.testAI.bind(this));
            $('#ipv-save-transcript-settings').on('click', this.saveTranscriptSettings.bind(this));
            
            // Scheduler
            $('#ipv-save-scheduler').on('click', this.saveScheduler.bind(this));
        },
        
        /**
         * Inizializza tooltips Bootstrap
         */
        initTooltips: function() {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        },
        
        /**
         * Start Import
         */
        startImport: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const $progress = $('#ipv-import-progress, #ipv-quick-progress');
            const $progressBar = $('#ipv-import-progress-bar, #ipv-progress-bar');
            const $status = $('#ipv-import-status, #ipv-progress-text');
            const $results = $('#ipv-import-results');
            
            // Disabilita bottone
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Importing...');
            
            // Mostra progress
            $progress.show();
            $progressBar.css('width', '0%').text('0%');
            $status.text('Preparing import...');
            $results.hide();
            
            // Start import via AJAX
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_start_import',
                    nonce: IPV_AJAX.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.pollImportProgress(response.data.job_id, $progressBar, $status, $results, $btn);
                    } else {
                        this.showError($status, response.data.message || 'Import failed');
                        $btn.prop('disabled', false).html('<span class="dashicons dashicons-download"></span> Start Import Now');
                    }
                },
                error: (xhr, status, error) => {
                    this.showError($status, 'Connection error: ' + error);
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-download"></span> Start Import Now');
                }
            });
        },
        
        /**
         * Poll Import Progress
         */
        pollImportProgress: function(jobId, $progressBar, $status, $results, $btn) {
            const pollInterval = setInterval(() => {
                $.ajax({
                    url: IPV_AJAX.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ipv_check_import_progress',
                        nonce: IPV_AJAX.nonce,
                        job_id: jobId
                    },
                    success: (response) => {
                        if (response.success) {
                            const progress = response.data.progress;
                            const status = response.data.status;
                            
                            // Aggiorna progress bar
                            $progressBar.css('width', progress + '%').text(progress + '%');
                            $status.text(status);
                            
                            // Se completato
                            if (progress >= 100) {
                                clearInterval(pollInterval);
                                this.showImportResults(response.data, $results);
                                $btn.prop('disabled', false).html('<span class="dashicons dashicons-download"></span> Start Import Now');
                                
                                // Show success toast
                                this.showToast('Import completed successfully!', 'success');
                            }
                        }
                    }
                });
            }, 2000); // Poll ogni 2 secondi
        },
        
        /**
         * Show Import Results
         */
        showImportResults: function(data, $results) {
            const html = `
                <div class="alert alert-success fade-in" role="alert">
                    <h6 class="alert-heading">Import Completed!</h6>
                    <p class="mb-2"><strong>Videos Imported:</strong> ${data.imported_count}</p>
                    <p class="mb-2"><strong>Skipped:</strong> ${data.skipped_count}</p>
                    <p class="mb-0"><strong>Duration:</strong> ${data.duration}</p>
                </div>
            `;
            $results.html(html).show();
        },
        
        /**
         * Sync Channel
         */
        syncChannel: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Syncing...');
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_sync_channel',
                    nonce: IPV_AJAX.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.showToast('Channel synced successfully!', 'success');
                    } else {
                        this.showToast(response.data.message || 'Sync failed', 'error');
                    }
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Sync Channel');
                },
                error: () => {
                    this.showToast('Connection error', 'error');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Sync Channel');
                }
            });
        },
        
        /**
         * Test APIs
         */
        testAPIs: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Testing...');
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_test_all_apis',
                    nonce: IPV_AJAX.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.showToast('All APIs are working!', 'success');
                    } else {
                        this.showToast(response.data.message || 'Some APIs failed', 'warning');
                    }
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test APIs');
                },
                error: () => {
                    this.showToast('Connection error', 'error');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test APIs');
                }
            });
        },
        
        /**
         * Toggle Transcript Method
         */
        toggleTranscriptMethod: function(e) {
            const method = $(e.currentTarget).val();
            
            if (method === 'ytapi') {
                $('#ytapi-settings').slideDown();
                $('#supadata-settings').slideUp();
            } else {
                $('#supadata-settings').slideDown();
                $('#ytapi-settings').slideUp();
            }
        },
        
        /**
         * Test YouTube API
         */
        testYouTubeAPI: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const $results = $('#ipv-api-test-results');
            const apiKey = $('#ytapi-key').val();
            
            if (!apiKey) {
                this.showToast('Please enter YouTube API key', 'warning');
                return;
            }
            
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Testing...');
            $results.html('<p class="text-center py-4"><span class="ipv-loading"></span> Testing connection...</p>');
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_test_youtube_api',
                    nonce: IPV_AJAX.nonce,
                    api_key: apiKey
                },
                success: (response) => {
                    if (response.success) {
                        const html = `
                            <div class="api-test-result success">
                                <div class="d-flex align-items-center mb-2">
                                    <span class="dashicons dashicons-yes-alt text-success me-2"></span>
                                    <strong>Connection Successful</strong>
                                </div>
                                <p class="small mb-2">${response.data.message}</p>
                                ${response.data.details ? `<pre>${JSON.stringify(response.data.details, null, 2)}</pre>` : ''}
                            </div>
                        `;
                        $results.html(html);
                        this.showToast('YouTube API is working!', 'success');
                    } else {
                        const html = `
                            <div class="api-test-result error">
                                <div class="d-flex align-items-center mb-2">
                                    <span class="dashicons dashicons-dismiss text-danger me-2"></span>
                                    <strong>Connection Failed</strong>
                                </div>
                                <p class="small mb-0">${response.data.message}</p>
                            </div>
                        `;
                        $results.html(html);
                        this.showToast('YouTube API test failed', 'error');
                    }
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test YouTube API');
                },
                error: () => {
                    const html = `
                        <div class="api-test-result error">
                            <div class="d-flex align-items-center mb-2">
                                <span class="dashicons dashicons-dismiss text-danger me-2"></span>
                                <strong>Connection Error</strong>
                            </div>
                            <p class="small mb-0">Could not connect to server</p>
                        </div>
                    `;
                    $results.html(html);
                    this.showToast('Connection error', 'error');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test YouTube API');
                }
            });
        },
        
        /**
         * Test SupaData API
         */
        testSupaDataAPI: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const $results = $('#ipv-api-test-results');
            const baseUrl = $('#supadata-base').val();
            const apiKey = $('#supadata-key').val();
            
            if (!baseUrl || !apiKey) {
                this.showToast('Please enter SupaData credentials', 'warning');
                return;
            }
            
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Testing...');
            $results.html('<p class="text-center py-4"><span class="ipv-loading"></span> Testing connection...</p>');
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_test_supadata_api',
                    nonce: IPV_AJAX.nonce,
                    base_url: baseUrl,
                    api_key: apiKey
                },
                success: (response) => {
                    if (response.success) {
                        const html = `
                            <div class="api-test-result success">
                                <div class="d-flex align-items-center mb-2">
                                    <span class="dashicons dashicons-yes-alt text-success me-2"></span>
                                    <strong>Connection Successful</strong>
                                </div>
                                <p class="small mb-2">${response.data.message}</p>
                                ${response.data.details ? `<pre>${JSON.stringify(response.data.details, null, 2)}</pre>` : ''}
                            </div>
                        `;
                        $results.html(html);
                        this.showToast('SupaData API is working!', 'success');
                    } else {
                        const html = `
                            <div class="api-test-result error">
                                <div class="d-flex align-items-center mb-2">
                                    <span class="dashicons dashicons-dismiss text-danger me-2"></span>
                                    <strong>Connection Failed</strong>
                                </div>
                                <p class="small mb-0">${response.data.message}</p>
                            </div>
                        `;
                        $results.html(html);
                        this.showToast('SupaData API test failed', 'error');
                    }
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test SupaData API');
                },
                error: () => {
                    const html = `
                        <div class="api-test-result error">
                            <div class="d-flex align-items-center mb-2">
                                <span class="dashicons dashicons-dismiss text-danger me-2"></span>
                                <strong>Connection Error</strong>
                            </div>
                            <p class="small mb-0">Could not connect to server</p>
                        </div>
                    `;
                    $results.html(html);
                    this.showToast('Connection error', 'error');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test SupaData API');
                }
            });
        },
        
        /**
         * Test AI Connection (OpenAI/Claude)
         */
        testAI: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const provider = $('#ai-provider').val();
            const apiKey = $('#ai-key').val();
            const model = $('#ai-model').val();
            
            if (!apiKey) {
                this.showToast('Please enter AI API key', 'warning');
                return;
            }
            
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Testing...');
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_test_ai_connection',
                    nonce: IPV_AJAX.nonce,
                    provider: provider,
                    api_key: apiKey,
                    model: model
                },
                success: (response) => {
                    if (response.success) {
                        this.showToast(`${provider === 'openai' ? 'OpenAI' : 'Claude'} API is working!`, 'success');
                    } else {
                        this.showToast(response.data.message || 'AI test failed', 'error');
                    }
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test AI Connection');
                },
                error: () => {
                    this.showToast('Connection error', 'error');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-plugins"></span> Test AI Connection');
                }
            });
        },
        
        /**
         * Save Transcript Settings
         */
        saveTranscriptSettings: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const method = $('input[name="transcript_method"]:checked').val();
            const settings = {
                method: method,
                ytapi_key: $('#ytapi-key').val(),
                supadata_base: $('#supadata-base').val(),
                supadata_key: $('#supadata-key').val(),
                supadata_path: $('#supadata-path').val(),
                supadata_timeout: $('#supadata-timeout').val(),
                // AI settings
                ai_provider: $('#ai-provider').val(),
                ai_key: $('#ai-key').val(),
                ai_model: $('#ai-model').val()
            };
            
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Saving...');
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_save_transcript_settings',
                    nonce: IPV_AJAX.nonce,
                    settings: settings
                },
                success: (response) => {
                    if (response.success) {
                        this.showToast('Settings saved successfully!', 'success');
                    } else {
                        this.showToast(response.data.message || 'Save failed', 'error');
                    }
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-saved"></span> Save Settings');
                },
                error: () => {
                    this.showToast('Connection error', 'error');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-saved"></span> Save Settings');
                }
            });
        },
        
        /**
         * Save Scheduler
         */
        saveScheduler: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const frequency = $('#ipv-sync-frequency').val();
            
            $btn.prop('disabled', true).html('<span class="ipv-loading"></span> Saving...');
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_save_scheduler',
                    nonce: IPV_AJAX.nonce,
                    frequency: frequency
                },
                success: (response) => {
                    if (response.success) {
                        this.showToast('Scheduler updated successfully!', 'success');
                        if (response.data.next_run) {
                            $('#ipv-next-sync').text(response.data.next_run);
                        }
                    } else {
                        this.showToast(response.data.message || 'Save failed', 'error');
                    }
                    $btn.prop('disabled', false).html('Save Schedule');
                },
                error: () => {
                    this.showToast('Connection error', 'error');
                    $btn.prop('disabled', false).html('Save Schedule');
                }
            });
        },
        
        /**
         * Check Scheduled Sync
         */
        checkScheduledSync: function() {
            const $nextSync = $('#ipv-next-sync');
            if ($nextSync.length === 0) return;
            
            $.ajax({
                url: IPV_AJAX.ajaxurl,
                type: 'POST',
                data: {
                    action: 'ipv_get_next_scheduled_sync',
                    nonce: IPV_AJAX.nonce
                },
                success: (response) => {
                    if (response.success && response.data.next_run) {
                        $nextSync.text(response.data.next_run);
                    }
                }
            });
        },
        
        /**
         * Show Toast Notification
         */
        showToast: function(message, type = 'info') {
            const bgClass = {
                'success': 'bg-success',
                'error': 'bg-danger',
                'warning': 'bg-warning',
                'info': 'bg-info'
            }[type] || 'bg-info';
            
            const icon = {
                'success': 'yes-alt',
                'error': 'dismiss',
                'warning': 'warning',
                'info': 'info'
            }[type] || 'info';
            
            const toast = $(`
                <div class="ipv-toast toast show" role="alert">
                    <div class="toast-header ${bgClass} text-white">
                        <span class="dashicons dashicons-${icon} me-2"></span>
                        <strong class="me-auto">IPV Video Suite</strong>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                    </div>
                    <div class="toast-body">
                        ${message}
                    </div>
                </div>
            `);
            
            $('body').append(toast);
            
            setTimeout(() => {
                toast.addClass('hiding');
                setTimeout(() => toast.remove(), 300);
            }, 5000);
            
            toast.find('.btn-close').on('click', function() {
                toast.addClass('hiding');
                setTimeout(() => toast.remove(), 300);
            });
        },
        
        /**
         * Show Error
         */
        showError: function($element, message) {
            $element.html(`
                <div class="alert alert-danger" role="alert">
                    <span class="dashicons dashicons-dismiss"></span>
                    ${message}
                </div>
            `);
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        IPV_Admin.init();
    });
    
})(jQuery);
