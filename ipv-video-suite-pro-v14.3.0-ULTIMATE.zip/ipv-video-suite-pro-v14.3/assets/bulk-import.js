/**
 * Bulk Tools JavaScript
 */

(function($) {
    'use strict';
    
    const BulkTools = {
        
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            $('#bulk-import-form').on('submit', this.handleImport.bind(this));
            $('#regenerate-thumbs-form').on('submit', this.handleRegenerateThumbs.bind(this));
            $('#regenerate-transcripts-form').on('submit', this.handleRegenerateTranscripts.bind(this));
        },
        
        handleImport: function(e) {
            e.preventDefault();
            
            const ids = $('#video_ids').val().trim();
            
            if (!ids) {
                alert('Inserisci almeno un video ID');
                return;
            }
            
            this.showProgress('Import in corso...');
            
            $.ajax({
                url: IPV_BULK.ajaxurl,
                method: 'POST',
                data: {
                    action: 'ipv_bulk_import_ids',
                    nonce: IPV_BULK.nonce,
                    video_ids: ids,
                    auto_transcripts: $('#auto_transcripts').is(':checked') ? '1' : '0'
                },
                success: function(response) {
                    if (response.success) {
                        BulkTools.updateProgress(100, response.data);
                    } else {
                        alert('Errore: ' + response.data.message);
                        BulkTools.hideProgress();
                    }
                },
                error: function() {
                    alert('Errore di connessione');
                    BulkTools.hideProgress();
                }
            });
        },
        
        handleRegenerateThumbs: function(e) {
            e.preventDefault();
            
            const filter = $('input[name="thumb_filter"]:checked').val();
            
            if (!confirm('Sicuro di voler rigenerare le thumbnail?')) {
                return;
            }
            
            this.showProgress('Rigenerazione thumbnail in corso...');
            
            $.ajax({
                url: IPV_BULK.ajaxurl,
                method: 'POST',
                data: {
                    action: 'ipv_bulk_regenerate_thumbs',
                    nonce: IPV_BULK.nonce,
                    filter: filter
                },
                success: function(response) {
                    if (response.success) {
                        BulkTools.updateProgress(100, response.data);
                    } else {
                        alert('Errore: ' + response.data.message);
                        BulkTools.hideProgress();
                    }
                },
                error: function() {
                    alert('Errore di connessione');
                    BulkTools.hideProgress();
                }
            });
        },
        
        handleRegenerateTranscripts: function(e) {
            e.preventDefault();
            
            const filter = $('input[name="transcript_filter"]:checked').val();
            
            if (!confirm('Sicuro di voler rigenerare le trascrizioni? Questa operazione usa crediti SupaData.')) {
                return;
            }
            
            this.showProgress('Rigenerazione trascrizioni in corso...');
            
            $.ajax({
                url: IPV_BULK.ajaxurl,
                method: 'POST',
                data: {
                    action: 'ipv_bulk_regenerate_transcripts',
                    nonce: IPV_BULK.nonce,
                    filter: filter
                },
                success: function(response) {
                    if (response.success) {
                        BulkTools.updateProgress(100, response.data);
                    } else {
                        alert('Errore: ' + response.data.message);
                        BulkTools.hideProgress();
                    }
                },
                error: function() {
                    alert('Errore di connessione');
                    BulkTools.hideProgress();
                }
            });
        },
        
        showProgress: function(title) {
            $('#progress-title').text(title);
            $('#progress-bar').css('width', '0%');
            $('#progress-text').text('');
            $('#progress-log').html('');
            $('#bulk-progress').show();
            $('html, body').animate({
                scrollTop: $('#bulk-progress').offset().top - 50
            }, 500);
        },
        
        updateProgress: function(percent, data) {
            $('#progress-bar').css('width', percent + '%');
            
            if (data) {
                let text = '';
                
                if (data.total) {
                    text = data.total + ' totali';
                }
                
                if (data.imported) {
                    text += ' | ' + data.imported + ' importati';
                }
                
                if (data.success) {
                    text += ' | ' + data.success + ' successo';
                }
                
                if (data.skipped) {
                    text += ' | ' + data.skipped + ' saltati';
                }
                
                if (data.failed) {
                    text += ' | ' + data.failed + ' falliti';
                }
                
                $('#progress-text').text(text);
                
                if (data.log && data.log.length > 0) {
                    let logHtml = '';
                    data.log.forEach(function(line) {
                        const className = line.includes('✓') ? 'success' : (line.includes('✗') ? 'error' : '');
                        logHtml += '<div class="' + className + '">' + line + '</div>';
                    });
                    $('#progress-log').html(logHtml);
                }
            }
        },
        
        hideProgress: function() {
            $('#bulk-progress').hide();
        }
    };
    
    $(document).ready(function() {
        BulkTools.init();
    });
    
})(jQuery);
