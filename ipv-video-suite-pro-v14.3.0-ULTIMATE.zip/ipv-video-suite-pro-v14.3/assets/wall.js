/**
 * IPV Video Wall JavaScript
 * Gestisce il caricamento dinamico dei video
 */

(function($) {
    'use strict';
    
    const IPVWall = {
        
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            $(document).on('click', '.ipv-load-more-btn', this.handleLoadMore.bind(this));
        },
        
        handleLoadMore: function(e) {
            e.preventDefault();
            
            const $button = $(e.currentTarget);
            const $wall = $button.closest('.ipv-wall');
            const $grid = $wall.find('.ipv-wall-grid');
            
            // Previeni click multipli
            if ($button.prop('disabled')) {
                return;
            }
            
            // Ottieni parametri
            const currentPage = parseInt($wall.data('page')) || 1;
            const nextPage = currentPage + 1;
            const per = parseInt($wall.data('per')) || 12;
            const onlyh = String($wall.data('onlyh')) === '1' ? '1' : '0';
            const category = $wall.data('category') || '';
            const target = $wall.data('target') || 'youtube';
            
            // Mostra loading
            this.setButtonLoading($button, true);
            
            // AJAX request
            $.ajax({
                url: IPV_WALL_AJAX.ajaxurl,
                method: 'POST',
                data: {
                    action: 'ipv_wall_more',
                    nonce: IPV_WALL_AJAX.nonce,
                    page: nextPage,
                    per: per,
                    onlyh: onlyh,
                    category: category,
                    target: target,
                    show_title: '1',
                    show_duration: '1',
                    show_date: '0'
                },
                success: function(response) {
                    if (response.success) {
                        // Aggiungi nuovi video alla griglia
                        $grid.append(response.data.html);
                        
                        // Aggiorna numero pagina
                        $wall.data('page', nextPage);
                        
                        // Se non ci sono più video, nascondi/disabilita il bottone
                        if (!response.data.has_more) {
                            $button.prop('disabled', true);
                            $button.find('.ipv-btn-text').text(IPV_WALL_AJAX.no_more_text);
                        }
                        
                        // Scroll smooth ai nuovi video
                        const $newVideos = $grid.find('.ipv-video-card').slice(-per);
                        if ($newVideos.length > 0) {
                            $('html, body').animate({
                                scrollTop: $newVideos.first().offset().top - 100
                            }, 500);
                        }
                    } else {
                        console.error('IPV Wall: Errore nel caricamento dei video');
                        alert('Errore nel caricamento dei video. Riprova.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('IPV Wall AJAX Error:', error);
                    alert('Errore di connessione. Riprova.');
                },
                complete: function() {
                    // Rimuovi loading
                    IPVWall.setButtonLoading($button, false);
                }
            });
        },
        
        setButtonLoading: function($button, loading) {
            if (loading) {
                $button.prop('disabled', true);
                $button.find('.ipv-btn-text').hide();
                $button.find('.ipv-btn-loader').show();
            } else {
                $button.prop('disabled', false);
                $button.find('.ipv-btn-text').show();
                $button.find('.ipv-btn-loader').hide();
            }
        }
    };
    
    // Initialize quando il documento è pronto
    $(document).ready(function() {
        IPVWall.init();
    });
    
})(jQuery);
