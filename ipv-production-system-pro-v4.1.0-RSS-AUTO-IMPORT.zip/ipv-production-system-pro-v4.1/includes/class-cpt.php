<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IPV_Prod_CPT {

    public static function register() {
        $labels = [
            'name'               => 'Video IPV',
            'singular_name'      => 'Video IPV',
            'menu_name'          => 'Video IPV',
            'add_new'            => 'Aggiungi nuovo',
            'add_new_item'       => 'Aggiungi nuovo Video IPV',
            'edit_item'          => 'Modifica Video IPV',
            'new_item'           => 'Nuovo Video IPV',
            'view_item'          => 'Vedi Video IPV',
            'search_items'       => 'Cerca Video IPV',
            'not_found'          => 'Nessun video trovato',
            'not_found_in_trash' => 'Nessun video nel cestino',
        ];

        $args = [
            'labels'             => $labels,
            'public'             => true,
            'show_in_menu'       => true,
            'menu_icon'          => 'dashicons-video-alt3',
            'has_archive'        => true,
            'rewrite'            => [ 'slug' => 'video-ipv' ],
            'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
            'show_in_rest'       => true,
        ];

        register_post_type( 'video_ipv', $args );
    }
}
