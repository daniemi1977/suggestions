<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IPV_Prod_Supadata {

    protected static $endpoint = 'https://api.supadata.ai/v1/transcript';

    public static function get_transcript( $video_id, $mode = 'auto' ) {
        $api_key = get_option( 'ipv_supadata_api_key', '' );
        if ( empty( $api_key ) ) {
            return new WP_Error( 'ipv_supadata_no_key', 'SupaData API Key non configurata.' );
        }

        $video_url = 'https://www.youtube.com/watch?v=' . $video_id;

        $args = [
            'headers' => [
                'x-api-key' => $api_key,
                'Accept'    => 'application/json',
            ],
            'timeout' => 60,
        ];

        $query = [
            'url'  => $video_url,
            'text' => 'true',
            'mode' => $mode,
        ];

        $request_url = add_query_arg( $query, self::$endpoint );

        IPV_Prod_Logger::log( 'Richiesta SupaData', [ 'url' => $request_url ] );

        $response = wp_remote_get( $request_url, $args );
        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'ipv_supadata_http_error', 'Errore SupaData HTTP ' . $code );
        }

        if ( empty( $data['transcript'] ) ) {
            return new WP_Error( 'ipv_supadata_no_transcript', 'SupaData non ha restituito una trascrizione.' );
        }

        return $data['transcript'];
    }
}
